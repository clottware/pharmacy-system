<?php require 'config/session.php'; ?>
<?php include 'head.php'; ?>
<?php include 'components/sidebar.php'; ?>
<?php include 'components/header.php'; ?>
<?php
if ($auth->currentUser() != null) {
    $user = $auth->currentUser();
    $displayName = $user['first_name'] . ' ' . $user['last_name'];
}
?>

<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-2">
    <div class="mb-3">
        <h1 class="mb-1"><span class="greetings" id="greeting">Hello</span>, <?= $displayName; ?></h1>
        <p class="fw-medium"><?= date($settings->get('date_format')); ?></p>
    </div>
    <div class="input-icon-start position-relative mb-3">
        <span class="input-icon-addon fs-16 text-gray-9">
            <i class="ti ti-calendar"></i>
        </span>
        <input type="text" id="widget-date-range" class="form-control date-range bookingrange" placeholder="Search Product">
    </div>
</div>
<?php
$salesAnalytics = new Analytics();
$sales = new Sales();
// Daily sales
$todaySales = $salesAnalytics->getTotalSales('day');
$todayChange = $salesAnalytics->getPercentageChange('day');

// Weekly products sold
$productSold = $salesAnalytics->getProductsSold('day');
$productSoldPercentage = $salesAnalytics->getProductPercentageChange('day');

// Payment method breakdown
$paymentBreakdown = $salesAnalytics->getPaymentBreakdown('week');
?>

<?php if (isset($restPass) && $restPass): ?>
    <div class="alert alert-warning alert-dismissible fade show custom-alert-icon shadow-sm d-flex align-items-center" role="alert">
        <i class="ti ti-info-triangle flex-shrink-0 me-2"></i>
        <strong>Warning:</strong> Your password has been reset to the default password. For your security, <a href="settings?gs=security" class="mx-1 text-decoration-underline">Please change</a> it as soon as possible.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="fas fa-xmark"></i></button>
    </div>
<?php endif; ?>
<div class="row sales-cards">
    <div class="col-xl-6 col-sm-12 col-12 d-flex">
        <div class="card d-flex align-items-center justify-content-between flex-fill mb-4">
            <div>
                <h6>Daily Earning </h6>
                <h3><?= $settings->get('currency_symbol_full'); ?> <span class="counters money" data-count="<?= $todaySales; ?>">0</span></h3>
                <p class="sales-range"><span class="text-<?= $todayChange > 0 ? 'success' : 'danger'; ?> "><i data-feather="chevron-<?= $todayChange > 0 ? 'up' : 'down'; ?>" class="feather-16"></i><?= $todayChange > 0 ? '+' : '' ?><?= $todayChange; ?>%&nbsp;</span><?= round($todayChange) > 0 ? 'increase' : 'decrease' ?> compare to yesterday</p>
            </div>
            <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the weekly earning"></i>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6 col-12 d-flex">
        <div class="card color-info bg-primary flex-fill mb-4">
            <div class="d-flex align-items-left flex-column justify-content-end h-100">
                <h3 class="counters" data-count="<?= $productSold; ?>">0</h3>
                <p>Product Sold</p>
                <span class="badge badge-soft-<?= $productSoldPercentage > 0 ? 'success' : 'danger'; ?>"><i class="ti ti-arrow-<?= $productSoldPercentage > 0 ? 'up' : 'down'; ?> me-1"></i><?= $productSoldPercentage > 0 ? '+' : '' ?><?= round($productSoldPercentage); ?>%</span>
            </div>

            <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the total product sold for the week"></i>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6 col-12 d-flex gap-2 ">
        <?php foreach ($paymentBreakdown as $pd): ?>
            <div class="card bg-<?= $pd['payment_method'] === 'momo' ? 'secondary color-info' : '' ?> flex-fill mb-4 overflow-hidden">
                <div class="d-flex align-items-left flex-column position-relative justify-content-end h-100">

                    <h3 class="counters money" data-count="<?= $pd['total'] ?>">0</h3>
                    <small class="c-bg"><?= $settings->get('currency_symbol'); ?></small>
                    <p class="text-capitalize"><?= $pd['payment_method'] ?></p>
                </div>
                <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                    <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the total payment method for the day"></i>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<div class="row">
    <?php
    $lowStockProducts = new Product();
    $lowStockProduct = $lowStockProducts->productStockLevel();
    $categoryModel = new Category();
    ?>
    <!-- Sales & Purchase -->
    <div class="col-xxl-8 col-xl-7 col-sm-12 col-12 d-flex">
        <div class="card flex-fill">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-inline-flex align-items-center">
                    <span class="title-icon bg-soft-danger fs-16 me-2"><i class="ti ti-alert-triangle"></i></span>
                    <h5 class="card-title mb-0">Low Stock Products</h5>
                </div>
                <a href="stock-level?page=level" class="fs-13 fw-medium text-decoration-underline">View All</a>
            </div>
            <div class="card-body">
                <?php if ($lowStockProduct): ?>
                    <?php foreach ($lowStockProduct as $lowStock): ?>
                        <?php $category = $lowStock['category_id'] ? $categoryModel->getCategoryById($lowStock['category_id']) : null; ?>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div class="d-flex align-items-center">
                                <div class="ms-2">
                                    <h6 class="fw-bold mb-1"><a href="javascript:void(0);"><?= $lowStock['name'] ?></a></h6>
                                    <p class="fs-13">Category : <?= $category['name'] ?></p>
                                </div>
                            </div>
                            <div class="text-end">
                                <p class="fs-13 mb-1"><?= $lowStock['quantity'] === 0 ? 'Out of Stock' : 'In Stock' ?></p>
                                <h6 class="text-orange fw-medium"><?= $lowStock['quantity']; ?></h6>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- /Sales & Purchase -->

    <!-- Top Selling Products -->
    <div class="col-xxl-4 col-xl-5 d-flex">
        <div class="card flex-fill">
            <div class="card-header">
                <div class="d-inline-flex align-items-center">
                    <span class="title-icon bg-soft-info fs-16 me-2"><i class="ti ti-info-circle"></i></span>
                    <h5 class="card-title mb-0">Overall Information</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-primary fs-24">
                                <i class="ti ti-package"></i>
                            </div>
                            <p class="mb-1">Products</p>
                            <h5><?= $salesAnalytics->totalProducts() ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-primary fs-24">
                                <i class="ti ti-shopping-cart"></i>
                            </div>
                            <?php $salesSum = $sales->getSalesSummary(); ?>
                            <p class="mb-1">Sales</p>
                            <h5><?= $settings->get('currency_symbol'); ?> <?= number_format($salesSum['grand_total_sales'], 2) ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-primary fs-24">
                                <i class="ti ti-paper-bag"></i>
                            </div>
                            <p class="mb-1">Items Sold</p>
                            <h5><?= $salesSum['total_items_sold'] ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-primary fs-24">
                                <i class="ti ti-basket-check"></i>
                            </div>
                            <p class="mb-1">Transactions</p>
                            <h5><?= $salesSum['total_transactions'] ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-red fs-24">
                                <i class="ti ti-clock-hour-4"></i>
                            </div>
                            <p class="mb-1">Expired</p>
                            <h5><?= $salesAnalytics->expiredProductsCount() ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-red fs-24">
                                <i class="ti ti-info-triangle"></i>
                            </div>
                            <p class="mb-1">Low Stock</p>
                            <h5><?= count($lowStockProduct) ?></h5>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var hour = parseInt(serverTime, 10);
        var greeting = "Hello";
        if (hour >= 5 && hour < 12) {
            greeting = "Good morning";
        } else if (hour >= 12 && hour < 18) {
            greeting = "Good afternoon";
        } else {
            greeting = "Good evening";
        }
        $('#greeting').text(greeting);

        $('#widget-date-range').on('apply.daterangepicker', function(ev, picker) {
            const startDate = picker.startDate.format('YYYY-MM-DD');
            const endDate = picker.endDate.format('YYYY-MM-DD');

            $.ajax({
                url: 'controllers/filter_sales',
                method: 'POST',
                data: {
                    start: startDate,
                    end: endDate
                },
                success: function(response) {
                    // Update your sales table or dashboard here
                    $('.sales-table tbody').html(response); // or parse JSON and render
                },
                error: function() {
                    alert('Failed to fetch sales data.');
                }
            });
        });

    });
</script>
<?php
function pageModal()
{
    // This function can be overridden in specific pages to add modals
    return null;
}
require 'components/footer.php';
?>