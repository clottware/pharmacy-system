<?php
$sales = new Sales();
$sales = $sales->getAllSales();
?>
<div class="col-md-12 col-lg-5 col-xl-4 ps-0">
    <aside class="product-order-list">
        <form action="controllers/pos" id="cartForm">
            <div class="customer-info">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
                    <div class="d-flex align-items-center">
                        <h4 class="mb-0">New Order</h4>
                        <span class="badge badge-purple badge-xs fs-10 fw-medium ms-2">#<?= count($sales) + 1 ?></span>
                    </div>
                    <a href="#" class="btn btn-sm btn-outline-primary d-none shadow-primary" data-bs-toggle="modal" data-bs-target="#create">Add Customer</a>
                </div>
                <select class="select">
                    <option selected>Walk in Customer</option>
                </select>
            </div>
            <div class="product-added block-section">
                <div class="d-flex align-items-center justify-content-between gap-3 mb-3">
                    <h5 class="d-flex align-items-center mb-0">Order Details</h5>
                    <div class="badge bg-light text-gray-9 fs-12 fw-semibold py-2 border rounded">Items : <span class="text-teal">0</span></div>
                </div>
                <div class="product-wrap">
                    <div class="empty-cart" style="display: flex;">
                        <div class="mb-1">
                            <img src="assets/img/icons/empty-cart.svg" width="50" height="50" alt="img">
                        </div>
                        <p class="fw-bold">No Products Selected</p>
                    </div>
                    <div class="product-list cart-list border-0 p-0" style="display: none;">
                        <div class="table-responsive">
                            <table class="table table-borderless cart-table">
                                <thead>
                                    <tr>
                                        <th class="bg-transparent fw-bold">Product</th>
                                        <th class="bg-transparent fw-bold">QTY</th>
                                        <th class="bg-transparent fw-bold">Price</th>
                                        <th class="bg-transparent fw-bold text-end"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center mb-1">
                                                <h6 class="fs-16 fw-medium"><a href="#"></a></h6>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="qty-item m-0">
                                                <a href="javascript:void(0);" class="dec d-flex justify-content-center align-items-center text-black" data-bs-toggle="tooltip" data-bs-placement="top" title="minus"><i data-feather="minus-circle" class="feather-14"></i></a>
                                                <input type="text" class="form-control text-center" name="qty" value="4">
                                                <a href="javascript:void(0);" class="inc d-flex justify-content-center align-items-center text-black" data-bs-toggle="tooltip" data-bs-placement="top" title="plus"><i data-feather="plus-circle" class="feather-14"></i></a>
                                            </div>
                                        </td>
                                        <td class="fw-bold"><?= $settings->get('currency_symbol'); ?>0</td>
                                        <td class="text-end">
                                            <a class="btn-icon delete-icon" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete">
                                                <i class="ti ti-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="block-section order-method bg-light m-0">
                <div class="order-total">
                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tr>
                                <td>Sub Total</td>
                                <td class="text-end"><?= $settings->get('currency_symbol'); ?> <span class="subTotal">0</span></td>
                            </tr>
                            <tr>
                                <td>Grand Total</td>
                                <td class="text-end"><?= $settings->get('currency_symbol'); ?> <span class="grandTotal">0</span></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row gx-2">
                    <div class="col-sm-4">
                        <a href="javascript:void(0);" class="btn btn-indigo d-flex align-items-center justify-content-center w-100 mb-2" id="resetCart"><i class="ti ti-reload me-2"></i>Reset</a>
                    </div>
                </div>
            </div>
            <div class="block-section payment-method">
                <h5 class="mb-2">Select Payment</h5>
                <div class="row align-items-center justify-content-center methods g-2 mb-4">
                    <div class="col-sm-6 col-md-4 col-xl d-flex">
                        <a href="javascript:void(0);" class="payment-item flex-fill" data-method="cash">
                            <p class="fw-medium">Cash</p>
                        </a>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xl d-flex">
                        <a href="javascript:void(0);" class="payment-item flex-fill" data-method="momo">
                            <p class="fw-medium">Mobile Money</p>
                        </a>
                    </div>
                    <input type="hidden" name="payment-item">
                </div>
                <div class="btn-block m-0">
                    <input type="hidden" name="action" value="new">
                    <button type="submit" class="btn btn-teal w-100">
                        Pay : <?= $settings->get('currency_symbol'); ?> <span class="grandTotal">0.00</span>
                    </button>
                </div>
            </div>
        </form>
    </aside>
</div>