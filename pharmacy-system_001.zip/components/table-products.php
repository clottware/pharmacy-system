<?php
function productTable($products = [])
{
    return <<<HTML

    
    HTML;
}
