<?php $active = basename($_SERVER['PHP_SELF']) ? 'active' : null; ?>
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <!-- Logo -->
    <div class="sidebar-logo active">
        <a href="dashboard" class="logo logo-normal">
            <img src="assets/img/logo.svg" alt="Img">
        </a>
        <a href="dashboard" class="logo logo-white">
            <img src="assets/img/logo-white.svg" alt="Img">
        </a>
        <a href="dashboard" class="logo-small">
            <img src="assets/img/logo-small.png" alt="Img">
        </a>
        <a id="toggle_btn" href="javascript:void(0);" class="d-none">
            <i data-feather="chevrons-left" class="feather-16"></i>
        </a>
    </div>
    <!-- /Logo -->
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Main</h6>
                    <ul>
                        <li>
                            <a href="dashboard"><i class="ti ti-layout-grid fs-16 me-2"></i><span>Dashboard</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Inventory</h6>
                    <ul>
                        <li><a href="products"><i class="ti ti-table-plus fs-16 me-2"></i><span>Product</span></a></li>
                        <li><a href="categories"><i class="ti ti-list-details fs-16 me-2"></i><span>Category</span></a></li>
                        <li><a href="brands"><i class="ti ti-triangles fs-16 me-2"></i><span>Brands</span></a></li>
                        <li class="submenu">
                            <a href="javascript:void(0);"><i class="ti ti-stairs-up fs-16 me-2"></i><span>Stock Levels</span><span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="stock-level?page=level">Low Stocks</a></li>
                                <li><a href="stock-level?page=expire">Expired Products</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Sales & Purchases</h6>
                    <ul>
                        <li><a href="sales"><i class="ti ti-shopping-cart fs-16 me-2"></i><span>Sales</span></a></li>
                        <li class="">
                            <a href="pos"><i class="ti ti-device-laptop fs-16 me-2"></i><span>POS</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Settings</h6>
                    <ul>
                        <li>
                            <a href="settings"><i class="ti ti-settings fs-16 me-2"></i>
                                <span>Settings</span>
                                <?php if ($settings->get('update') == 'true'): ?>
                                    <span class="badge bg-primary badge-xs text-white fs-10 ms-2">New</span>
                                <?php endif; ?>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->