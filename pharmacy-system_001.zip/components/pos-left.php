<?php
$currentUser = $auth->currentUser();
if ($currentUser) {
    $displayName = $currentUser['first_name'] . ' ' . $currentUser['last_name'];
} else {
    $displayName = 'Guest';
}
$productModel = new Product();
$categoryModel = new Category();
$brandModel = new Brands();
$sales = new Sales();
$sales = $sales->getAllSales();
if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
    $products = $productModel->getProductsByCategory($_GET['category']);
} else {
    $products = $productModel->getAllProducts();
}
?>
<div class="col-md-12 col-lg-7 col-xl-8">
    <div class="pos-categories tabs_wrapper">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
            <div>
                <h5 class="mb-1">Welcome, <?= $displayName; ?></h5>
                <p><?= date($settings->get('date_format')); ?></p>
            </div>
        </div>
        <ul class="tabs owl-carousel pos-category3 mb-4 w-100">
            <li id="all">
                <h6><a href="javascript:void(0);">Sales</a></h6>
            </li>
            <li id="new" class="active">
                <h6><a href="javascript:void(0);">Add Sales</a></h6>
            </li>
        </ul>
        <div class="pos-products">
            <div class="tabs_container">
                <div class="tab_content" data-tab="all">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                        <div>
                            <h5 class="mb-1">Sales -<?= count($sales) ?></h5>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                            <div class="search-set">
                                <div class="search-input">
                                    <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table datatable">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Id</th>
                                            <th>Total Amount</th>
                                            <th>Amount Received</th>
                                            <th>Balance</th>
                                            <th>Stats</th>
                                            <th> Created at</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($sales):
                                            foreach ($sales as $sale):
                                        ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <a href="javascript:void(0);" class="view-sales-details" data-id="<?= $sale['sale_id'] ?>"><?= $sale['reference']; ?></a>
                                                        </div>
                                                    </td>
                                                    <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['total_amount'], 2) ?></td>
                                                    <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['amount_receive'], 2) ?></td>
                                                    <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['sales_balance'], 2) ?></td>
                                                    <td><span class=""><?= $sale['status'] ?></span></td>
                                                    <td class=" action-table-data">
                                                        <?= date($settings->get('date_format'), strtotime($sale['created_at'])) ?>
                                                    </td>
                                                </tr>
                                        <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab_content active" data-tab="new">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                            <div class="search-set">
                                <div class="search-input">
                                    <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table datatable">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Brand</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th class="no-sort"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($products):
                                            foreach ($products as $product):
                                                $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                                                $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                                        ?>
                                                <tr id="<?= $product['id'] ?>">
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <a href="products?action=view&id=<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></a>
                                                        </div>
                                                    </td>
                                                    <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                                    <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                                    <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                                    <td data-original="<?= intval($product['quantity']) ?>"><?= intval($product['quantity']) ?></td>
                                                    <td class="action-table-data">
                                                        <div class="edit-delete-action">
                                                            <a class="p-2 bg-teal text-white fs-18 addToCartBtn" data-qty="<?= number_format($product['quantity'], 2) ?>" data-id="<?= $product['id'] ?>" data-name="<?= $product['name'] ?>" data-price="<?= number_format($product['price'], 2) ?>" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add product" href="javascript:void(0);">
                                                                <i data-feather="plus-circle" class="feather-plus-circle"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                        <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        function number_format(number, decimals = 0, dec_point = '.', thousands_sep = ',') {
            number = parseFloat(number) || 0;
            return number.toLocaleString('en-US', {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            }).replace('.', dec_point).replace(/,/g, thousands_sep);
        }
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            },
        });

        // function to handle toaster
        function toaster(type, message) {
            Toast.fire({
                icon: type,
                title: message,
            });
        }
        // 🔍 Check if cart exists and render
        let cart = JSON.parse(localStorage.getItem('posCart')) || [];
        if (cart.length > 0) {
            $('.empty-cart').hide();
            $('.cart-list').show();
            renderCart();
        } else {
            $('.empty-cart').css('display', 'flex');
            $('.cart-list').hide();
        }

        // 🛒 Add to cart button click
        $('body').on('click', '.addToCartBtn', function() {

            let id = $(this).data('id');
            let cart = JSON.parse(localStorage.getItem('posCart')) || [];
            let existing = cart.find(p => p.id == id);

            $.ajax({
                type: "GET",
                url: "controllers/pos",
                data: {
                    product_id: id,
                    qty: existing ? existing.qty + 1 : 1,
                },
                dataType: "json",
                beforeSend: function() {
                    $btn.prop('disabled', true);
                },
                success: function(response) {
                    if (response.status) {
                        const product = {
                            id: response.data.id,
                            name: response.data.name,
                            price: parseFloat(response.data.price),
                            qty: existing ? existing.qty + 1 : 1,
                            currencySymbol: response.data.currencySymbol
                        };
                        if (existing) {
                            existing.qty += 1;
                        } else {
                            cart.push(product);
                        }
                        localStorage.setItem('posCart', JSON.stringify(cart));
                        $('.empty-cart').css('display', 'none');
                        $('.cart-list').show();
                        toaster('success', response.message);
                    } else {
                        toaster('error', response.message);
                    }

                    renderCart();
                }
            });
        });

        // 🧾 Render cart UI
        function renderCarts() {
            let cart = JSON.parse(localStorage.getItem('posCart')) || [];
            let html = '';
            let subTotal = 0;
            cart.forEach((item, index) => {
                let itemTotal = item.price * item.qty;
                subTotal += itemTotal;
                html += `<tr>
                <td>
                    <div class="d-flex align-items-center mb-1">
                        <h6 class="fs-16 fw-medium"><a href="#">${item.name}</a></h6>
                    </div>
                </td>
                <td>
                    <div class="qty-item m-0">
                        <a href="javascript:void(0);" class="dec d-flex justify-content-center align-items-center text-black" data-bs-toggle="tooltip" data-bs-placement="top" title="minus"> <i class="ti ti-circle-minus"></i></a>
                        <input type="text" class="form-control text-center" readonly name="item_qty[]" value="${item.qty}">
                        <input type="hidden" id="product_id" name="item_id[]" value="${item.id}">
                        <input type="hidden" id="product_price" name="item_price[]" value="${item.price}">
                        <a href="javascript:void(0);" class="inc d-flex justify-content-center align-items-center text-black" data-bs-toggle="tooltip" data-bs-placement="top" title="plus"> <i class="ti ti-circle-plus "></i></a>
                    </div>
                </td>
                <td class="fw-bold">${item.currencySymbol}${(item.price * item.qty).toFixed(2)}</td>
                <td class="text-end">
                    <a class="btn-icon delete-icon removeBtn" href="javascript:void(0);" data-id="${item.qty}" data-bs-toggle="modal" data-bs-target="#delete">
                        <i class="ti ti-trash"></i>
                    </a>
                </td>
            </tr>`;
            });
            $('.cart-table tbody').html(html);
            // Update totals
            $('.subTotal').text(subTotal.toFixed(2));
            $('.grandTotal').text(subTotal.toFixed(2)); // If no extra charges, grand total = sub total

        }


        function renderCart() {
            let cart = JSON.parse(localStorage.getItem('posCart')) || [];
            let html = '';
            let subTotal = 0;

            cart.forEach((item, index) => {
                let itemTotal = item.price * item.qty;
                subTotal += itemTotal;

                // 🔄 Update product table stock
                const $productRow = $('#' + item.id);
                const $stockCell = $productRow.find('td').eq(4); // Assuming stock is in the 5th column
                const originalStock = parseInt($stockCell.data('original')); // Use data-original to track initial stock
                const remainingStock = originalStock - item.qty;
                $stockCell.text(remainingStock >= 0 ? remainingStock : 0);

                html += `<tr>
      <td>
        <div class="d-flex align-items-center mb-1">
          <h6 class="fs-16 fw-medium"><a href="#">${item.name}</a></h6>
        </div>
      </td>
      <td>
        <div class="qty-item m-0">
          <a href="javascript:void(0);" class="dec text-black" data-id="${item.id}" title="minus"><i class="ti ti-circle-minus"></i></a>
          <input type="text" class="form-control text-center" readonly name="item_qty[]" value="${item.qty}">
          <input type="hidden" name="item_id[]" value="${item.id}">
          <input type="hidden" name="item_price[]" value="${item.price}">
          <a href="javascript:void(0);" class="inc text-black" data-id="${item.id}" title="plus"><i class="ti ti-circle-plus"></i></a>
        </div>
      </td>
      <td class="fw-bold">${item.currencySymbol}${itemTotal.toFixed(2)}</td>
      <td class="text-end">
        <a class="btn-icon delete-icon removeBtn" href="javascript:void(0);" data-id="${item.id}">
          <i class="ti ti-trash"></i>
        </a>
      </td>
    </tr>`;
            });

            $('.cart-table tbody').html(html);
            $('.subTotal').text(subTotal.toFixed(2));
            $('.grandTotal').text(subTotal.toFixed(2));
        }


        // ❌ Remove item
        $(document).on('click', '.removeBtn', function() {
            let cart = JSON.parse(localStorage.getItem('posCart')) || [];
            cart.splice($(this).data('index'), 1);
            localStorage.setItem('posCart', JSON.stringify(cart));
            renderCart();
        });

        $(document).on('click', '#resetCart', function() {
            localStorage.removeItem('posCart');
            renderCart();
            $('.empty-cart').css('display', 'flex');
            $('.cart-list').hide();
            toaster('success', 'Cart has been reset.');
        });

        // Increment Decrement

        $('body').on('click', '.inc', function() {
            updateValue(this, 1);
        });
        $('body').on('click', '.dec', function() {
            updateValue(this, -1);
        });

        function updateValue(obj, delta) {
            let id = $(obj).parent().find('input[type="hidden"]').val();
            var item = $(obj).parent().find('input[type="text"]');
            var newValue = parseInt(item.val(), 10) + delta;

            let cart = JSON.parse(localStorage.getItem('posCart')) || [];
            item.val(Math.max(newValue, 0));

            // Find if product already exists in cart
            let existing = cart.find((product) => product.id == id);

            $.ajax({
                type: 'GET',
                url: 'controllers/pos',
                data: {
                    product_id: id,
                    qty: existing ? existing.qty + delta : 1,
                },
                dataType: 'json',
                beforeSend: function() {
                    $btn.prop('disabled', true);
                },
                success: function(response) {
                    if (response.status) {
                        const product = {
                            id: response.data.id,
                            name: response.data.name,
                            price: parseFloat(response.data.price),
                            qty: existing ? existing.qty + delta : 1,
                            currencySymbol: response.data.currencySymbol,
                        };
                        if (existing) {
                            existing.qty += delta;
                        } else {
                            cart.push(product);
                        }
                        localStorage.setItem('posCart', JSON.stringify(cart));
                    } else {
                        toaster('error', response.message);
                    }

                    renderCart();
                },
            });
        }

        $(document).on('click', '.payment-item', function() {
            let method = $(this).data('method');
            let input = $('input[name="payment-item"]');

            input.val(method);
        });

        $(document).on('submit', '#cartForm', function(e) {
            e.preventDefault();
            let $form = $(this);
            let formData = $form.serialize();
            let $btn = $('button[type="submit"]');
            $('.sale-id').html('');
            $('.final-price').html('');
            $('#payment_amount').val('');
            $('#sale_id').val('');
            $('select#select_payment_method').val('').trigger('change');
            $.ajax({
                url: 'controllers/pos',
                method: 'POST',
                data: formData,
                dataType: "json",
                beforeSend: function() {
                    $btn.prop('disabled', true);
                },
                success: function(response) {
                    if (response.status) {
                        $('.sale-id').html('#' + response.data.sale_id);
                        $('.final-price').html(response.data.total_price);
                        $('#payment_amount').val(number_format(response.data.total_price, 2));
                        $('#sale_id').val(response.data.sale_id);
                        $('select#select_payment_method').val(response.data.payment_method).trigger('change');
                        $('#saleComplete').modal('show');
                        $('.cancel-order-btn').data('id', response.data.sale_id);
                    } else {
                        toaster('error', response.message);
                    }
                }
            });
        });

        $('.cancel-order-btn').on('click', function() {
            let id = $(this).data('id');
            $('input[name="cancel_order_id"]').val(id);
            $('#cancelSales').modal('show');
        });

        $('#cancelOrderForm').submit(function(e) {
            e.preventDefault();
            let $form = $(this);
            let formData = $form.serialize();
            let $btn = $('button[type="submit"]');
            $.ajax({
                url: 'controllers/pos',
                method: 'POST',
                data: formData,
                dataType: "json",
                success: function(response) {
                    if (response.status) {
                        localStorage.removeItem('posCart');
                        renderCart();
                        $('.empty-cart').css('display', 'flex');
                        $('.cart-list').hide();
                        toaster('success', 'Cart has been reset.');
                        $('#cancelSales').modal('hide');
                        $('#saleComplete').modal('hide');
                        // Resets all forms on the page
                        $('form').each(function() {
                            this.reset();
                        });
                    } else {
                        toaster('error', response.message);
                    }
                }
            });
        });

        $('#confirmBtnOrder').click(function(e) {
            e.preventDefault();
            let $btn = $('button[type="submit"]');
            let $receive_amount = $('#received_amount').val();
            let $payment_amount = $('#payment_amount').val();
            let $sale_change = $('#sale_change').val();
            let $payment_method = $('#select_payment_method').val();
            let $sales_id = $('#sale_id').val();
            $.ajax({
                url: 'controllers/pos',
                method: 'POST',
                data: {
                    receive_amount: $receive_amount,
                    payment_amount: $payment_amount,
                    sale_change: $sale_change,
                    payment_method: $payment_method,
                    sales_id: $sales_id,
                    action: 'confirm'
                },
                dataType: "json",
                success: function(response) {
                    if (response.status) {
                        localStorage.removeItem('posCart');
                        renderCart();
                        $('.empty-cart').css('display', 'flex');
                        $('.cart-list').hide();
                        toaster('success', 'Cart has been reset.');
                        $('#cancelSales').modal('hide');
                        $('#saleComplete').modal('hide');
                        // Resets all forms on the page
                        $('form').each(function() {
                            this.reset();
                        });
                        toaster('success', response.message);
                    } else {
                        toaster('error', response.message);
                    }
                }
            });
        });

        $('#salesConfirmForm').submit(function(e) {
            e.defaultPrevented();
            let $form = $(this);
            let formData = $form.serialize();
            let $btn = $('button[type="submit"]');

            $.ajax({
                url: 'controllers/pos',
                method: 'POST',
                data: formData,
                dataType: "json",
                success: function(response) {
                    if (response.status) {
                        localStorage.removeItem('posCart');
                        renderCart();
                        $('.empty-cart').css('display', 'flex');
                        $('.cart-list').hide();
                        toaster('success', 'Cart has been reset.');
                        $('#cancelSales').modal('hide');
                        $('#saleComplete').modal('hide');
                        // Resets all forms on the page
                        $('form').each(function() {
                            this.reset();
                        });
                    } else {
                        toaster('error', response.message);
                    }
                }
            });
        });

        $('.view-sales-details').click(function(e) {
            e.preventDefault();
            let id = $(this).data('id');
            $('.sales-status').removeClass('badge-warning');
            $('.sales-status').removeClass('badge-danger');
            $('.sales-status').removeClass('badge-success');
            $.ajax({
                url: 'controllers/pos',
                method: 'GET',
                data: {
                    id: id,
                    getSales: true
                },
                dataType: "json",
                success: function(response) {
                    $('.sales-reference').html('#' + response.data.reference);
                    $('.sales-status').html(response.data.status);
                    $('.sales-total').html(number_format(response.data.total_amount, 2));
                    $('.sales-paid').html(number_format(response.data.amount_receive, 2));
                    $('.sales-due').html(number_format(response.data.sales_balance, 2));
                    $('.sales-method').html(response.data.payment_method);
                    const rawDate = response.data.created_at;
                    const dateObj = new Date(rawDate);

                    // Example: format as "04 Sep 2025, 2:08 PM"
                    const formatted = dateObj.toLocaleString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });

                    $('.sales-date').html(formatted);
                    if (response.data.status == 'pending') {
                        $('.sales-status').addClass('badge-warning')
                    }
                    if (response.data.status == 'paid') {
                        $('.sales-status').addClass('badge-success')
                    }
                    if (response.data.status == 'canceled') {
                        $('.sales-status').addClass('badge-danger')
                    }
                    const currencySymbol = '<?= $settings->get("currency_symbol"); ?>';
                    let html = '';

                    response.data.items.forEach(item => {
                        html += `<tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                    <a href="products?action=view&id=${item.product_id}">${item.product_name}</a>
                                    </div>
                                </td>
                                <td>${item.category}</td>
                                <td>${number_format(item.price, 2)}</td>
                                <td>${item.quantity}</td>
                                <td>${number_format(item.subtotal,2)}</td>
                                </tr>`;
                    });

                    $('.datanew tbody').html(html);
                    $('#sales-details-new').modal('show');
                }
            });
        });

    });
</script>

<script>
    $(document).ready(function() {
        function calculateChange() {
            let received = parseFloat($('#received_amount').val().replace(/,/g, '')) || 0;
            let payment = parseFloat($('#payment_amount').val().replace(/,/g, '')) || 0;
            let change = received - payment;

            // Prevent negative change
            $('#sale_change').val(change >= 0 ? change.toFixed(2) : '0.00');
        }

        // Trigger on input
        $('#received_amount, #payment_amount').on('input', function() {
            calculateChange();
        });

        // Optional: Format input with commas
        $('#received_amount, #payment_amount').on('blur', function() {
            let val = parseFloat($(this).val().replace(/,/g, '')) || 0;
            $(this).val(val.toLocaleString('en-US', {
                minimumFractionDigits: 2
            }));
        });
    });
</script>