<?php
class Analytics
{
    private $conn;
    private $productTable = "products";
    private $salesTable = "sales";
    private $salesItemsTable = "sale_items";

    public function __construct()
    {
        $this->conn = Database::getInstance(); // Correct way to get the singleton instance
    }

    public function totalProducts()
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->productTable}";
        return $this->conn->fetch($sql)['total'];
    }

    public function lowStockCount()
    {
        $sql = "SELECT COUNT(*) as low_stock FROM {$this->productTable} WHERE quantity <= quantity_alert";
        return $this->conn->fetch($sql)['low_stock'];
    }

    public function expiredProductsCount()
    {
        $today = date('Y-m-d');
        $sql = "SELECT COUNT(*) as expired FROM {$this->productTable} WHERE expiry_date IS NOT NULL AND expiry_date < ?";
        return $this->conn->fetch($sql, [$today])['expired'];
    }

    /**
     * Get total sales for a given period
     */
    public function getTotalSales($period = 'day')
    {
        switch ($period) {
            case 'day':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND DATE(created_at) = CURDATE()";
                break;
            case 'week':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND  YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)";
                break;
            case 'month':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
                break;
        }
        return $this->conn->fetch($sql)['total'] ?? 0;
    }

    /**
     * Get previous period sales for comparison
     */
    public function getPreviousTotalSales($period = 'day')
    {
        switch ($period) {
            case 'day':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND DATE(created_at) = CURDATE() - INTERVAL 1 DAY";
                break;
            case 'week':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1) - 1";
                break;
            case 'month':
                $sql = "SELECT SUM(total_amount) as total FROM {$this->salesTable} WHERE status = 'paid' AND MONTH(created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH)";
                break;
        }
        return $this->conn->fetch($sql)['total'] ?? 0;
    }

    /**
     * Calculate percentage change
     */
    public function getPercentageChange($period = 'day')
    {
        $current = $this->getTotalSales($period);
        $previous = $this->getPreviousTotalSales($period);

        if ($previous == 0) {
            return $current > 0 ? 100 : 0; // avoid division by zero
        }
        return (($current - $previous) / $previous) * 100;
    }

    /**
     * Get number of products sold for a given period
     */
    public function getProductsSold($period = 'day')
    {
        switch ($period) {
            case 'day':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE status = 'paid' AND DATE(s.created_at) = CURDATE()";
                break;
            case 'week':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE status = 'paid' AND YEARWEEK(s.created_at, 1) = YEARWEEK(CURDATE(), 1)";
                break;
            case 'month':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE status = 'paid' AND MONTH(s.created_at) = MONTH(CURDATE()) AND YEAR(s.created_at) = YEAR(CURDATE())";
                break;
        }
        return $this->conn->fetch($sql)['qty'] ?? 0;
    }

    /**
     * Get number of previous period products sold for comparison
     */

    public function getPreviousProductsSold($period = 'day')
    {
        switch ($period) {
            case 'day':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE DATE(s.created_at) = CURDATE() - INTERVAL 1 DAY";
                break;
            case 'week':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE YEARWEEK(s.created_at, 1) = YEARWEEK(CURDATE(), 1) - 1";
                break;
            case 'month':
                $sql = "SELECT SUM(quantity) as qty FROM {$this->salesItemsTable} si 
                        JOIN {$this->salesTable} s ON si.sale_id = s.id
                        WHERE MONTH(s.created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(s.created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH)";
                break;
        }
        return $this->conn->fetch($sql)['qty'] ?? 0;
    }

    /**
     * Get product percentage change
     *
     */
    public function getProductPercentageChange($period = 'day')
    {
        $current = $this->getProductsSold($period);
        $previous = $this->getPreviousProductsSold($period);

        if ($previous == 0) {
            return $current > 0 ? 100 : 0; // avoid division by zero
        }
        return (($current - $previous) / $previous) * 100;
    }

    /**
     * Get sales breakdown by payment method
     */
    public function getPaymentBreakdown($period = 'day')
    {
        switch ($period) {
            case 'day':
                $where = "DATE(created_at) = CURDATE()";
                break;
            case 'week':
                $where = "YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)";
                break;
            case 'month':
                $where = "MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
                break;
        }

        $sql = "SELECT payment_method, SUM(total_amount) as total 
                FROM {$this->salesTable} 
                WHERE $where 
                GROUP BY payment_method";

        return $this->conn->fetchAll($sql);
    }

    /**
     * Get total sales within a date range
     */
    public function getSalesByDateRange($startDate, $endDate)
    {
        $sql = "SELECT SUM(total_amount) as total_sales, COUNT(id) as total_transactions 
                FROM {$this->salesTable} 
                WHERE DATE(created_at) BETWEEN ? AND ?";
        return $this->conn->fetch($sql, [$startDate, $endDate]);
    }

    /**
     * Compare two periods and return percentage change
     */
    public function compareSales($currentStart, $currentEnd, $previousStart, $previousEnd)
    {
        $current = $this->getSalesByDateRange($currentStart, $currentEnd);
        $previous = $this->getSalesByDateRange($previousStart, $previousEnd);

        $currentTotal = $current['total_sales'] ?? 0;
        $previousTotal = $previous['total_sales'] ?? 0;

        $percentageChange = 0;
        if ($previousTotal > 0) {
            $percentageChange = (($currentTotal - $previousTotal) / $previousTotal) * 100;
        } elseif ($currentTotal > 0) {
            $percentageChange = 100; // 100% increase if no previous record
        }

        return [
            "current" => $currentTotal,
            "previous" => $previousTotal,
            "percentage_change" => round($percentageChange, 2)
        ];
    }

    /**
     * Get total expired goods for a given period
     */
}
