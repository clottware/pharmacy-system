<?php

class Sales
{
    private $conn;
    private $salesTable = "sales";
    private $saleItemsTable = "sale_items";

    public function __construct()
    {
        $this->conn = Database::getInstance();
    }

    // Create new sale
    public function createSale($staff_id, $payment_method, $reference, $items = [])
    {
        try {
            $this->conn->beginTransaction();

            // Validate stock for each item before proceeding
            foreach ($items as $index => $item) {
                $sql = "SELECT quantity FROM products WHERE id = ?";
                $product = $this->conn->fetch($sql, [$item['id']]);
                if (!$product || $product['quantity'] < $item['quantity']) {
                    //throw new Exception("Insufficient stock for product ID: " . $item['id']);
                    $res = ['status' => false, 'message' => "Insufficient stock for product ID: " . $item['id']];
                    return $res;
                }
            }

            // Calculate total
            $total = 0;
            foreach ($items as $item) {
                $total += $item['quantity'] * $item['price'];
            }

            // Insert into sales table
            $sql = "INSERT INTO {$this->salesTable} (staff_id, payment_method, total_amount, reference,created_at) VALUES (?, ?, ?, ?, NOW())";
            $sale_id = $this->conn->insert($sql, [$staff_id, $payment_method, $total, $reference]);

            // Insert into sale_items table
            foreach ($items as $item) {
                $subtotal = $item['quantity'] * $item['price'];
                $sql = "INSERT INTO {$this->saleItemsTable} (sale_id, product_id, quantity, price, subtotal, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
                $this->conn->insert($sql, [
                    $sale_id,
                    $item['id'],
                    $item['quantity'],
                    $item['price'],
                    $subtotal
                ]);

                // Reduce stock in products table
                //$this->updateProductStock($item['id'], $item['quantity']);
            }

            $this->conn->commit();
            $res = ['status' => true, 'sale_id' => $sale_id, 'total' => $total];
            return $res;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    public function changeSaleStatus($sales_id, $status = 'pending')
    {

        $sql = "UPDATE {$this->salesTable} SET status = ? WHERE id = ?";
        $this->conn->update($sql, [$status, $sales_id]);
    }

    public function deleteSales($product_id, $status = 'pending')
    {
        $sql = "UPDATE {$this->salesTable} SET status = ? WHERE id = ?";
        $this->conn->update($sql, [$status, $product_id]);
    }

    // Reduce stock
    private function updateProductStock($product_id, $quantity_sold)
    {
        $sql = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
        $this->conn->update($sql, [$quantity_sold, $product_id]);
    }

    public function updateSales($sale_id, $payment_method, $total_amount, $amount_receive, $sales_balance)
    {
        $sql = "UPDATE {$this->salesTable} 
        SET payment_method = ?,
            total_amount = ?,
            amount_receive = ?,
            sales_balance = ?
            WHERE id = ?";

        $update = $this->conn->update($sql, [
            $payment_method,
            $total_amount,
            $amount_receive,
            $sales_balance,
            $sale_id
        ]);

        if ($update) {
            $this->changeSaleStatus($sale_id, $status = 'paid');


            $sale_items = $this->getSale($sale_id);
            foreach ($sale_items['items'] as $sale_item) {
                $this->updateProductStock($sale_item['product_id'], $sale_item['quantity']);
            }
        }
    }

    // Get sale by ID
    public function getSale($sale_id)
    {
        $sql = "SELECT * FROM {$this->salesTable} WHERE id = ?";
        $sale = $this->conn->fetch($sql, [$sale_id]);

        if ($sale) {
            $sql = "
            SELECT 
                si.*, 
                p.name AS product_name,
                p.price AS product_price,
                p.category_id,
                p.brand_id,
                c.name AS category
            FROM {$this->saleItemsTable} si
            LEFT JOIN products p ON si.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE si.sale_id = ?
        ";
            $items = $this->conn->fetchAll($sql, [$sale_id]);
            $sale['items'] = $items;
        }

        return $sale;
    }


    public function getAllSales()
    {
        $sql = "
        SELECT 
            s.id,
            s.payment_method,
            s.total_amount,
            s.sales_balance,
            s.amount_receive,
            s.status,
            s.reference,
            si.sale_id,
            s.created_at,
            SUM(si.quantity) AS total_items,
            SUM(si.price * si.quantity) AS total_amount
        FROM {$this->salesTable} s
        LEFT JOIN {$this->saleItemsTable} si ON s.id = si.sale_id
        GROUP BY s.id
        ORDER BY s.created_at DESC
    ";

        return $this->conn->fetchAll($sql);
    }


    public function getSalesSummary()
    {
        $sql = "
        SELECT 
            COUNT(DISTINCT s.id) AS total_transactions,
            SUM(si.quantity) AS total_items_sold,
            SUM(si.price * si.quantity) AS grand_total_sales
        FROM {$this->salesTable} s
        LEFT JOIN {$this->saleItemsTable} si ON s.id = si.sale_id
        WHERE s.status = 'paid'
    ";

        return $this->conn->fetch($sql);
    }

    public function getSalesSummaryByPaymentMethod()
    {
        $sql = "
        SELECT 
            SUM(total_amount) AS total_sales,
            SUM(CASE WHEN payment_method = 'cash' THEN total_amount ELSE 0 END) AS cash_sales,
            SUM(CASE WHEN payment_method = 'momo' THEN total_amount ELSE 0 END) AS momo_sales
        FROM {$this->salesTable}
        WHERE status = 'paid'
    ";

        return $this->conn->fetch($sql);
    }



    // Get sales by date range
    public function getSalesByDateRange($start_date, $end_date)
    {
        $sql = "SELECT * FROM {$this->salesTable} WHERE DATE(created_at) BETWEEN ? AND ?";
        return $this->conn->fetchAll($sql, [$start_date, $end_date]);
    }
}
