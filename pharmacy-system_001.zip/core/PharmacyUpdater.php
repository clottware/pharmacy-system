<?php
class PharmacyUpdater
{
    private $db;
    private $currentVersion = APP_VERSION; // Local version
    private $manifestUrl = 'https://demo.clottware.com/pms/updates/update.json';
    private $token = APP_UPDATE_TOKEN;

    public function __construct()
    {

        $this->db = Database::getInstance(); // Correct way to get the singleton instance
    }

    public function checkForUpdate()
    {
        $manifest = json_decode(file_get_contents($this->manifestUrl), true);
        if (version_compare($manifest['latest_version'], $this->currentVersion, '>')) {
            $res = ['status' => true, 'msg' => "Update available: " . $manifest['latest_version']];
        } else {
            $res = ['status' => false, 'msg' => "System is up to date: " . $manifest['latest_version']];
        }

        return $res;
    }

    public function downloadAndApplyUpdate()
    {
        $manifest = json_decode(file_get_contents($this->manifestUrl), true);
        $zipPath = __DIR__ . '/../update.zip';
        file_put_contents($zipPath, fopen($manifest['zip_url'], 'r'));

        if (isset($manifest['sql_script'])) {
            $runBackup = $this->backupWithPhp();
            $runMigration = $this->runSqlMigration($manifest['sql_script']);
            if (!$runBackup['status'] && !$runMigration['status']) {
                $res = ['status' => false, 'backup_r' => $runBackup['msg'], 'migrate_r' => $runMigration['msg']];
                return $res;
            }
        }

        $zip = new ZipArchive;
        if ($zip->open($zipPath) === TRUE) {
            $zip->extractTo(__DIR__ . '/../');
            $zip->close();

            $res = ['status' => true, 'msg' => "Files updated: " . $manifest['latest_version'], 'version' => $manifest['latest_version']];

            $this->updateLocalVersion($manifest['latest_version']);
        } else {
            $res = ['status' => false, 'msg' => "Failed to unzip update: "];
        }


        return $res;
        //
        //$this->updateLocalVersion($manifest['latest_version']);
    }

    public function backup()
    {
        try {
            // Attempt to get the database instance and check connection
            $db = Database::getInstance(); // This will throw if connection fails
        } catch (Exception $e) {
            return ['status' => false, 'msg' => "Database connection failed: " . $e->getMessage()];
        }

        $host = DB_HOST;
        $dbname = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASSWORD;
        $backupDir = __DIR__ . '/../backups/';
        $timestamp = date('Ymd_His');
        $backupFile = $backupDir . "pharmacy_backup_$timestamp.sql";

        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0777, true);
        }

        // Escape password for shell safety
        $passSafe = escapeshellarg($pass);

        $command = "mysqldump --user=$user --password=$passSafe --host=$host $dbname > $backupFile";
        exec($command, $output, $result);

        if ($result === 0) {
            $res = ['status' => true, 'msg' => "Backup created: $backupFile"];
        } else {
            $res = ['status' => false, 'msg' => "Backup failed", 'output' => $output];
        }

        return $res;
    }

    public function backupWithPhp()
    {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        if ($mysqli->connect_error) {
            return ['status' => false, 'msg' => "Database connection failed: " . $mysqli->connect_error];
        }

        $backupDir = __DIR__ . '/../backups/';
        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0777, true);
        }
        $timestamp = date('Ymd_His');
        $backupFile = $backupDir . "pharmacy_backup_$timestamp.sql";
        $handle = fopen($backupFile, 'w+');

        $tables = [];
        $result = $mysqli->query("SHOW TABLES");
        while ($row = $result->fetch_row()) {
            $tables[] = $row[0];
        }

        foreach ($tables as $table) {
            // Get CREATE TABLE statement
            $res = $mysqli->query("SHOW CREATE TABLE `$table`");
            $row = $res->fetch_row();
            fwrite($handle, $row[1] . ";\n\n");

            // Get table data
            $res = $mysqli->query("SELECT * FROM `$table`");
            while ($data = $res->fetch_assoc()) {
                $vals = array_map([$mysqli, 'real_escape_string'], array_values($data));
                $vals = "'" . implode("','", $vals) . "'";
                fwrite($handle, "INSERT INTO `$table` VALUES ($vals);\n");
            }
            fwrite($handle, "\n");
        }

        fclose($handle);
        $mysqli->close();

        return ['status' => true, 'msg' => "Backup created: $backupFile"];
    }

    private function runSqlMigration($sqlFile)
    {
        // $sqlPath = __DIR__ . '/../database/' . $sqlFile;
        // if (!file_exists($sqlPath)) {
        //     $res = ['status' => false, 'msg' => "SQL file not found: $sqlFile"];
        // }

        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        if ($mysqli->connect_error) {
            return ['status' => false, 'msg' => "Database connection failed: " . $mysqli->connect_error];
        }

        $sql = file_get_contents($sqlFile);
        $sql = preg_replace('/--.*\n/', '', $sql); //


        if (!$mysqli->multi_query($sql)) {
            $res = ['status' => false, 'msg' => "Migration failed: " . $mysqli->error];
            $mysqli->close();
            return $res;
        }
        do {
            // flush results for multi_query
            if ($result = $mysqli->store_result()) {
                $result->free();
            }
        } while ($mysqli->more_results() && $mysqli->next_result());
        $mysqli->close();

        $res = ['status' => true, 'msg' => "Database updated"];
        return $res;
    }

    private function updateLocalVersion($newVersion)
    {
        file_put_contents(__DIR__ . '/../updates/version.txt', $newVersion);
        $res = ['status' => true, 'msg' => "Version updated to $newVersion\n"];
        return $res;
    }
}
