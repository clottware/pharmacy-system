<?php
// core/Utils.php

class Utils
{
    // Sanitize input
    public static function sanitize($data)
    {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }

    // Redirect to another page
    public static function redirect($url)
    {
        header("Location: $url");
        exit;
    }

    // Generate a random string (for tokens, etc.)
    public static function randomString($length = 32)
    {
        return bin2hex(random_bytes($length / 2));
    }

    // Format date
    public static function formatDate($date, $format = 'Y-m-d H:i:s')
    {
        return date($format, strtotime($date));
    }

    // Show pretty array for debugging
    public static function dd($data)
    {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
        exit;
    }

    // Check if request is POST
    public static function isPost()
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }

    // Check if request is GET
    public static function isGet()
    {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }

    // Return JSON response
    public static function jsonResponse($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    // Slugify a string (e.g., for URLs)
    public static function slugify($text)
    {
        // replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);

        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        // trim
        $text = trim($text, '-');

        // remove duplicate -
        $text = preg_replace('~-+~', '-', $text);

        // lowercase
        return strtolower($text);
    }

    public static function numToString($num)
    {
        return str_replace(',', '', $num); // Result: "1000.00"

    }
}
