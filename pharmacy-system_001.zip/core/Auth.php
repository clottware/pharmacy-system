<?php

/**
 * Auth Class
 * 
 * Handles user authentication
 * Depends on: core/Database.php
 */

require_once __DIR__ . '/Database.php';

class Auth
{
    private $db;
    private $sessionKey = "user_id";

    public function __construct()
    {
        session_start();
        $this->db = Database::getInstance(); // Correct way to get the singleton instance
    }



    public function login($username, $password, $rememberMe = false)
    {
        $sql = "SELECT * FROM users WHERE username = ?";
        $user = $this->db->fetch($sql, [$username]);

        if (!$user) {
            return ["success" => false, "message" => "User not found"];
        }

        if (!password_verify($password, $user['password'])) {
            return ["success" => false, "message" => "Incorrect password"];
        }

        // Set cookie for "remember me"
        if ($rememberMe) {
            $token = bin2hex(random_bytes(32)); // Generate a secure token
            $sql = "UPDATE users SET remember_token = ? WHERE id = ?";
            if ($this->db->update($sql, [$token, $user['id']])) {
                // Store token in cookie
                setcookie("remember_token", $token, time() + (86400 * 30), "/"); // 30 days
            }
        }

        $_SESSION[$this->sessionKey] = $user['id'];
        return ["success" => true, "message" => "Login successful"];
    }

    public function logout()
    {
        // Remove token from database if user is logged in
        if ($this->isLoggedIn()) {
            $sql = "UPDATE users SET remember_token = NULL WHERE id = ?";
            if ($this->db->update($sql, [$_SESSION[$this->sessionKey]])) {
                // Remove cookie
                setcookie("remember_token", "", time() - 3600, "/"); // Expire the cookie
            }
        }
        unset($_SESSION[$this->sessionKey]);
        session_destroy();
        return true;
    }

    public function isLoggedIn()
    {
        return isset($_SESSION[$this->sessionKey]);
    }

    public function currentUser()
    {
        if (!$this->isLoggedIn()) return null;

        $sql = "SELECT * FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$_SESSION[$this->sessionKey]]);
    }

    public function register($username, $email, $password)
    {
        // Check if user exists
        $exists = $this->db->fetch("SELECT id FROM users WHERE username = ? OR email = ?", [$username, $email]);
        if ($exists) {
            return ["success" => false, "message" => "Username or Email already exists"];
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";

        if ($this->db->query($sql, [$username, $email, $hashedPassword])) {
            return ["success" => true, "message" => "User registered successfully"];
        }

        return ["success" => false, "message" => "Registration failed"];
    }

    public function checkRememberedUser()
    {
        if ($this->isLoggedIn()) return true;

        if (isset($_COOKIE['remember_token'])) {
            $token = $_COOKIE['remember_token'];
            $sql = "SELECT * FROM users WHERE remember_token = ? LIMIT 1";
            $user = $this->db->fetch($sql, [$token]);

            if ($user) {
                $_SESSION[$this->sessionKey] = $user['id'];
                return true;
            }
        }
    }

    public function updateProfile($first_name, $last_name, $username, $phone, $email)
    {
        $userId = $_SESSION[$this->sessionKey] ?? null;

        if (!$userId) {
            return false; // user not logged in
        }

        $sql = "UPDATE users 
            SET first_name = ?, 
                last_name = ?, 
                username = ?, 
                phone_number = ?, 
                email = ?
            WHERE id = ?";

        return $this->db->update($sql, [
            $first_name,
            $last_name,
            $username,
            $phone,
            $email,
            $userId
        ]);
    }

    public function changePassword($currentPassword, $newPassword): array
    {
        $userId = $_SESSION[$this->sessionKey];

        // Get current hashed password
        $sql = "SELECT password FROM users WHERE id = ?";
        $user = $this->db->fetch($sql, [$userId]);

        if (!$user || !password_verify($currentPassword, $user['password'])) {
            return ['status' => false, 'message' => 'Current password is incorrect.'];
        }

        // Hash new password
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update password & timestamp
        $sql = "UPDATE users SET password = ?, last_password_change = NOW() WHERE id = ?";
        $updated = $this->db->update($sql, [$newHash, $userId]);

        if ($updated) {
            return ['status' => true, 'message' => 'Password updated successfully.'];
        }

        return ['status' => false, 'message' => 'Failed to update password.'];
    }

    public function restPassword($password, $email): array
    {
        // Get current hashed password
        $sql = "SELECT password FROM users WHERE email = ?";
        $user = $this->db->fetch($sql, [$email]);

        // Hash new password [Password233]
        $newHash = password_hash(DEFAULT_PASSWORD, PASSWORD_DEFAULT);

        // Update password & timestamp
        $sql = "UPDATE users SET password = ?, last_password_change = NOW() WHERE email = ?";
        $updated = $this->db->update($sql, [$newHash, $email]);

        if ($updated) {
            return ['status' => true, 'message' => 'Password updated successfully.'];
        }

        return ['status' => false, 'message' => 'Failed to update password.'];
    }

    public function getAllUsers(): array
    {
        $sql = "SELECT id, first_name, last_name, username, email, phone_number, role, created_at FROM users";
        return $this->db->fetchAll($sql);
    }

    public function getUserById($id)
    {
        $sql = "SELECT id, first_name, last_name, username, email, phone_number, role, created_at FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    public function getUserByEmail($email)
    {
        $sql = "SELECT id,username, email FROM users WHERE email = ?";
        return $this->db->fetch($sql, [$email]);
    }
}
