<?php

class DosageForm
{
    private $conn;
    private $table = "dosage_forms"; // table name in DB

    public function __construct()
    {
        $this->conn = Database::getInstance();
    }

    // Add new dosage form
    public function addDosageForm(string $dosageForm): ?int
    {
        // Check if dosage form already exists
        if ($this->dosageFormExists($dosageForm)) {
            return null; // Dosage form already exists, return null
        }
        $sql = "INSERT INTO {$this->table} (name) VALUES (?)";

        if ($this->conn->insert($sql, [$dosageForm])) {
            return $this->conn->insertId(); // Return new dosage form ID
        }

        return null; // Insert failed
    }

    // Update dosage form
    public function updateDosageForm(int $id, string $dosageForm): bool
    {
        // Check if dosage form already exists
        if ($this->dosageFormExists($dosageForm)) {
            return false; // DosageForm already exists, return false
        }
        $sql = "UPDATE {$this->table} SET name = ? WHERE id = ?";
        return $this->conn->update($sql, [$dosageForm, $id]);
    }

    public function deleteDosageForm(int $id): bool
    {
        // Check if brands exists
        if (!$this->getDosageFormById($id)) {
            return false; // DosageForm does not exist, return false
        }
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->conn->delete($sql, [$id]);
    }

    public function getDosageForm(): array
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY created_at DESC";
        return $this->conn->fetchAll($sql);
    }

    public function getDosageFormById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        return $this->conn->fetch($sql, [$id]);
    }
    public function dosageFormExists(string $dosageForm): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE name = ?";
        $result = $this->conn->fetch($sql, [$dosageForm]);
        return $result['count'] > 0;
    }
}
