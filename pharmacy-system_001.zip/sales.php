
<?php require 'config/session.php'; ?>
<?php
customHead($content = [
    "<link rel='stylesheet' href='assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'>"
]);
?>
<?php include 'head.php'; ?>
<?php include 'components/sidebar.php'; ?>
<?php include 'components/header.php'; ?>


<?php if (!isset($_GET['action']) || (isset($_GET['action']) && $_GET['action'] === 'all')): ?>
<?php include 'views/sales-lists.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'filter')): ?>
<?php include 'views/sales-lists.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'add')): ?>
<?php include 'views/sales-action.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'edit')): ?>
<?php include 'views/sales-action.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'view')): ?>
<?php include 'views/sales-view.php'; ?>
<?php endif; ?>

<?php
customFooter([
    "<script src='assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js'></script>"
]);
?>
<?php require 'components/footer.php'; ?>