<?php

/**
 * Log Class
 * 
 * Logs system activities and errors into daily log files.
 */

class Log
{
    private string $logDir;

    public function __construct(string $logDir = __DIR__ . '/../logs')
    {
        $this->logDir = rtrim($logDir, '/');

        if (!is_dir($this->logDir)) {
            mkdir($this->logDir, 0777, true); // create directory if not exists
        }
    }

    /**
     * Write an entry to the log file
     */
    public function write(string $message, string $type = 'INFO'): bool
    {
        $date = date("Y-m-d");
        $time = date("H:i:s");
        $file = "{$this->logDir}/{$date}.log";

        $logEntry = "[{$time}] [{$type}] {$message}" . PHP_EOL;

        return file_put_contents($file, $logEntry, FILE_APPEND | LOCK_EX) !== false;
    }

    /**
     * Shortcut for error logs
     */
    public function error(string $message): bool
    {
        return $this->write($message, 'ERROR');
    }

    /**
     * Shortcut for activity logs
     */
    public function activity(string $message): bool
    {
        return $this->write($message, 'ACTIVITY');
    }
}
