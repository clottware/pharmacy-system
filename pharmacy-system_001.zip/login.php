<?php
require_once __DIR__ . '/config/config.php';
print_r($auth->checkRememberedUser()); // Debugging line to check if $auth is initialized correctly
if ($auth->checkRememberedUser()) {
    header('Location: index');
    exit;
}
include_once __DIR__ . '/functions.php';
?>
<!-- IT WILL MAKE SENSE SOON -->
<!DOCTYPE html>
<html lang="en">

<head>
    <?= getHeadContent("Login - Clottware Pharmacy"); ?>
</head>

<body class="account-page" style="height:100vh;">
    <!-- Main Wrapper -->
    <div class="main-wrapper">
        <div class="account-content">
            <div class="login-wrapper bg-img">
                <div class="login-content authent-content">
                    <form id="loginForm" autocomplete="on">
                        <div class="login-userset">
                            <div class="login-logo logo-normal">
                                <img src="assets/img/logo.svg" alt="img">
                            </div>
                            <a href="index.html" class="login-logo logo-white">
                                <img src="assets/img/logo-white.svg" alt="Img">
                            </a>
                            <div class="login-userheading">
                                <h3>Sign In</h3>
                                <h4 class="fs-15">Welcome Back</h4>
                            </div>
                            <?php if (isset($_GET['error'])): ?>
                                <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
                            <?php endif; ?>
                            <div id="loginResponse"></div>
                            <div class="mb-3">
                                <label class="form-label">Username <span class="text-danger"> *</span></label>
                                <div class="input-group">
                                    <input type="text" name="username" autocomplete="username" required autofocus class="form-control">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password <span class="text-danger"> *</span></label>
                                <div class="pass-group">
                                    <input type="password" class="pass-input form-control" autocomplete="current-password" name="password" required>
                                    <span class="ti toggle-password ti-eye-off text-gray-9"></span>
                                </div>
                            </div>
                            <div class="form-login authentication-check">
                                <div class="row">
                                    <div class="col-12 d-flex align-items-center justify-content-between">
                                        <div class="custom-control custom-checkbox">
                                            <label class="checkboxs ps-4 mb-0 pb-0 line-height-1 fs-16 text-gray-6">
                                                <input type="checkbox" name="remember_me" class="form-control">
                                                <span class="checkmarks"></span>Remember me
                                            </label>
                                        </div>
                                        <div class="text-end">
                                            <a class="text-orange fs-16 fw-medium" href="forgot-password">Forgot Password?</a>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="form-login">
                                <?php echo renderSubmitButton('Login', 'loginBtn', 'w-100'); ?>
                            </div>
                            <div class="my-4 d-flex justify-content-center align-items-center copyright-text">
                                <p>Copyright &copy; 2025 Clottware</p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Feather Icon JS -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/plugins/sweetalert2/sweetalert2.all.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/main.js?v=<?= time(); ?>"></script>
</body>

</html>