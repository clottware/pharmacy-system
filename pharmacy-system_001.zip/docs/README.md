<!-- @format -->

# 💊 Clottware Pharmacy Management System

A local-first pharmacy management system developed with HTML, CSS, Bootstrap 5, PHP, jQuery, and MySQL. Designed to run offline but smart enough to check for updates and news when online.

---

## 📋 Overview

- **Developer**: Clottware
- **Stack**: HTML, CSS, Bootstrap 5, PHP (7.4+), jQuery, MySQL
- **Mode**: Offline-first with optional online enhancements
- **Version**: 0.1.0
- **License**: Freemium (Core features are free, some features require premium access)

---

## 📦 Core Features

- Inventory & Stock Management
- POS Sales System
- Supplier Records
- Customer Profiles
- Sales Reports & Alerts
- Admin/Staff User System
- Update Checker (when online)
- Premium Features (optional)

---

## 🚀 Getting Started

1. Clone or download this repository.
2. Import the database from `docs/database-schema.sql`.
3. Update your local server credentials in `config/db.php`.
4. Launch `index.php` from your localhost server (e.g., XAMPP).

---

## 📚 Documentation

- **Folder Structure**: [`docs/structure.md`](structure.md)
- **Database Schema**: [`docs/database-schema.sql`](database-schema.sql)
- **Tech Reference**: PHP 7.4+, jQuery 3.x, Bootstrap 5.3+

---

## 🛠 Premium Roadmap

- Cloud sync and remote backup
- Export to Excel & PDF
- Real-time pharmacy news feed
- WhatsApp Integration

---
