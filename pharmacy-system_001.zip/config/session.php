<?php
//include config file
include_once __DIR__ . '/config.php';
if (!$auth->checkRememberedUser()) {
    header('Location: login');
    exit;
}

// Password reset alert
$user = $auth->currentUser();
$restPass = false;
if ($user && password_verify(DEFAULT_PASSWORD, $user['password'])) {
    $restPass = true;
}

// check if session is valid

// Optional: restrict roles
// if ($_SESSION['user']['role'] !== 'admin') {
//     header('Location: unauthorized.php');
//     exit;
// }
