<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

if (Utils::isPost()) {
    $startDate = $_POST['start'] ?? null;
    $endDate = $_POST['end'] ?? null;

    if (!$startDate || !$endDate) {
        echo json_encode([
            'status' => false,
            'message' => 'Start and end dates are required.'
        ]);
        exit;
    }

    $analytics = new Analytics();

    // Get current period sales summary
    $summary = $analytics->getSalesByDateRange($startDate, $endDate);

    // Optional: Compare with previous period
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $interval = $start->diff($end);

    $previousStart = $start->sub($interval)->format('Y-m-d');
    $previousEnd = $end->sub($interval)->format('Y-m-d');

    $comparison = $analytics->compareSales($startDate, $endDate, $previousStart, $previousEnd);

    echo json_encode([
        'status' => true,
        'data' => [
            'total_sales' => number_format($summary['total_sales'] ?? 0, 2),
            'total_transactions' => $summary['total_transactions'] ?? 0,
            'comparison' => $comparison
        ]
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
