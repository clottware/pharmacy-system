<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

if (Utils::isPost()) {
    $updater = new PharmacyUpdater();
    $settings = new Settings();
    $checkUpdate = $updater->checkForUpdate();

    if (isset($_POST['updateCheck'])) {
        if ($checkUpdate['status']) {
            $settings->set('update', 'true');
            echo Utils::jsonResponse(['status' => true, 'message' => $checkUpdate['msg']], 200);
        } else {
            $settings->set('update', 'false');
            echo Utils::jsonResponse(['status' => false, 'message' => $checkUpdate['msg']], 200);
        }
    }

    if (isset($_POST['download'])) {
        if ($checkUpdate['status']) {
            $download = $updater->downloadAndApplyUpdate();

            if ($download['status']) {
                $settings->set('update', 'false');
                $settings->set('app_version', $download['version']);
                echo Utils::jsonResponse(['status' => true, 'message' => $download['msg']], 200);
            } else {
                echo Utils::jsonResponse(['status' => false, 'message' => $download['msg']], 200);
            }
        }
    }
}
