<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $category = Utils::sanitize($_POST['category'] ?? '');
    $category_type = Utils::sanitize($_POST['category_type'] ?? '');
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : null;

    // Validate input
    if (!in_array($category_type, ['new', 'edit', 'delete'])) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid category type.'], 400);
        exit;
    }

    $categoryModel = new Category();

    if ($category_type === 'new') {
        if (empty($category)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Category name is required.'], 200);
            exit;
        }
        $result = $categoryModel->addCategory($category);
        $category_id = $result; // Get the ID of the newly created category
    }

    if ($category_type === 'edit') {
        // Ensure category_id is provided for editing
        if (empty($category)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Category name is required.'], 200);
            exit;
        }
        if (!$category_id) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Category ID is required for editing.'], 400);
            exit;
        }
        $result = $categoryModel->updateCategory($category_id, $category);
    }

    if ($category_type === 'delete') {
        // Ensure category_id is provided for deletion
        if (!$category_id) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Category ID is required for deletion.'], 400);
            exit;
        }
        $result = $categoryModel->deleteCategory($category_id);
    }

    if ($result) {
        echo Utils::jsonResponse(['status' => true, 'message' => 'Category saved successfully.', 'categories' => ['category_id' => $category_id, 'category' => $category]], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Category already exists.'], 200);
    }
} elseif (Utils::isGet()) {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $categoryModel = new Category();

    if ($id) {
        $category = $categoryModel->getCategoryById($id);
        echo Utils::jsonResponse(['status' => true, 'data' => $category], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid category ID.'], 400);
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
