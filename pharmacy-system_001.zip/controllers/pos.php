<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {

    if (isset($_POST['action']) && $_POST['action'] === 'new') {
        $productModel = new Product();
        $sales = new Sales();
        $id = $_POST['item_id'] ?? '';
        $qty = $_POST['item_qty'] ?? '';
        $price = $_POST['item_price'] ?? '';
        $payment_method = Utils::sanitize($_POST['payment-item'] ?? '');


        if (empty($id) && (empty($qty))) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Something Went wrong. Try Again.'], 200);
            return;
        }

        if (empty($payment_method)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Choose a payment method.'], 200);
            return;
        }

        $sales_person = $auth->currentUser();

        if ($sales_person) {
            $staff_id = $sales_person['id'];
            $getProduct = $productModel->getProductById($id);

            $items = [];
            for ($i = 0; $i < count($id); $i++) {
                $items[] = [
                    'id' => $id[$i],
                    'quantity' => $qty[$i],
                    'price' => $price[$i]
                ];
            }


            $reference = 'CTW' . Utils::randomString(4);

            $ns = $sales->createSale($staff_id, $payment_method, $reference, $items);

            if ($ns['status']) {
                echo Utils::jsonResponse(['status' => true, 'message' => 'Sales created successfully', 'data' => ['sale_id' => $ns['sale_id'], 'total_price' => number_format($ns['total'], 2), 'payment_method' => $payment_method]], 200);
                return;
            }
        } else {
            if ($auth->logout()) {
                Utils::redirect('login');
                exit;
            }
        }
    }

    if (isset($_POST['action']) && $_POST['action'] === 'cancel') {
        $sales = new Sales();
        $salesId = Utils::sanitize($_POST['cancel_order_id'] ?? '');

        if (empty($salesId)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Something Went wrong. Try Again.'], 200);
            return;
        }

        $sales->changeSaleStatus($salesId, 'canceled');
        echo Utils::jsonResponse(['status' => true, 'message' => 'Order cancelled'], 200);
        return;
    }

    if (isset($_POST['action']) && $_POST['action'] === 'confirm') {
        $sales = new Sales();
        $sale_id = Utils::sanitize($_POST['sales_id'] ?? '');
        $amount_receive = Utils::numToString($_POST['receive_amount'] ?? '');
        $total_amount = Utils::numToString($_POST['payment_amount'] ?? '');
        $sales_balance = Utils::numToString($_POST['sale_change'] ?? '');
        $payment_method = Utils::sanitize($_POST['payment_method'] ?? '');

        if (empty($sale_id)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Something Went wrong. Try Again.'], 200);
            return;
        }

        $sales->updateSales($sale_id, $payment_method, $total_amount, $amount_receive, $sales_balance);
        echo Utils::jsonResponse(['status' => true, 'message' => 'Order #' . $sale_id . ' completed'], 200);
        return;
    }
}

if (Utils::isGet()) {
    if (isset($_GET['product_id'])) {
        $productModel = new Product();
        $id = Utils::sanitize($_GET['product_id'] ?? '');
        $qty = Utils::sanitize($_GET['qty'] ?? '');

        if (empty($id) && $qty === 0) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Something Went wrong. Try Again.'], 200);
            return;
        }

        $getProduct = $productModel->getProductById($id);

        if ($getProduct) {

            if ($qty > $getProduct['quantity']) {
                echo Utils::jsonResponse(['status' => false, 'message' => $getProduct['name'] . ' is out of stock.'], 200);
                return;
            }

            echo Utils::jsonResponse(['status' => true, 'message' => 'Product added successfully', 'data' => ['name' => $getProduct['name'], 'price' => $getProduct['price'], 'id' => $getProduct['id'], 'sales_qty' => $qty, 'product_qty' => $getProduct['quantity'], 'currencySymbol' => $settings->get('currency_symbol')]], 200);
            return;
        }
    }

    if (isset($_GET['getSales'])) {
        $sales = new Sales();
        $id = Utils::sanitize($_GET['id'] ?? '');

        if (empty($id)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Something Went wrong. Try Again.'], 200);
            return;
        }

        $getSales = $sales->getSale($id);
        echo Utils::jsonResponse(['status' => true, 'message' => 'Product added successfully', 'data' => $getSales], 200);
        return;
    }
}
