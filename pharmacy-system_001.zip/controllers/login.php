<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $username = Utils::sanitize($_POST['username'] ?? '');
    $password = Utils::sanitize($_POST['password'] ?? '');
    $rememberMe = isset($_POST['remember_me']) ? true : false;

    // Validate input
    if (empty($username) || empty($password)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Username and password are required.'], 400);
    }

    // Authenticate user
    $user = $auth->login($username, $password);

    if ($user['success'] && $auth->isLoggedIn()) {
        // Handle "Remember Me" functionality
        if ($rememberMe) {
            setcookie('username', $username, time() + (86400 * 30), "/"); // 30 days
        }

        echo Utils::jsonResponse(['status' => true, 'message' => 'Login successful. Redirecting...'], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => $user['message']], 401);
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
