<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $email = Utils::sanitize($_POST['email'] ?? '');

    // Validate input
    if (empty($email)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Field is required.'], 400);
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid email address.'], 400);
        exit;
    }

    // Authenticate user
    $getUser = $auth->getUserByEmail($email);
    if ($getUser) {
        // Reset Password
        $rest = $auth->restPassword(DEFAULT_PASSWORD, $email);
        if ($rest) {
            echo Utils::jsonResponse(['status' => true, 'message' => 'User Password Reset Ini.'], 200);
        } else {
            echo Utils::jsonResponse(['status' => false, 'message' => 'User Password Reset Ini.'], 200);
        }
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'User Password Reset Ini.'], 200);
    }
} else if (Utils::isGet()) {
    $email = Utils::sanitize($_GET['email'] ?? '');
    // Validate input
    if (empty($email)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Field is required.'], 400);
    }

    $getUser = $auth->getUserByEmail($email);
    if ($getUser) {
        echo Utils::jsonResponse(['status' => true, 'message' => 'User Password Reset Ini.'], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'User Password Reset Ini.'], 200);
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
