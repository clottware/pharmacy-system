<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Security</h4>
    </div>
    <div class="card-body">
        <div>
            <div class="d-flex align-items-center justify-content-between flex-wrap row-gap-3 border-bottom mb-3 pb-3">
                <div class="d-flex align-items-center">
                    <span class="avatar avatar-lg border bg-light fs-24 me-2">
                        <i class="ti ti-eye-off text-gray-900 fs-18"></i>
                    </span>
                    <?php
                    if ($auth->currentUser() != null) {
                        $user = $auth->currentUser();
                    } ?>
                    <div>
                        <h5 class="fs-16 fw-medium mb-1">
                            Password
                        </h5>
                        <p class="fs-14">Last Changed <?= date($settings->get('date_format_time'), strtotime($user['last_password_change'])) ?></p>
                    </div>
                </div>
                <a href="javascript:void(0);" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#change-password">Change Password</a>
            </div>
        </div>
    </div>
</div>

<?php

function pageModal()
{
    ob_start();
?>
    <!-- Change Password -->
    <div class="modal fade" id="change-password">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="page-title">
                        <h4>Change Password</h4>
                    </div>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="changePasswordForm" autocomplete="off" method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="formResponse"></div>
                            </div>
                            <div class="col-lg-12">
                                <div class="input-blocks">
                                    <label class="fw-medium">Current Password <span class="text-danger">*</span></label>
                                    <div class="pass-group">
                                        <input type="text" autocomplete="current-password" name="current_password" class="form-control settings-pass-input">
                                        <span class="toggle-password ti fa-eye fa-eye-slash ti-eye"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="input-blocks">
                                    <label class="fw-medium">New Password <span class="text-danger">*</span></label>
                                    <div class="pass-group" id="passwordInput">
                                        <input type="password" autocomplete="new-password" name="new_password" class="form-control settings-pass-inputs">
                                        <span class="toggle-passwords ti ti-eye-off"></span>
                                        <span class="pass-checked"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="input-blocks mb-0">
                                    <label class="fw-medium">Confirm Password <span class="text-danger">*</span></label>
                                    <div class="pass-group">
                                        <input type="password" autocomplete="current-password" name="confirm_password" class="form-control settings-pass-inputa">
                                        <span class="toggle-passworda ti ti-eye-off"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:void(0);" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</a>
                        <?php echo renderSubmitButton('Save Changes', 'changePassword', ''); ?>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- /Change Password -->
<?php
    return ob_get_clean();
} ?>