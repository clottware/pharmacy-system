<?php
if ($auth->currentUser() != null) {
    $user = $auth->currentUser();
    $displayName = $user['first_name'] . ' ' . $user['last_name'];
} ?>
<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Profile</h4>
    </div>
    <div class="card-body">
        <form id="profileForm" action="controllers/update-profile" method="POST">
            <div class="card-title-head">
                <h6 class="fs-16 fw-bold mb-3">
                    <span class="fs-16 me-2"><i class="ti ti-user"></i></span>
                    Basic Information
                </h6>
            </div>
            <div class="profile-pic-upload mb-3 pb-2">
                <div class="profile-pic">
                    <img src="./assets/img/users/user-49.png" class="object-fit-cover h-100 rounded-1 avatar-profile" data-name="<?= htmlspecialchars($displayName) ?>" alt="<?= htmlspecialchars($displayName) ?>">
                </div>
                <div class="new-employee-field">
                    <div class="mb-0">
                        <div>
                            <h6 class="fw-medium"><?= htmlspecialchars($displayName) ?></h6>
                            <p>Role: <?= htmlspecialchars($user['role']) ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">
                            First Name <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">
                            Last Name <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">
                            Username <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']) ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">
                            Phone Number
                        </label>
                        <input type="text" class="form-control" name="phone_number" value="<?= htmlspecialchars($user['phone_number']) ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">
                            Email <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                </div>
            </div>
            <div class="text-end settings-bottom-btn mt-0">
                <button type="button" class="btn btn-secondary me-2" onclick="window.history.back();">Cancel</button>
                <?php echo renderSubmitButton('Save Changes', 'saveProfile', ''); ?>
            </div>
        </form>
    </div>
</div>

<?php
function pageModal()
{
    return null;
}
?>