<?php

/**
 * Product List View
 */

$productModel = new Product();
$categoryModel = new Category();
$brandModel = new Brands();
if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
    $products = $productModel->getProductsByCategory($_GET['category']);
} else {
    $products = $productModel->getAllProducts();
}
?>
<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold">Product List</h4>
            <h6>Manage your products</h6>
        </div>
    </div>
    <div class="page-btn">
        <a href="products?action=add" class="btn btn-primary"><i class="ti ti-circle-plus me-1"></i>Add Product</a>
    </div>
    <div class="page-btn import d-none">
        <a href="#" class="btn btn-secondary color" data-bs-toggle="modal" data-bs-target="#view-notes"><i
                data-feather="download" class="me-1"></i>Import Product</a>
    </div>
</div>

<!-- /product list -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
        <div class="search-set">
            <div class="search-input">
                <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
            </div>
        </div>
        <div class="d-flex table-dropdown my-xl-auto right-content align-items-center flex-wrap row-gap-3">
            <?php if (isset($_GET['action']) && $_GET['action'] === 'filter'): ?>
                <a href="products.php" class="btn btn-secondary me-2">Clear Filter</a>
            <?php endif; ?>
            <div class="dropdown me-2">
                <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                    Category
                </a>
                <ul class="dropdown-menu  dropdown-menu-end p-3">
                    <?php
                    $categories = $categoryModel->getCategories();
                    if ($categories):
                        foreach ($categories as $category):
                    ?>
                            <li>
                                <a href="products.php?action=filter&category=<?= htmlspecialchars($category['id']) ?>" class="dropdown-item rounded-1"><?= htmlspecialchars($category['name']) ?></a>
                            </li>
                    <?php
                        endforeach;
                    endif;
                    ?>
            </div>
            <?php
            $brands = $brandModel->getBrands();
            if ($brands):
            ?>
                <div class="dropdown">
                    <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                        Brand
                    </a>
                    <ul class="dropdown-menu  dropdown-menu-end p-3">
                        <?php
                        foreach ($brands as $brand):
                        ?>
                            <li>
                                <a href="javascript:void(0);" class="dropdown-item rounded-1"><?= htmlspecialchars($brand['name']) ?></a>
                            </li>
                        <?php
                        endforeach;

                        ?>
                    </ul>
                </div>
            <?php
            endif;
            ?>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table datatable">
                <thead class="thead-light">
                    <tr>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Created By</th>
                        <th class="no-sort"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($products):
                        foreach ($products as $product):
                            $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                            $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                    ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="action=view&id=<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></a>
                                    </div>
                                </td>
                                <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                <td><?= intval($product['quantity']) ?></td>
                                <td><?= date($settings->get('date_format'), strtotime($product['created_at'])) ?></td>
                                <td class="action-table-data">
                                    <div class="edit-delete-action">
                                        <a class="me-2 edit-icon  p-2" href="?action=view&id=<?= $product['id'] ?>">
                                            <i data-feather="eye" class="feather-eye"></i>
                                        </a>
                                        <a class="me-2 p-2" href="?action=edit&id=<?= $product['id'] ?>">
                                            <i data-feather="edit" class="feather-edit"></i>
                                        </a>
                                        <a data-bs-toggle="modal" data-bs-target="#delete-modal" class="p-2" href="javascript:void(0);">
                                            <i data-feather="trash-2" class="feather-trash-2"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /product list -->

<!-- /Main Wrapper -->

<?php
function pageModal()
{
    ob_start();
?>
    <!-- Import Product -->
    <div class="modal fade" id="view-notes">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="page-wrapper-new p-0">
                    <div class="content">
                        <div class="modal-header">
                            <div class="page-title">
                                <h4>Import Product</h4>
                            </div>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="product-list.html">

                                <div class="row">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label>Product<span class="ms-1 text-danger">*</span></label>
                                            <select class="select">
                                                <option>Select</option>
                                                <option>Bold V3.2</option>
                                                <option>Nike Jordan</option>
                                                <option>Iphone 14 Pro</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label>Category<span class="ms-1 text-danger">*</span></label>
                                            <select class="select">
                                                <option>Select</option>
                                                <option>Laptop</option>
                                                <option>Electronics</option>
                                                <option>Shoe</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label>Sub Category<span class="ms-1 text-danger">*</span></label>
                                            <select class="select">
                                                <option>Select</option>
                                                <option>Lenovo</option>
                                                <option>Bolt</option>
                                                <option>Nike</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-sm-6 col-12">
                                        <div class="row">
                                            <div>
                                                <div class="modal-footer-btn download-file">
                                                    <a href="javascript:void(0)" class="btn btn-submit">Download Sample File</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="mb-3 image-upload-down">
                                            <label class="form-label">Upload CSV File</label>
                                            <div class="image-upload download">
                                                <input type="file">
                                                <div class="image-uploads">
                                                    <img src="assets/img/download-img.png" alt="img">
                                                    <h4>Drag and drop a <span>file to upload</span></h4>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Created by<span class="ms-1 text-danger">*</span></label>
                                            <input type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3 mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea class="form-control"></textarea>
                                            <p class="mt-1">Maximum 60 Characters</p>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn me-2 btn-secondary fs-13 fw-medium p-2 px-3 shadow-none" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary fs-13 fw-medium p-2 px-3">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Import Product -->

    <!-- delete modal -->
    <?php echo confirmationModal('Delete Product', 'Are you sure you want to delete this product?', 'Yes Delete', 'Cancel'); ?>
    <!-- /delete modal -->
<?php
}
?>