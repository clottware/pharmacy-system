<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Company Settings</h4>
    </div>
    <div class="card-body">
        <form id="companySettingsForm" action="company-settings" method="POST">
            <div class="border-bottom mb-3">
                <div class="card-title-head">
                    <h6 class="fs-16 fw-bold mb-2">
                        <span class="fs-16 me-2"><i class="ti ti-building"></i></span>
                        Company Information
                    </h6>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-6 col-md-4">
                        <div class="mb-3">
                            <label class="form-label">
                                Company Name <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="company_name" value="<?= $settings->get('site_name') ?>" required>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-4">
                        <div class="mb-3">
                            <label class="form-label">
                                Company Email Address
                            </label>
                            <input type="email" class="form-control" name="company_email" value="<?= $settings->get('site_email') ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">
                                Phone Number
                            </label>
                            <input type="text" class="form-control" name="company_phone" value="<?= $settings->get('phone') ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">
                                Fax
                            </label>
                            <input type="text" class="form-control" name="company_fax" value="<?= $settings->get('fax') ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">
                                Website
                            </label>
                            <input type="text" class="form-control" name="company_website" value="<?= $settings->get('website') ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="company-address">
                <div class="card-title-head">
                    <h6 class="fs-16 fw-bold mb-2">
                        <span class="fs-16 me-2"><i class="ti ti-map-pin"></i></span>
                        Address Information
                    </h6>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label class="form-label">
                                Address
                            </label>
                            <input type="text" class="form-control" name="company_address" value="<?= $settings->get('address') ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-end settings-bottom-btn mt-0">
                <?php echo renderSubmitButton('Save Changes', 'saveCompanySettings', ''); ?>
            </div>
        </form>
    </div>
</div>

<?php
function pageModal()
{
    return null;
}
?>