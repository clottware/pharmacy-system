<?php

/**
 * Sales List View
 */

$sales = new Sales();
$sales = $sales->getAllSales();
?>
<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold">Sales List</h4>
            <h6>Manage your sales</h6>
        </div>
    </div>
    <div class="page-btn">
        <a href="pos" class="btn btn-primary"><i class="ti ti-circle-plus me-1"></i>Add Sale</a>
    </div>
    <div class="page-btn import d-none">
        <a href="#" class="btn btn-secondary color" data-bs-toggle="modal" data-bs-target="#view-notes"><i
                data-feather="download" class="me-1"></i>Import Product</a>
    </div>
</div>

<!-- /product list -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
        <div class="search-set">
            <div class="search-input">
                <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table datatable">
                <thead class="thead-light">
                    <tr>
                        <th>Id</th>
                        <th>Total Amount</th>
                        <th>Amount Received</th>
                        <th>Balance</th>
                        <th>Stats</th>
                        <th> Created at</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($sales):
                        foreach ($sales as $sale):
                    ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:void(0);" class="view-sales-details" data-id="<?= $sale['sale_id'] ?>"><?= $sale['reference']; ?></a>
                                    </div>
                                </td>
                                <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['total_amount'], 2) ?></td>
                                <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['amount_receive'], 2) ?></td>
                                <td><?= $settings->get('currency_symbol'); ?> <?= number_format($sale['sales_balance'], 2) ?></td>
                                <td><span class=""><?= $sale['status'] ?></span></td>
                                <td class=" action-table-data">
                                    <?= date($settings->get('date_format'), strtotime($sale['created_at'])) ?>
                                </td>
                            </tr>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /product list -->

<!-- /Main Wrapper -->

<?php
function pageModal()
{
    ob_start();
?>
    <?php $settings = new Settings(); ?>
    <!-- details popup -->
    <div class="modal fade" id="sales-details-new">
        <div class="modal-dialog sales-details-modal">
            <div class="modal-content">
                <div class="page-header p-4 border-bottom mb-0">
                    <div class="add-item d-flex align-items-center">
                        <div class="page-title modal-datail">
                            <h4 class="mb-0 me-2">Sales Detail</h4>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="card border-0">
                        <div class="card-body pb-0">
                            <div class="invoice-box table-height" style="max-width: 1600px;width:100%;padding: 0;font-size: 14px;line-height: 24px;color: #555;">
                                <div class="row sales-details-items d-flex">
                                    <div class="col-md-4 details-item">
                                        <h6>Invoice Info</h6>
                                        <p class="mb-0">Reference: <span class="fs-16 text-primary ms-2 sales-reference"></span></p>
                                        <p class="mb-0">date: <span class="ms-2 text-gray-9 sales-date"></span></p>
                                        <p class="mb-0">Method: <span class="ms-2 text-gray-9 sales-method"></span></p>
                                        <p class="mb-0">Status: <span class="badge ms-2 sales-status"></span></p>
                                    </div>
                                </div>
                                <h5 class="order-text">Order Summary</h5>
                                <div class="table-responsive no-pagination mb-3">
                                    <table class="table  datanew">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Category</th>
                                                <th>Purchase Price(<?= $settings->get('currency_symbol'); ?>)</th>
                                                <th>Quantity</th>
                                                <th>Total Cost(<?= $settings->get('currency_symbol'); ?>)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <a href="javascript:void(0);"></a>
                                                    </div>
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="row">

                                <div class="row">
                                    <div class="col-lg-6 ms-auto">
                                        <div class="total-order w-100 max-widthauto m-auto mb-4">
                                            <ul class="rounded-3">
                                                <li>
                                                    <h4>Grand Total</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-total"></span></h5>
                                                </li>
                                                <li>
                                                    <h4>Paid</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-paid"></span></h5>
                                                </li>
                                                <li>
                                                    <h4>Balance</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-due"></span></h5>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /details popup -->

    <!-- delete modal -->
    <?php echo confirmationModal('Delete Product', 'Are you sure you want to delete this product?', 'Yes Delete', 'Cancel'); ?>
    <!-- /delete modal -->
<?php
}
?>

<script>
    $(document).ready(function() {
        function number_format(number, decimals = 0, dec_point = '.', thousands_sep = ',') {
            number = parseFloat(number) || 0;
            return number.toLocaleString('en-US', {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            }).replace('.', dec_point).replace(/,/g, thousands_sep);
        }
        $('.view-sales-details').click(function(e) {
            e.preventDefault();
            let id = $(this).data('id');
            $('.sales-status').removeClass('badge-warning');
            $('.sales-status').removeClass('badge-danger');
            $('.sales-status').removeClass('badge-success');
            $.ajax({
                url: 'controllers/pos',
                method: 'GET',
                data: {
                    id: id,
                    getSales: true
                },
                dataType: "json",
                success: function(response) {
                    $('.sales-reference').html('#' + response.data.reference);
                    $('.sales-status').html(response.data.status);
                    $('.sales-total').html(number_format(response.data.total_amount, 2));
                    $('.sales-paid').html(number_format(response.data.amount_receive, 2));
                    $('.sales-due').html(number_format(response.data.sales_balance, 2));
                    $('.sales-method').html(response.data.payment_method);
                    const rawDate = response.data.created_at;
                    const dateObj = new Date(rawDate);

                    // Example: format as "04 Sep 2025, 2:08 PM"
                    const formatted = dateObj.toLocaleString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });

                    $('.sales-date').html(formatted);
                    if (response.data.status == 'pending') {
                        $('.sales-status').addClass('badge-warning')
                    }
                    if (response.data.status == 'paid') {
                        $('.sales-status').addClass('badge-success')
                    }
                    if (response.data.status == 'canceled') {
                        $('.sales-status').addClass('badge-danger')
                    }
                    const currencySymbol = '<?= $settings->get("currency_symbol"); ?>';
                    let html = '';

                    response.data.items.forEach(item => {
                        html += `<tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                    <a href="products?action=view&id=${item.product_id}">${item.product_name}</a>
                                    </div>
                                </td>
                                <td>${item.category}</td>
                                <td>${number_format(item.price, 2)}</td>
                                <td>${item.quantity}</td>
                                <td>${number_format(item.subtotal,2)}</td>
                                </tr>`;
                    });

                    $('.datanew tbody').html(html);
                    $('#sales-details-new').modal('show');
                }
            });
        });
    });
</script>