<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Clottware DrugStore </h4>
    </div>
    <div class="card-body">
        <div>
            <div class="d-flex align-items-center justify-content-between flex-wrap row-gap-3 border-bottom mb-3 pb-3">
                <div class="d-flex align-items-center">
                    <span class="avatar avatar-lg border bg-light fs-24 me-2">
                        <i class="ti ti-<?= $settings->get('update') == 'true' ? 'file-download-filled text-gray-900' : 'square-check-filled text-primary' ?> fs-21"></i>
                    </span>
                    <?php
                    if ($auth->currentUser() != null) {
                        $user = $auth->currentUser();
                    } ?>
                    <div>
                        <h5 class="fs-16 fw-medium mb-1 update-label"><?= $settings->get('update') == 'true' ? 'DrugStore update is available.' : 'DrugStore is up to date.' ?></h5>
                        <p class="fs-14">Version <?= $settings->get('app_version') ?></p>
                    </div>
                </div>
                <a href="javascript:void(0);" class="btn btn-primary" id="<?= $settings->get('update') == 'true' ? 'download' : 'appUpdate' ?>">
                    <i class="ti ti-<?= $settings->get('update') == 'true' ? 'download' : ' d-none' ?> fs-21"></i>
                    <?= $settings->get('update') == 'true' ? 'Download Update' : 'Check Update' ?>
                </a>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            },
        });

        // function to handle toaster
        function toaster(type, message) {
            Toast.fire({
                icon: type,
                title: message,
            });
        }

        function responseAction(action = true) {
            if (action) {


            }
        }

        $('body').on('click', '#appUpdate', function() {
            let $btn = $(this);
            $.ajax({
                type: "POST",
                url: "controllers/update",
                data: {
                    updateCheck: true
                },
                dataType: "json",
                beforeSend: function() {
                    $btn.prop('disabled', true);
                    $btn.addClass('disabled');
                },
                success: function(response) {
                    if (response.status) {
                        toaster('warning', response.message);
                        $('.update-label').html('DrugStore update is available.');
                        $btn.attr('id', 'download');
                        $btn.html('Download Update');

                    } else {
                        toaster('success', response.message);
                        $('.update-label').html('DrugStore is up to date.');
                    }
                    $btn.removeClass('disabled');
                    $btn.prop('disabled', false);
                },
                error: function(error) {
                    // Handle error
                    toaster('error', "Something went wrong. Please try again later.");
                }
            });
        });

        $('body').on('click', '#download', function() {
            let $btn = $(this);
            $('#updateGIF').attr('width', '200px');
            $('#updateGIF').attr('src', 'assets/img/update.gif');
            $('#updateModal').modal('show');
            $.ajax({
                type: "POST",
                url: "controllers/update",
                data: {
                    download: true
                },
                dataType: "json",
                beforeSend: function() {
                    $btn.prop('disabled', true);
                    $btn.addClass('disabled');
                },
                success: function(response) {
                    if (response.status) {
                        toaster('success', response.message);
                        $('.update-label').html('DrugStore is up to date.');
                        $('#updateGIF').attr('src', 'assets/img/icons/done-check.png');
                        $('#updateGIF').attr('width', '50px');
                        $('.update-title').html('Updated Successfully');
                        $('.update-desc').html('Clottware DrugStore was updated Successfully');
                        $btn.attr('id', 'appUpdate');
                        $btn.html('Check Update');

                    } else {
                        toaster('error', response.message);
                        $('#updateGIF').attr('src', 'assets/img/icons/error-check.png');
                        $('.update-title').html('An Error Occurred');
                        $('#updateGIF').attr('width', '50px');
                        $('.update-desc').html('An error occurred during the update. Try again.');
                    }
                    $btn.removeClass('disabled');
                    $btn.prop('disabled', false);
                    $('.modal-footer').show();
                },
                error: function(error) {
                    // Handle error
                    toaster('error', "Something went wrong. Please try again later.");
                }
            });
        });
    });
</script>
<?php

function pageModal()
{
    ob_start();
?>
    <!-- Change Password -->
    <div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="page-wrapper-new p-0">
                    <div class="content p-5 px-3 text-center">
                        <img src="assets/img/update.gif" alt="" class="" id="updateGIF" width="200px">
                        <h4 class="fs-20 fw-bold mb-2 mt-1 update-title">Installing...</h4>
                        <p class="mb-0 fs-16 update-desc">This might take a while</p>
                    </div>
                </div>
                <div class="modal-footer" style="display: none;">
                    <a href="javascript:void(0);" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>
    <!-- /Change Password -->
<?php
    return ob_get_clean();
} ?>