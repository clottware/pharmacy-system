<?php
require_once __DIR__ . '/config/config.php';
print_r($auth->checkRememberedUser()); // Debugging line to check if $auth is initialized correctly
if ($auth->checkRememberedUser()) {
    header('Location: index');
    exit;
}
include_once __DIR__ . '/functions.php';
?>
<!-- IT WILL MAKE SENSE SOON -->
<!DOCTYPE html>
<html lang="en">

<head>
    <?= getHeadContent("Forgot password - Clottware Pharmacy"); ?>
</head>

<body class="account-page bg-white" style="height:100vh;">
    <div class="main-wrapper">
        <div class="account-content">
            <div class="login-wrapper login-new">
                <div class="row w-100">
                    <div class="col-lg-5 mx-auto">
                        <div class="login-content user-login">
                            <div class="login-logo">
                                <img src="assets/img/logo.svg" alt="img">
                                <a href="index.html" class="login-logo logo-white">
                                    <img src="assets/img/logo-white.svg" alt="Img">
                                </a>
                            </div>
                            <form id="passRestForm">
                                <div class="card">
                                    <div class="card-body p-5">
                                        <div class="login-userheading">
                                            <h3>Forgot password?</h3>
                                            <h4>Reset your password</h4>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email <span class="text-danger"> *</span></label>
                                            <div class="input-group">
                                                <input type="email" id="emailRest" value="" name="email" class="form-control border-end-0" required>
                                                <span class="input-group-text border-start-0">
                                                    <i class="ti ti-mail"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-login">
                                            <?php echo renderSubmitButton('Rest Password', 'passReset', 'w-100'); ?>
                                        </div>

                                        <div class="form-setlogin or-text mb-3">
                                            <h4>OR</h4>
                                        </div>
                                        <div class="signinform text-center m-0">
                                            <h4>Return to<a href="login" class="hover-a"> login </a></h4>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="my-4 d-flex justify-content-center align-items-center copyright-text">
                            <p>Copyright &copy; 2025 Clottware</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Feather Icon JS -->
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/plugins/sweetalert2/sweetalert2.all.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/main.js?v=<?= time(); ?>"></script>
</body>

</html>