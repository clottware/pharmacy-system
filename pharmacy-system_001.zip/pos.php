<?php require 'config/session.php'; ?>
<?php
$bodyClass = 'pos-page';
$mainClass = ' pos-three';
?>
<?php
function customPageHeader()
{ ?>
    <link rel='stylesheet' href='assets/plugins/owlcarousel/owl.carousel.min.css'>
    <link rel='stylesheet' href='assets/plugins/owlcarousel/owl.theme.default.min.css'>
<?php }
?>
<?php include 'head.php'; ?>
<?php include 'components/header-pos.php'; ?>

<div class="page-wrapper pos-pg-wrapper ms-0">
    <div class="content pos-design p-0">
        <div class="row align-items-start pos-wrapper">
            <?php include 'components/pos-left.php'; ?>
            <?php include 'components/pos-right.php'; ?>
        </div>
    </div>
</div>



<?php
function pageModal()
{
    ob_start();
    $settings = new Settings();
    $sales = new Sales();
    $sales = $sales->getSalesSummaryByPaymentMethod();
?>
    <!-- Calculator -->
    <div class="modal fade pos-modal" id="calculator" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="calculator-wrap">
                        <div class="p-3">
                            <div class="d-flex align-items-center">
                                <h3>Calculator</h3>
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div>
                                <input class="input" type="text" placeholder="0" readonly>
                            </div>
                        </div>
                        <div class="calculator-body d-flex justify-content-between">
                            <div class="text-center">
                                <button class="btn btn-clear" onclick="clr()">C</button>
                                <button class="btn btn-number" onclick="dis('7')">7</button>
                                <button class="btn btn-number" onclick="dis('4')">4</button>
                                <button class="btn btn-number" onclick="dis('1')">1</button>
                                <button class="btn btn-number" onclick="dis(',')">,</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-expression" onclick="dis('/')">÷</button>
                                <button class="btn btn-number" onclick="dis('8')">8</button>
                                <button class="btn btn-number" onclick="dis('5')">5</button>
                                <button class="btn btn-number" onclick="dis('2')">2</button>
                                <button class="btn btn-number" onclick="dis('0')">0</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-expression" onclick="dis('%')">%</button>
                                <button class="btn btn-number" onclick="dis('9')">9</button>
                                <button class="btn btn-number" onclick="dis('6')">6</button>
                                <button class="btn btn-number" onclick="dis('3')">3</button>
                                <button class="btn btn-number" onclick="dis('.')">.</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-clear" onclick="back()"><i class="ti ti-backspace"></i></button>
                                <button class="btn btn-expression" onclick="dis('*')">x</button>
                                <button class="btn btn-expression" onclick="dis('-')">-</button>
                                <button class="btn btn-expression" onclick="dis('+')">+</button>
                                <button class="btn btn-clear" onclick="solve()">=</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Calculator -->
    <!-- Cash Register Details -->
    <div class="modal fade pos-modal" id="cash-register" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cash Register Details</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped border">
                            <tr>
                                <td>Cash in Hand</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 45689</td>
                            </tr>
                            <tr>
                                <td>Total Sale Amount</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 565597.88</td>
                            </tr>
                            <tr>
                                <td>Total Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 566867.97</td>
                            </tr>
                            <tr>
                                <td>Cash Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 3355.84</td>
                            </tr>
                            <tr>
                                <td>Total Sale Return</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 1959</td>
                            </tr>
                            <tr>
                                <td>Total Expense</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 0</td>
                            </tr>
                            <tr>
                                <td class="text-gray-9 fw-bold bg-secondary-transparent">Total Cash</td>
                                <td class="text-gray-9 fw-bold text-end bg-secondary-transparent"><?= $settings->get('currency_symbol_full'); ?> 587130.97</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-end gap-2 flex-wrap">
                    <button type="button" class="btn btn-md btn-primary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /Cash Register Details -->

    <!-- Today's Sale -->
    <div class="modal fade pos-modal" id="today-sale" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Today's Sale</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped border">
                            <tr>
                                <td>Total Sale Amount</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> <?= number_format($sales['total_sales'], 2) ?></td>
                            </tr>
                            <tr>
                                <td>Cash Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> <?= number_format($sales['cash_sales'], 2) ?></td>
                            </tr>
                            <tr>
                                <td>Mobile Money</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> <?= number_format($sales['momo_sales'], 2) ?></td>
                            </tr>
                            <tr>
                                <td class="text-gray-9 fw-bold bg-secondary-transparent">Total Cash</td>
                                <td class="text-gray-9 fw-bold text-end bg-secondary-transparent"><?= $settings->get('currency_symbol_full'); ?> <?= number_format($sales['total_sales'], 2) ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-end gap-2 flex-wrap">
                    <button type="button" class="btn btn-md btn-primary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /Today's Sale -->

    <!-- Payment Cash -->
    <div class="modal fade modal-default" data-bs-backdrop="static" data-bs-keyboard="false" id="saleComplete">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Finalize Sale</h5>
                </div>
                <form id="salesConfirmForm">
                    <div class="modal-body pb-1">
                        <div class="mb-2">
                            <span class="badge badge-purple badge-xs fs-10 fw-medium ms-2 sale-id">#1</span>
                            <input type="hidden" name="sale_id" id="sale_id">
                        </div>
                        <div class="bg-light br-10 p-4 text-center mb-3">
                            <h2 class="display-1"><?= $settings->get('currency_symbol'); ?> <span class="final-price">0.00</span></h2>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Received Amount <span class="text-danger">*</span></label>
                                    <div class="input-icon-start position-relative">
                                        <span class="input-icon-addon text-gray-9">
                                            <?= $settings->get('currency_symbol'); ?>
                                        </span>
                                        <input type="text" class="form-control" id="received_amount" name="received_amount" value="0">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Paying Amount <span class="text-danger">*</span></label>
                                    <div class="input-icon-start position-relative">
                                        <span class="input-icon-addon text-gray-9">
                                            <?= $settings->get('currency_symbol'); ?>
                                        </span>
                                        <input type="text" class="form-control" id="payment_amount" name="payment_amount" value="0">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="change-item mb-3">
                                    <label class="form-label">Change</label>
                                    <div class="input-icon-start position-relative">
                                        <span class="input-icon-addon text-gray-9">
                                            <?= $settings->get('currency_symbol'); ?>
                                        </span>
                                        <input type="text" class="form-control" id="sale_change" name="sale_change" value="0.00">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Payment Type <span class="text-danger">*</span></label>
                                    <select class="select select-payment" id="select_payment_method" name="select_payment_method">
                                        <option value="cash" selected>Cash</option>
                                        <option value="momo">Mobile Money</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer d-flex justify-content-end flex-wrap gap-2">
                        <input type="hidden" name="action" value="confirm">
                        <button type="button" class="btn btn-md btn-secondary cancel-order-btn" data-id="">Cancel Order</button>
                        <button type="submit" class="btn btn-md btn-primary" id="confirmBtnOrder">Confirm Payment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Payment Cash  -->

    <!-- details popup -->
    <div class="modal fade" id="sales-details-new">
        <div class="modal-dialog sales-details-modal">
            <div class="modal-content">
                <div class="page-header p-4 border-bottom mb-0">
                    <div class="add-item d-flex align-items-center">
                        <div class="page-title modal-datail">
                            <h4 class="mb-0 me-2">Sales Detail</h4>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="card border-0">
                        <div class="card-body pb-0">
                            <div class="invoice-box table-height" style="max-width: 1600px;width:100%;padding: 0;font-size: 14px;line-height: 24px;color: #555;">
                                <div class="row sales-details-items d-flex">
                                    <div class="col-md-4 details-item">
                                        <h6>Invoice Info</h6>
                                        <p class="mb-0">Reference: <span class="fs-16 text-primary ms-2 sales-reference"></span></p>
                                        <p class="mb-0">date: <span class="ms-2 text-gray-9 sales-date"></span></p>
                                        <p class="mb-0">Method: <span class="ms-2 text-gray-9 sales-method"></span></p>
                                        <p class="mb-0">Status: <span class="badge ms-2 sales-status"></span></p>
                                    </div>
                                </div>
                                <h5 class="order-text">Order Summary</h5>
                                <div class="table-responsive no-pagination mb-3">
                                    <table class="table  datanew">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Category</th>
                                                <th>Purchase Price(<?= $settings->get('currency_symbol'); ?>)</th>
                                                <th>Quantity</th>
                                                <th>Total Cost(<?= $settings->get('currency_symbol'); ?>)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <a href="javascript:void(0);"></a>
                                                    </div>
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="row">

                                <div class="row">
                                    <div class="col-lg-6 ms-auto">
                                        <div class="total-order w-100 max-widthauto m-auto mb-4">
                                            <ul class="rounded-3">
                                                <li>
                                                    <h4>Grand Total</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-total"></span></h5>
                                                </li>
                                                <li>
                                                    <h4>Paid</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-paid"></span></h5>
                                                </li>
                                                <li>
                                                    <h4>Balance</h4>
                                                    <h5><?= $settings->get('currency_symbol'); ?> <span class="sales-due"></span></h5>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /details popup -->

    <div class="modal fade modal-default" id="cancelSales" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="cancel-order">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="success-wrap text-center">
                        <form id="cancelOrderForm">
                            <div class="icon-success bg-purple-transparent text-purple mb-2">
                                <i class="ti ti-close"></i>
                            </div>
                            <input type="hidden" name="cancel_order_id" value="">
                            <input type="hidden" name="action" value="cancel">
                            <h3 class="mb-2">Confirm Your Action</h3>
                            <p class="fs-16 mb-3">The current order will be marked as canceled. But not deleted if it's persistent. Would you like to proceed ?</p>
                            <div class="d-flex align-items-center justify-content-center gap-2 flex-wrap">
                                <button type="button" class="btn btn-md btn-secondary" data-bs-dismiss="modal">No, Cancel</button>
                                <button type="submit" class="btn btn-md btn-primary">Yes, Proceed</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src='assets/js/calculator.js'></script>
    <?php
    function customPageFooter()
    { ?>
        <!-- Sticky-sidebar -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>

    <?php }
    ?>
<?php
}
require 'components/footer-pos.php';
?>

<script>
    $(function() {
        function updateClock() {
            var now = new Date();
            var h = String(now.getHours()).padStart(2, '0');
            var m = String(now.getMinutes()).padStart(2, '0');
            var s = String(now.getSeconds()).padStart(2, '0');
            $('.hour').text(h);
            $('.minute').text(m);
            $('.second').text(s);
        }
        updateClock();
        setInterval(updateClock, 1000);
    });
</script>