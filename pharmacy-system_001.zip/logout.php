<?php
require_once __DIR__ . '/config/config.php';

if ($auth->logout()) {
    Utils::redirect('login');
    exit;
}
