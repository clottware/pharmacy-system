CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;


CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `default_cats` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` VALUES ('5','Medicine','Prescription and over-the-counter drugs used for treatment or prevention of diseases.','2025-08-26 06:59:53','2025-08-26 07:48:33','1');
INSERT INTO `categories` VALUES ('6','Supplement','Vitamins, minerals, and dietary supplements that support general health.','2025-08-26 06:59:53','2025-08-26 07:48:37','1');
INSERT INTO `categories` VALUES ('7','Medical Device','Equipment, instruments, or machines used in healthcare diagnosis and treatment.','2025-08-26 06:59:53','2025-08-26 07:48:40','1');
INSERT INTO `categories` VALUES ('8','Cosmetic','Products applied to the body for cleansing, beautifying, or improving appearance.','2025-08-26 06:59:53','2025-08-26 07:48:42','1');
INSERT INTO `categories` VALUES ('9','Herbal Product','Traditional and natural remedies made from plants and herbs.','2025-08-26 06:59:53','2025-08-26 07:48:45','1');
INSERT INTO `categories` VALUES ('10','Personal Care','Everyday healthcare and hygiene products like soap, toothpaste, etc.','2025-08-26 06:59:53','2025-08-26 07:48:47','1');
INSERT INTO `categories` VALUES ('11','Surgical Supply','Items used in surgeries and medical procedures such as gloves, masks, and instruments.','2025-08-26 06:59:53','2025-08-26 07:48:49','1');
INSERT INTO `categories` VALUES ('12','Infant & Child Care','Products specifically made for babies and children.','2025-08-26 06:59:53','2025-08-26 07:48:51','1');

CREATE TABLE `changelogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) DEFAULT NULL,
  `change_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `dosage_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `dosage_forms` VALUES ('1','Tablet','Solid oral dosage form, usually swallowed whole','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('2','Capsule','Solid dosage form with medicine inside a shell','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('3','Syrup','Liquid form, sweetened, for oral use','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('4','Injection','Liquid form administered via syringe','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('5','Cream','Semi-solid preparation for external use','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('6','Drops','Liquid in small volumes, often for eyes/ears/nose','2025-08-26 06:54:28','');
INSERT INTO `dosage_forms` VALUES ('7','Ointment','Greasy semi-solid preparation for skin application','2025-08-26 06:54:28','');

CREATE TABLE `drug_tty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tty` varchar(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tty` (`tty`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `drug_tty` VALUES ('1','SBD','Semantic Branded Drug - Brand name with strength and dosage form');
INSERT INTO `drug_tty` VALUES ('2','SCD','Semantic Clinical Drug - Generic name with strength and dosage form');
INSERT INTO `drug_tty` VALUES ('3','BN','Brand Name - The drug brand name only');
INSERT INTO `drug_tty` VALUES ('4','IN','Ingredient - The active ingredient');
INSERT INTO `drug_tty` VALUES ('5','PIN','Precise Ingredient - More specific version of IN');
INSERT INTO `drug_tty` VALUES ('6','DF','Dose Form - The form of the drug, e.g., Oral Tablet');
INSERT INTO `drug_tty` VALUES ('7','GPCK','Generic Pack - A package of generic clinical drugs');
INSERT INTO `drug_tty` VALUES ('8','BPCK','Branded Pack - A package of branded drugs');

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `recorded_by` (`recorded_by`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `medicine_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `medicines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `batch_no` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `unit` varchar(20) DEFAULT NULL,
  `buying_price` decimal(10,2) DEFAULT NULL,
  `selling_price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `medicines_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `medicine_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `news_feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `fetched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `premium_features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `dosage_form` varchar(100) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `min_qty` int(11) NOT NULL DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `cost_price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_products_category` (`category_id`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` VALUES ('1','Paracetamol 500mg Tablets','','5','0','','1','','2027-08-20','1','2','20.00','10.00','2025-08-26 11:58:47','1','2025-08-29 14:26:04');
INSERT INTO `products` VALUES ('2','One plus 400','','5','0','','1','','2025-09-09','50','49','1000.00','40.00','2025-09-02 19:01:26','1','2025-09-02 19:01:26');

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `payment_method` enum('cash','mobile_money') DEFAULT 'cash',
  `total_amount` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `key_name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(50) DEFAULT 'string',
  `group` varchar(100) DEFAULT 'general',
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

INSERT INTO `settings` VALUES ('1','','site_name','Clottware Pharmacy','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('2','','currency_symbol','₵','string','general','','2025-08-26 08:20:49');
INSERT INTO `settings` VALUES ('3','','timezone','Africa/Accra','string','general','','2025-08-03 15:17:42');
INSERT INTO `settings` VALUES ('4','','site_email','email@company.com','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('5','','phone','0202062842','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('6','','fax','05966875','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('7','','website','website.com','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('8','','address','','string','general','','2025-08-10 01:21:41');
INSERT INTO `settings` VALUES ('9','','language','English','string','general','','2025-08-10 02:31:21');
INSERT INTO `settings` VALUES ('10','','date_format_time','F d, Y, h:i A','string','general','','2025-08-26 22:17:48');
INSERT INTO `settings` VALUES ('11','','short_date','m/d/Y, h:i A','string','general','','2025-08-26 22:17:56');
INSERT INTO `settings` VALUES ('12','','currency_sep','₵1,234.56','string','general','','2025-08-10 02:31:21');
INSERT INTO `settings` VALUES ('13','','numbers_format','1,234.56','string','general','','2025-08-10 02:31:21');
INSERT INTO `settings` VALUES ('14','','date_format','F d, Y','string','general','','2025-08-26 22:17:37');
INSERT INTO `settings` VALUES ('15','','currency_symbol_full','GHS','string','general','','2025-08-10 02:31:21');
INSERT INTO `settings` VALUES ('16','','app_version','0.0.1','string','general','','2025-09-03 05:12:46');
INSERT INTO `settings` VALUES ('17','','update_token','','string','general','','2025-09-03 04:32:55');
INSERT INTO `settings` VALUES ('18','','update','true','string','general','','2025-09-03 13:09:46');

CREATE TABLE `stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicine_id` int(11) DEFAULT NULL,
  `type` enum('in','out','adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `logged_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `medicine_id` (`medicine_id`),
  KEY `logged_by` (`logged_by`),
  CONSTRAINT `stock_log_ibfk_1` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`),
  CONSTRAINT `stock_log_ibfk_2` FOREIGN KEY (`logged_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `phone_number` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `remember_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES ('1','admin','admin@gmail.com','$2y$10$2dKdD3vJ/RIrrmy14AVhm.3u5guJD/lcTnKKmtTMCmawo9FOnMaES','2025-08-09 23:53:59','Phs','Admin','admin','000000','2025-08-03 15:17:42','');

