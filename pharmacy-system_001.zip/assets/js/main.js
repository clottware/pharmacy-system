/** @format */

$(document).ready(function () {
  if ($('img[data-name]').length != 0) {
    $('.avatar-profile').initial({
      charCount: 1,
      radius: 10,
    });
  }

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    },
  });

  // function to handle toaster
  function toaster(type, message) {
    Toast.fire({
      icon: type,
      title: message,
    });
  }

  $('#profileForm').on('submit', function (e) {
    e.preventDefault(); // Stop default form submit

    let $form = $(this);
    let $btn = $('#saveBtn');
    let $spinner = $('#loader-spinner');
    let formData = $form.serialize();

    $.ajax({
      url: $form.attr('action'),
      method: 'POST',
      data: formData,
      beforeSend: function () {
        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
      },
      success: function (response) {
        if (response.status) {
          toaster('success', response.message);
          //wait for some sec and reload page
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        } else {
          if (response.authentication === 'false') {
            window.location = 'logout';
          }
          toaster('error', response.message);
        }
      },
      error: function () {
        toaster('error', 'Something went wrong. Please try again.');
      },
      complete: function () {
        $btn.prop('disabled', false);
        $spinner.addClass('d-none');
      },
    });
  });

  $('#loginForm').on('submit', function (e) {
    e.preventDefault();

    let $form = $(this);
    let formData = $form.serialize();
    let $btn = $('#loginForm button[type="submit"]');
    let $spinner = $('#loader-spinner');
    $('#loginResponse').empty(); // Clear previous messages
    $.ajax({
      url: 'controllers/login',
      method: 'POST',
      data: formData,
      dataType: 'json',
      beforeSend: function () {
        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
      },
      success: function (response) {
        if (response.status) {
          $('#loginResponse').html(
            '<div class="alert alert-success">' + response.message + '</div>'
          );
          Toast.fire({
            icon: 'success',
            title: 'Signed in successfully',
          });
          setTimeout(() => {
            window.location.href = 'dashboard';
          }, 1000);
        } else {
          $('#loginResponse').html(
            '<div class="alert alert-danger">' + response.message + '</div>'
          );
        }
      },
      error: function () {
        $('#loginResponse').html(
          '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
        );
      },
      complete: function () {
        $btn.prop('disabled', false);
        $spinner.addClass('d-none');
      },
    });
  });

  $('#emailRest').on('input', function () {
    let email = $(this).val();
    let $btn = $('#passReset');
    let $spinner = $('#loader-spinner');
    // Simple email regex for validation
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email && emailRegex.test(email)) {
      $.ajax({
        url: 'controllers/reset',
        method: 'GET',
        data: { email: email },
        dataType: 'json',
        beforeSend: function () {
          $btn.prop('disabled', true);
          $spinner.removeClass('d-none');
        },
        success: function (response) {
          $btn.prop('disabled', false);
          $spinner.addClass('d-none');
        },
      });
    }
  });

  $('#passRestForm').on('submit', function (e) {
    e.preventDefault();
    let $form = $(this);
    let formData = $form.serialize();
    let $btn = $('button[type="submit"]');
    let $spinner = $('#loader-spinner');
    $('#loginResponse').empty(); // Clear previous messages

    $.ajax({
      type: 'POST',
      url: 'controllers/reset',
      data: formData,
      dataType: 'json',
      beforeSend: function () {
        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
      },
      success: function (response) {
        Toast.fire({
          icon: 'success',
          title: 'Password reset successfully',
        });
        $btn.prop('disabled', false);
        $spinner.addClass('d-none');
      },
    });
  });

  $('#changePasswordForm').on('submit', function (e) {
    e.preventDefault();

    let $form = $(this);
    let $btn = $('#changePasswordForm button[type="submit"]');
    let $spinner = $('.loader-spinner');
    $('.formResponse').empty(); // Clear previous messages
    $.ajax({
      url: 'controllers/change-password',
      method: 'POST',
      data: $form.serialize(),
      dataType: 'json',
      beforeSend: function () {
        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
      },
      success: function (response) {
        if (response.status) {
          $('.formResponse').html(
            '<div class="alert alert-success">' + response.message + '</div>'
          );
          Toast.fire({
            icon: 'success',
            title: 'Password changed successfully',
          });
          // dismiss modal
          $('#change-password').modal('hide');
          // reset form
          $form[0].reset();
        } else {
          $('.formResponse').html(
            '<div class="alert alert-danger">' + response.message + '</div>'
          );
        }
      },
      error: function () {
        $('.formResponse').html(
          '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
        );
      },
      complete: function () {
        $btn.prop('disabled', false);
        $spinner.addClass('d-none');
      },
    });
  });

  $('#companySettingsForm').on('submit', function (e) {
    e.preventDefault();

    let $form = $(this);
    let $btn = $('#companySettingsForm button[type="submit"]');
    let $spinner = $('#loader-spinner');
    $('.formResponse').empty(); // Clear previous messages
    $.ajax({
      url: 'controllers/company-settings',
      method: 'POST',
      data: $form.serialize(),
      dataType: 'json',
      beforeSend: function () {
        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
      },
      success: function (response) {
        if (response.status) {
          Toast.fire({
            icon: 'success',
            title: response.message,
          });
        } else {
          Toast.fire({
            icon: 'success',
            title: response.message,
          });
        }
      },
      error: function () {
        $('.formResponse').html(
          '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
        );
      },
      complete: function () {
        $btn.prop('disabled', false);
        $spinner.addClass('d-none');
      },
    });
  });

  const lastCheck = localStorage.getItem('lastUpdateCheck');
  const now = Date.now();
  const twelveHours = 12 * 60 * 60 * 1000;

  if (navigator.onLine && (!lastCheck || now - lastCheck > twelveHours)) {
    $.ajax({
      url: 'controllers/update',
      method: 'POST',
      data: {
        updateCheck: true,
      },
      dataType: 'json',
      success: function (res) {
        localStorage.setItem('lastUpdateCheck', now);
      },
    });
  }
});
