<?php require 'config/session.php'; ?>
<?php include 'head.php'; ?>
<?php include 'components/sidebar.php'; ?>
<?php include 'components/header.php'; ?>
<?php
if ($auth->currentUser() != null) {
    $user = $auth->currentUser();
    $displayName = $user['first_name'] . ' ' . $user['last_name'];
}
?>

<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-2">
    <div class="mb-3">
        <h1 class="mb-1"><span class="greetings" id="greeting">Hello</span>, <?= $displayName; ?></h1>
        <p class="fw-medium">You sold <span class="text-primary fw-bold">0+</span> products, Today</p>
    </div>
    <div class="input-icon-start position-relative mb-3">
        <span class="input-icon-addon fs-16 text-gray-9">
            <i class="ti ti-calendar"></i>
        </span>
        <input type="text" class="form-control date-range bookingrange" placeholder="Search Product">
    </div>
</div>
<?php
$salesAnalytics = new Analytics();
// Daily sales
$todaySales = $salesAnalytics->getTotalSales('week');
$todayChange = $salesAnalytics->getPercentageChange('week');

// Weekly products sold
$weeklyProducts = $salesAnalytics->getProductsSold('week');
$weeklyChange = $salesAnalytics->getProductPercentageChange('week');

// Payment method breakdown
$monthlyBreakdown = $salesAnalytics->getPaymentBreakdown('week');
?>
<div class="row sales-cards">
    <div class="col-xl-6 col-sm-12 col-12 d-flex">
        <div class="card d-flex align-items-center justify-content-between flex-fill mb-4">
            <div>
                <h6>Weekly Earning </h6>
                <h3><?= $settings->get('currency_symbol'); ?> <span class="counters" data-count="<?= $todaySales; ?>"><?= $todaySales; ?></span></h3>
                <p class="sales-range"><span class="text-<?= $todayChange > 0 ? 'success' : 'danger'; ?> "><i data-feather="chevron-<?= $todayChange > 0 ? 'up' : 'down'; ?>" class="feather-16"></i><?= $todayChange > 0 ? '+' : '-' ?><?= $todayChange; ?>%&nbsp;</span><?= $todayChange > 0 ? 'increase' : 'decrease' ?> compare to last week</p>
            </div>
            <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the weekly earning"></i>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6 col-12 d-flex">
        <div class="card color-info bg-primary flex-fill mb-4">
            <div class="d-flex align-items-left flex-column justify-content-end h-100">
                <h3 class="counters" data-count="0"><?= $weeklyProducts; ?></h3>
                <p>Product Sold</p>
                <span class="badge badge-soft-<?= $weeklyChange > 0 ? 'success' : 'danger'; ?>"><i class="ti ti-arrow-<?= $weeklyChange > 0 ? 'up' : 'down'; ?> me-1"></i><?= $weeklyChange > 0 ? '+' : '-' ?><?= $weeklyChange; ?>%</span>
            </div>

            <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the total product sold for the week"></i>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6 col-12 d-flex">
        <div class="card color-info bg-secondary flex-fill mb-4">
            <div class="d-flex align-items-left flex-column justify-content-end h-100">
                <h3 class="counters" data-count="0">0</h3>
                <p>Total Expired</p>
                <span class="badge badge-soft-danger"><i class="ti ti-arrow-down me-1"></i>-0%</span>
            </div>
            <div class="tooltip-box text-md" style="top: 9px; right: 12px;">
                <i class="ti ti-info-circle" data-bs-toggle="tooltip" data-bs-custom-class="tooltip-secondary" data-bs-placement="bottom" data-bs-original-title="This is the total expired products for the week"></i>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <?php
    $lowStockProducts = new Product();
    $lowStockProduct = $lowStockProducts->productStockLevel();
    $categoryModel = new Category();
    ?>
    <!-- Sales & Purchase -->
    <div class="col-xxl-8 col-xl-7 col-sm-12 col-12 d-flex">
        <div class="card flex-fill">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-inline-flex align-items-center">
                    <span class="title-icon bg-soft-danger fs-16 me-2"><i class="ti ti-alert-triangle"></i></span>
                    <h5 class="card-title mb-0">Low Stock Products</h5>
                </div>
                <a href="low-stocks.html" class="fs-13 fw-medium text-decoration-underline">View All</a>
            </div>
            <div class="card-body">
                <?php if ($lowStockProduct): ?>
                    <?php foreach ($lowStockProduct as $lowStock): ?>
                        <?php $category = $lowStock['category_id'] ? $categoryModel->getCategoryById($lowStock['category_id']) : null; ?>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div class="d-flex align-items-center">
                                <div class="ms-2">
                                    <h6 class="fw-bold mb-1"><a href="javascript:void(0);"><?= $lowStock['name'] ?></a></h6>
                                    <p class="fs-13">Category : <?= $category['name'] ?></p>
                                </div>
                            </div>
                            <div class="text-end">
                                <p class="fs-13 mb-1"><?= $lowStock['quantity'] === 0 ? 'Out of Stock' : 'In Stock' ?></p>
                                <h6 class="text-orange fw-medium"><?= $lowStock['quantity']; ?></h6>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- /Sales & Purchase -->

    <!-- Top Selling Products -->
    <div class="col-xxl-4 col-xl-5 d-flex">
        <div class="card flex-fill">
            <div class="card-header">
                <div class="d-inline-flex align-items-center">
                    <span class="title-icon bg-soft-info fs-16 me-2"><i class="ti ti-info-circle"></i></span>
                    <h5 class="card-title mb-0">Overall Information</h5>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-info fs-24">
                                <i class="ti ti-package"></i>
                            </div>
                            <p class="mb-1">Products</p>
                            <h5>0</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-success fs-24">
                                <i class="ti ti-shopping-cart"></i>
                            </div>
                            <p class="mb-1">Sales</p>
                            <h5>0</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-red fs-24">
                                <i class="ti ti-clock-hour-4"></i>
                            </div>
                            <p class="mb-1">Expired</p>
                            <h5>0</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-item border bg-light p-3 text-center">
                            <div class="mb-2 text-red fs-24">
                                <i class="ti ti-info-triangle"></i>
                            </div>
                            <p class="mb-1">Low Stock</p>
                            <h5>0</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var hour = parseInt(serverTime, 10);
        var greeting = "Hello";
        if (hour >= 5 && hour < 12) {
            greeting = "Good morning";
        } else if (hour >= 12 && hour < 18) {
            greeting = "Good afternoon";
        } else {
            greeting = "Good evening";
        }
        $('#greeting').text(greeting);
    });
</script>
<?php
function pageModal()
{
    // This function can be overridden in specific pages to add modals
    return null;
}
require 'components/footer.php';
?>