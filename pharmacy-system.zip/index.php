<?php
//include config file
include_once __DIR__ . '/config/config.php';
if (!$auth->checkRememberedUser()) {
    Utils::redirect('login');
    exit;
} else {
    Utils::redirect('dashboard'); // Redirect to dashboard if user is already logged in 
}
