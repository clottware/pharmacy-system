<!-- @format -->

# 📂 Folder Structure

This document explains the purpose of each folder in the project.

---

## Root Files

| File            | Description                       |
| --------------- | --------------------------------- |
| `index.php`     | Login / Entry point of the system |
| `dashboard.php` | Admin dashboard page              |

---

## 📁 Folders

### `assets/`

Static frontend files: CSS, JS, and images.

- `css/`: Custom and Bootstrap overrides
- `js/`: jQuery scripts and app logic
- `images/`: Logos, medicine images, etc.

---

### `components/`

Reusable UI components like header, sidebar, footer, modals, etc.

---

### `config/`

Configuration files for database, constants, and global settings.

---

### `controllers/`

Handles logic for forms, POST/GET requests, validations.

---

### `core/`

Core helpers and utilities: authentication, sanitization, session management.

---

### `docs/`

Project documentation in Markdown.

---

### `models/`

SQL operations and database-related PHP classes/functions.

---

### `premium/`

Premium-only features and utilities.

---

### `updates/`

Version changelogs and update scripts.

---

### `views/`

HTML markup views (split pages like `sales.php`, `inventory.php`, `customers.php`, etc.)

---
