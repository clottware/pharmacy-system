<?php

/**
 * This file contains all defined constants and configuration settings for the application.
 * It is included in various parts of the application to ensure consistent configuration.
 */

// Define the base URL of the application
define('BASE_URL', 'http://localhost/pharmacy-system/');

// Define other constants as needed
define('APP_NAME', 'Clottware Pharmacy');
define('APP_VERSION', '1.0.0');
// Define database connection settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'pharmacy_system');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

// Environment
define('DEBUG_MODE', true);
if (DEBUG_MODE) {
    //show all sever-side errors
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Include functions file for common functions
include_once __DIR__ . '/../functions.php';

// Define paths for assets
define('ASSETS_PATH', BASE_URL . 'assets/');
// Define paths for controllers, models, and views
define('CONTROLLERS_PATH', __DIR__ . '/../controllers/');
define('MODELS_PATH', __DIR__ . '/../models/');
define('VIEWS_PATH', __DIR__ . '/../views/');
// Include autoload file for class loading
require_once __DIR__ . '/autoload.php';
// Include rendered file
require_once __DIR__ . '/../components/submit-btn.php';
// Include the class
$auth = new Auth();
$validate = new Validator();
$settings = new Settings();
$mailer = new Mailer("support@pharmacy.local", "Pharmacy Admin");
$logs = new Log();

date_default_timezone_set($settings->get('timezone'));
// Example usage of the classes



// Log an activity
// $log->activity("User ID 5 updated stock for item #42");

// // Log an error
// $log->error("Database connection failed: Access denied for user 'root'");
