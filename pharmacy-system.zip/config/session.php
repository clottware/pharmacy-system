<?php
//include config file
include_once __DIR__ . '/config.php';
if (!$auth->checkRememberedUser()) {
    header('Location: login');
    exit;
}

// check if session is valid

// Optional: restrict roles
// if ($_SESSION['user']['role'] !== 'admin') {
//     header('Location: unauthorized.php');
//     exit;
// }
