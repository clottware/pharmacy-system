<?php

/**
 * Database Connection
 * Clottware Pharmacy Management System
 * @package    config
 * @version    0.1.0
 * @since      PHP 7.4+
 */

include_once __DIR__ . '/config.php'; // Include configuration settings

$host = DB_HOST;
$db   = DB_NAME;
$user = DB_USER;
$pass = DB_PASSWORD;
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // throw errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // return associative arrays
    PDO::ATTR_EMULATE_PREPARES   => false,                  // use native prepares
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Database Connection Failed: ' . $e->getMessage());
}
