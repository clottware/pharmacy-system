<?php
// autoload.php

spl_autoload_register(function ($class) {
    // Remove namespace prefix if any
    $class = ltrim($class, '\\');
    $classPath = str_replace('\\', DIRECTORY_SEPARATOR, $class) . '.php';

    $paths = [
        __DIR__ . '/../core',
        __DIR__ . '/../controllers',
        __DIR__ . '/../models',
    ];

    foreach ($paths as $path) {
        $fullPath = $path . DIRECTORY_SEPARATOR . $classPath;

        if (file_exists($fullPath)) {
            require_once $fullPath;
            return;
        }

        // Optional: search recursively in subfolders
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (strcasecmp($file->getFilename(), basename($classPath)) === 0) {
                require_once $file->getPathname();
                return;
            }
        }
    }

    // Debug mode
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        die("Autoloader error: Class '$class' not found in any registered paths.");
    }
});
