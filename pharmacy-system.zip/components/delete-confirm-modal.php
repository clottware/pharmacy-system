<?php

function confirmationModal($title = '', $message = '', $confirmText = 'Delete', $cancelText = 'Cancel')
{
    $modalId = 'delete-modal';
    return <<<HTML
    <div class="modal fade" id="{$modalId}" tabindex="-1" aria-labelledby="{$modalId}Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="page-wrapper-new p-0">
                    <div class="content p-5 px-3 text-center">
                        <span class="rounded-circle d-inline-flex p-2 bg-danger-transparent mb-2"><i class="ti ti-trash fs-24 text-danger"></i></span>
                        <h4 class="fs-20 fw-bold mb-2 mt-1">{$title}</h4>
                        <p class="mb-0 fs-16">{$message}</p>
                        <div class="modal-footer-btn mt-3 d-flex justify-content-center">
                            <button type="button" class="btn me-2 btn-secondary fs-13 fw-medium p-2 px-3 shadow-none" data-bs-dismiss="modal">{$cancelText}</button>
                            <button type="submit" class="btn btn-primary fs-13 fw-medium p-2 px-3" data-id="<brand_id>">{$confirmText}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
HTML;
}
