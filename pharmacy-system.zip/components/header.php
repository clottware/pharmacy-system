<?php
if ($auth->currentUser() != null) {
    $user = $auth->currentUser();
    $displayName = $user['first_name'] . ' ' . $user['last_name'];
} ?>
<!-- Header -->
<div class="header">
    <div class="main-header">

        <!-- Logo -->
        <div class="header-left active">
            <a href="dashboard" class="logo logo-normal">
                <img src="assets/img/logo.svg" alt="Img">
            </a>
            <a href="dashboard" class="logo logo-white">
                <img src="assets/img/logo-white.svg" alt="Img">
            </a>
            <a href="dashboard" class="logo-small">
                <img src="assets/img/logo-small.png" alt="Img">
            </a>
        </div>
        <!-- /Logo -->

        <a id="mobile_btn" class="mobile_btn" href="#sidebar">
            <span class="bar-icon">
                <span></span>
                <span></span>
                <span></span>
            </span>
        </a>

        <!-- Header Menu -->
        <ul class="nav user-menu">

            <li class="nav-item pos-nav ms-auto">
                <a href="products?action=add" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add new product" class="btn btn-primary btn-md d-inline-flex align-items-center">
                    <i class="ti ti-circle-plus me-1"></i>Add New
                </a>
            </li>

            <li class="nav-item pos-nav">
                <a href="pos" data-bs-toggle="tooltip" data-bs-placement="bottom" title="POS" class="btn btn-dark btn-md d-inline-flex align-items-center">
                    <i class="ti ti-device-laptop me-1"></i>POS
                </a>
            </li>


            <li class="nav-item nav-item-box">
                <a href="javascript:void(0);" id="btnFullscreen" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Fullscreen">
                    <i class="ti ti-maximize"></i>
                </a>
            </li>
            <!-- Notifications -->
            <li class="nav-item dropdown nav-item-box d-none" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Notifications">
                <a href="javascript:void(0);" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                    <i class="ti ti-bell"></i>
                </a>
                <div class="dropdown-menu notifications">
                    <div class="topnav-dropdown-header">
                        <h5 class="notification-title">Notifications</h5>
                        <a href="javascript:void(0)" class="clear-noti">Mark all as read</a>
                    </div>
                    <div class="noti-content">
                        <ul class="notification-list">
                            <li class="notification-message d-none">
                                <a href="activities.html">
                                    <div class="media d-flex">
                                        <span class="avatar flex-shrink-0">
                                            <img alt="Img" src="assets/img/profiles/avatar-13.jpg">
                                        </span>
                                        <div class="flex-grow-1">
                                            <p class="noti-details"><span class="noti-title">James Kirwin</span> confirmed his order. Order No: #78901.Estimated delivery: 2 days</p>
                                            <p class="noti-time">4 mins ago</p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="empty notification-message bg-light d-flex flex-column align-items-center justify-content-center" style="height: 290px;">
                                <p>No new notifications</p>
                            </li>
                        </ul>
                    </div>
                    <div class="topnav-dropdown-footer d-flex align-items-center gap-3">
                        <a href="#" class="btn btn-secondary btn-md w-100">Cancel</a>
                        <a href="activitiesl" class="btn btn-primary btn-md w-100">View all</a>
                    </div>
                </div>
            </li>
            <!-- /Notifications -->
            <li class="nav-item dropdown has-arrow main-drop profile-nav">
                <a href="javascript:void(0);" class="nav-link userset" data-bs-toggle="dropdown">
                    <span class="user-info p-0">
                        <span class="user-letter">
                            <img src="" data-name="<?= htmlspecialchars($displayName) ?>" alt="<?= htmlspecialchars($displayName) ?>" class="img-fluid avatar-profile">
                        </span>
                    </span>
                </a>
                <div class="dropdown-menu menu-drop-user">
                    <div class="profileset d-flex align-items-center">

                        <span class="user-img me-2">
                            <img src="" class="avatar-profile" data-name="<?= htmlspecialchars($displayName) ?>" alt="<?= htmlspecialchars($displayName) ?>">
                        </span>
                        <div>
                            <h6 class="fw-medium"><?= htmlspecialchars($displayName) ?></h6>
                            <p><?= htmlspecialchars($user['role']) ?></p>
                        </div>
                    </div>
                    <a class="dropdown-item" href="settings?gs=profile"><i class="ti ti-user-circle me-2"></i>MyProfile</a>
                    <a class="dropdown-item" href="settings?gs=general"><i class="ti ti-settings-2 me-2"></i>Settings</a>
                    <hr class="my-2">
                    <a class="dropdown-item logout pb-0" href="logout"><i class="ti ti-logout me-2"></i>Logout</a>
                </div>
            </li>
        </ul>
        <!-- /Header Menu -->

        <!-- Mobile Menu -->
        <div class="dropdown mobile-user-menu">
            <a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
                aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="settings?gs=profile">My Profile</a>
                <a class="dropdown-item" href="settings?gs=general">Settings</a>
                <a class="dropdown-item" href="logout">Logout</a>
            </div>
        </div>
        <!-- /Mobile Menu -->
    </div>
</div>
<!-- /Header -->
<div class="page-wrapper">
    <div class="content">