<?php
function renderSubmitButton($label = 'Submit', $id = 'submitBtn', $class = 'btn btn-primary')
{
    return '<button type="submit" id="' . htmlspecialchars($id) . '" loader-spinner class="btn btn-primary ' . htmlspecialchars($class) . '"><i class="fas fa-spinner fa-spin me-2 d-none" id="loader-spinner"></i> ' . htmlspecialchars($label) . '</button>';
}
