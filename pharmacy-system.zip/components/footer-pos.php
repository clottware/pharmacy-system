<?php
if (function_exists(pageModal())) {
    echo pageModal();
}
?>
</main>
<!-- Owl JS -->
<script src="assets/plugins/owlcarousel/owl.carousel.min.js"></script>

<?= getFooterContent(); ?>

</body>

</html>