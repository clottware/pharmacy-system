</div>
<?php include_once 'components/page-footer.php'; ?>
</div>
<?php
$modal = pageModal();
if (isset($modal)) {
    echo $modal;
}
?>
</main>
<?= getFooterContent(); ?>

</body>

</html>