<?php
if ($auth->currentUser() != null) {
    $user = $auth->currentUser();
    $displayName = $user['first_name'] . ' ' . $user['last_name'];
} ?>
<!-- Header -->
<div class="header pos-header">

    <!-- Logo -->
    <div class="header-left active">
        <a href="pos" class="logo logo-normal">
            <img src="assets/img/logo.svg" alt="Img">
        </a>
        <a href="pos" class="logo logo-white">
            <img src="assets/img/logo-white.svg" alt="Img">
        </a>
        <a href="pos" class="logo-small">
            <img src="assets/img/logo-small.png" alt="Img">
        </a>
    </div>
    <!-- /Logo -->

    <a id="mobile_btn" class="mobile_btn d-none" href="#sidebar">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>

    <!-- Header Menu -->
    <ul class="nav user-menu">
        <!-- Search -->
        <li class="nav-item time-nav">
            <span class="bg-teal text-white d-inline-flex align-items-center">
                <img src="assets/img/icons/clock-icon.svg" alt="img" class="me-2">
                <span class="hour p-0"></span>:<span class="minute p-0"></span>:<span class="second p-0"></span>
            </span>
        </li>
        <!-- /Search -->
        <li class="nav-item pos-nav">
            <a href="dashboard" class="btn btn-purple btn-md d-inline-flex align-items-center">
                <i class="ti ti-world me-1"></i>
                Dashboard
            </a>
        </li>
        <li class="nav-item nav-item-box">
            <a href="#" data-bs-toggle="modal" data-bs-target="#calculator" class="bg-orange border-orange text-white"><i class="ti ti-calculator"></i></a>
        </li>
        <li class="nav-item nav-item-box">
            <a href="javascript:void(0);" id="btnFullscreen" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Maximize">
                <i class="ti ti-maximize"></i>
            </a>
        </li>
        <li class="nav-item nav-item-box" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Today’s Sale">
            <a href="#" data-bs-toggle="modal" data-bs-target="#today-sale"><i class="ti ti-progress"></i></a>
        </li>
        <li class="nav-item dropdown has-arrow main-drop profile-nav">
            <a href="javascript:void(0);" class="nav-link userset" data-bs-toggle="dropdown">
                <span class="user-info p-0">
                    <span class="user-letter">
                        <img src="" data-name="<?= htmlspecialchars($displayName) ?>" alt="<?= htmlspecialchars($displayName) ?>" class="img-fluid avatar-profile">
                    </span>
                </span>
            </a>
            <div class="dropdown-menu menu-drop-user">
                <div class="profileset d-flex align-items-center">

                    <span class="user-img me-2">
                        <img src="" class="avatar-profile" data-name="<?= htmlspecialchars($displayName) ?>" alt="<?= htmlspecialchars($displayName) ?>">
                    </span>
                    <div>
                        <h6 class="fw-medium"><?= htmlspecialchars($displayName) ?></h6>
                        <p><?= htmlspecialchars($user['role']) ?></p>
                    </div>
                </div>
                <a class="dropdown-item" href="settings?gs=profile"><i class="ti ti-user-circle me-2"></i>MyProfile</a>
                <a class="dropdown-item" href="settings?gs=general"><i class="ti ti-settings-2 me-2"></i>Settings</a>
                <hr class="my-2">
                <a class="dropdown-item logout pb-0" href="logout"><i class="ti ti-logout me-2"></i>Logout</a>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->

    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
            aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="settings?gs=profile">My Profile</a>
            <a class="dropdown-item" href="settings?gs=general">Settings</a>
            <a class="dropdown-item" href="logout">Logout</a>
        </div>
    </div>
    <!-- /Mobile Menu -->
</div>
<!-- Header -->