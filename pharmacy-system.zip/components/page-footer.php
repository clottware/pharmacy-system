<div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3">
    <p class="mb-0 text-gray-9"><?= date('Y') ?> &copy; Clottware Point. All Right Reserved</p>
    <p>Designed &amp; Developed by <a href="javascript:void(0);" class="text-primary">Clottware</a></p>
</div>