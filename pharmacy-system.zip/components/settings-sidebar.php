<div class="settings-sidebar" id="sidebar2">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu5" class="sidebar-menu">
            <h4 class="fw-bold fs-18 mb-2 pb-2">Settings</h4>
            <ul>
                <li class="submenu-open">
                    <ul>
                        <li class="submenu">
                            <a href="javascript:void(0);" <?= (isset($_GET['gs'])) ? ' class="active subdrop"' : '' ?>>
                                <i class="ti ti-settings fs-18"></i>
                                <span class="fs-14 fw-medium ms-2">General Settings</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul>
                                <li><a href="?gs=profile" <?= (isset($_GET['gs']) && $_GET['gs'] === 'profile') ? 'class="active"' : '' ?>>Profile</a></li>
                                <li><a href="?gs=security" <?= (isset($_GET['gs']) && $_GET['gs'] === 'security') ? 'class="active"' : '' ?>>Security</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0);" <?= (isset($_GET['ps'])) ? ' class="active subdrop"' : '' ?>>
                                <i class="ti ti-world fs-18"></i>
                                <span class="fs-14 fw-medium ms-2">Portal Settings</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul>
                                <li><a href="?ps=company">Company Settings </a></li>
                                <li><a href="?ps=localization">Localization</a></li>
                                <li><a href="?ps=appearance" class="d-none">Appearance</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0);">
                                <i class="ti ti-settings-dollar fs-18"></i>
                                <span class="fs-14 fw-medium ms-2">Financial Settings</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul>
                                <li><a href="?fs=payment">Payment Gateway</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>