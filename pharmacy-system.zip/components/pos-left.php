<?php
$currentUser = $auth->currentUser();
if ($currentUser) {
    $displayName = $currentUser['first_name'] . ' ' . $currentUser['last_name'];
} else {
    $displayName = 'Guest';
}
$productModel = new Product();
$categoryModel = new Category();
$brandModel = new Brands();
if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
    $products = $productModel->getProductsByCategory($_GET['category']);
} else {
    $products = $productModel->getAllProducts();
}
?>
<div class="col-md-12 col-lg-7 col-xl-8">
    <div class="pos-categories tabs_wrapper">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
            <div>
                <h5 class="mb-1">Welcome, <?= $displayName; ?></h5>
                <p><?= date($settings->get('date_format')); ?></p>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="input-icon-start pos-search position-relative">
                    <span class="input-icon-addon">
                        <i class="ti ti-search"></i>
                    </span>
                    <input type="text" class="form-control" placeholder="Search Product">
                </div>
                <a href="#" class="btn btn-sm btn-primary">View All Categories</a>
            </div>
        </div>
        <ul class="tabs owl-carousel pos-category3 mb-4">
            <li id="all">
                <h6><a href="javascript:void(0);">Overview</a></h6>
            </li>
            <li id="new" class="active">
                <h6><a href="javascript:void(0);">Add Sales</a></h6>
            </li>
        </ul>
        <div class="pos-products">
            <div class="tabs_container">
                <div class="tab_content" data-tab="all"></div>
                <div class="tab_content active" data-tab="new">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                            <div class="search-set">
                                <div class="search-input">
                                    <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
                                </div>
                            </div>
                            <div class="d-flex table-dropdown my-xl-auto right-content align-items-center flex-wrap row-gap-3">
                                <?php if (isset($_GET['action']) && $_GET['action'] === 'filter'): ?>
                                    <a href="products.php" class="btn btn-secondary me-2">Clear Filter</a>
                                <?php endif; ?>
                                <div class="dropdown me-2">
                                    <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                        Category
                                    </a>
                                    <ul class="dropdown-menu  dropdown-menu-end p-3">
                                        <?php
                                        $categories = $categoryModel->getCategories();
                                        if ($categories):
                                            foreach ($categories as $category):
                                        ?>
                                                <li>
                                                    <a href="products.php?action=filter&category=<?= htmlspecialchars($category['id']) ?>" class="dropdown-item rounded-1"><?= htmlspecialchars($category['name']) ?></a>
                                                </li>
                                        <?php
                                            endforeach;
                                        endif;
                                        ?>
                                </div>
                                <?php
                                $brands = $brandModel->getBrands();
                                if ($brands):
                                ?>
                                    <div class="dropdown">
                                        <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                            Brand
                                        </a>
                                        <ul class="dropdown-menu  dropdown-menu-end p-3">
                                            <?php
                                            foreach ($brands as $brand):
                                            ?>
                                                <li>
                                                    <a href="javascript:void(0);" class="dropdown-item rounded-1"><?= htmlspecialchars($brand['name']) ?></a>
                                                </li>
                                            <?php
                                            endforeach;

                                            ?>
                                        </ul>
                                    </div>
                                <?php
                                endif;
                                ?>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table datatable">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Brand</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th class="no-sort"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($products):
                                            foreach ($products as $product):
                                                $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                                                $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                                        ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <a href="javascript:void(0);"><?= htmlspecialchars($product['name']) ?></a>
                                                        </div>
                                                    </td>
                                                    <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                                    <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                                    <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                                    <td><?= intval($product['quantity']) ?></td>
                                                    <td class="action-table-data">
                                                        <div class="edit-delete-action">

                                                            <a data-bs-toggle="modal" data-bs-target="#delete-modal" class="p-2" href="javascript:void(0);">
                                                                <i data-feather="cart" class="feather-cart"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                        <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>