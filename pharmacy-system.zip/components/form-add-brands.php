<form id="add-brand-form">
    <div class="modal-body">
        <div class="mb-3">
            <div class="respond-form"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Brand<span class="text-danger ms-1">*</span></label>
            <input type="text" name="brand" class="form-control">
            <input type="hidden" name="brand_type" value="new">
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn me-2 btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <?php echo renderSubmitButton('Add Brand', 'addBrand', ''); ?>
    </div>
</form>