<form id="add-category-form">
    <div class="modal-body">
        <div class="mb-3">
            <div class="respond-form"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Category<span class="text-danger ms-1">*</span></label>
            <input type="text" name="category" class="form-control">
            <input type="hidden" name="category_type" value="new">
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn me-2 btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <?php echo renderSubmitButton('Add Category', 'addCategory', ''); ?>
    </div>
</form>