
<?php require 'config/session.php'; ?>
<?php
customHead($content = [
    "<link rel='stylesheet' href='assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'>"
]);
?>
<?php include 'head.php'; ?>
<?php include 'components/sidebar.php'; ?>
<?php include 'components/header.php'; ?>
<?php
$categoryModel = new Category();
$brandModel = new Brands();
$dosageFormModel = new DosageForm();
?>


<?php if ((isset($_GET['page']) && $_GET['page'] === 'level')): ?>
<?php include 'views/stock-level.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'filter')): ?>
<?php include 'views/product-lists.php'; ?>
<?php endif; ?>

<?php if ((isset($_GET['page']) && $_GET['page'] === 'expire')): ?>
<?php include 'views/stock-expired.php'; ?>
<?php endif; ?>

<?php
customFooter([
    "<script src='assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js'></script>"
]);
?>
<?php require 'components/footer.php'; ?>