<?php require 'config/session.php'; ?>
<?php include 'head.php'; ?>
<?php include 'components/sidebar.php'; ?>
<?php include 'components/header.php'; ?>


<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold">Settings</h4>
            <h6>Manage your settings on portal</h6>
        </div>
    </div>
    <ul class="table-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header">
                <i class="ti ti-chevron-up"></i>
            </a>
        </li>
    </ul>
</div>

<div class="row">
    <div class="col-xl-12">
        <div class="settings-wrapper d-flex">
            <?php include_once 'components/settings-sidebar.php'; ?>
            <?php if (!isset($_GET['gs']) && !isset($_GET['ps']) && !isset($_GET['fs'])): ?>
                <?php include_once 'views/settings-profile.php'; ?>
            <?php endif; ?>
            <?php if (isset($_GET['gs'])): ?>
                <?php if ($_GET['gs'] === 'profile'): ?>
                    <?php include_once 'views/settings-profile.php'; ?>
                <?php elseif ($_GET['gs'] === 'security'): ?>
                    <?php include_once 'views/settings-security.php'; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($_GET['ps'])): ?>
                <?php if ($_GET['ps'] === 'company'): ?>
                    <?php include_once 'views/settings-company.php'; ?>
                <?php elseif ($_GET['ps'] === 'localization'): ?>
                    <?php include_once 'views/settings-localization.php'; ?>
                <?php elseif ($_GET['ps'] === 'appearance'): ?>
                    <?php include_once 'views/settings-appearance.php'; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($_GET['fs'])): ?>
                <?php if ($_GET['fs'] === 'payment'): ?>
                    <?php include_once 'views/settings-finance.php'; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require 'components/footer.php'; ?>