<!-- @format -->

# Pharmacy Management System – Full Documentation (README)

## 📘 Project Overview

**Pharmacy Management System** is a full-featured web application built with PHP, MySQL, HTML, CSS, Bootstrap, and jQuery. It is designed for local-first use via XAMPP, with optional support for online syncing, premium updates, and LAN access for multi-user usage.

> ⚙️ This system supports small-to-medium pharmacies with features such as inventory management, point of sale (POS), restocking, user roles, reporting, and license-based updates.

---

## 📁 Project Structure

```
/pharmacy
│
├── assets/               # CSS, JS, Images
├── includes/             # DB connection, functions, session
├── modules/              # Sales, Purchases, Inventory, Users
├── pages/                # Dashboard, Login, POS, Reports
├── templates/            # Header, Footer, Layouts
├── index.php             # Entry point
├── login.php             # Login page
├── logout.php            # Logout logic
├── update-agent.php      # Checks for updates (if online)
├── config.php            # DB connection and constants
├── pharmacy_schema.sql   # DB Schema
└── README.md             # This file

```

---

## 🗃️ Database: `pharmacy_db`

(See section below for full table structure and ERD)

Includes tables for:

- medicines
- categories
- suppliers
- customers
- users (admin, cashier, pharmacist)
- purchases & purchase_items
- sales & sales_items
- stock_logs (history)
- settings (for licensing & configs)

---

## 🧩 Key Features

### ✅ Inventory Management

- Add/update medicine stock
- Batch numbers and expiry dates
- Restock via purchase orders

### 💰 Sales & POS

- Fast medicine search
- Real-time stock checks
- Discounts, subtotal, totals
- Invoice printing

### 🧾 Purchase Management

- Record supplier stock entries
- Track cost prices and expiry

### 👥 User Roles & Access

- Admin, Cashier, Pharmacist
- Role-based navigation & permissions

### 📊 Reports

- Daily/weekly/monthly sales
- Low stock alerts
- Expiry alerts
- Transaction history

### 🌐 Multi-user (LAN)

- One computer acts as XAMPP server
- Other computers access via browser using local IP (e.g. http://192.168.0.10/pharmacy)

### 🔐 Licensing & Sync (Premium Optional)

- License key stored in `settings`
- Syncs with remote server for:
  - Updates
  - Backup
  - Unlocking premium features

---

## 🔗 ER Diagram Summary

(Use tools like dbdiagram.io or MySQL Workbench to visualize)

Relationships:

- `sales` ↔ `sales_items` ↔ `medicines`
- `purchases` ↔ `purchase_items` ↔ `medicines`
- `users` linked to most actions
- `suppliers` & `categories` linked to `medicines`

---

## 🧠 Developer Notes

- Use `mysqli` or `PDO` with prepared statements for all queries.
- Passwords hashed using `password_hash()`.
- Use transactions for multi-step logic like purchases/sales.
- Sync agent (update-agent.php) checks remote API for updates or license.
- Use `stock_logs` for any manual or automatic stock changes (like rollback).

---

## 🧪 Testing & Sample Data

To simulate real scenarios, load sample data for:

- At least 10 medicine categories
- 3 suppliers
- 50 medicines (random batches/expiry)
- 2 users: admin and cashier

You can write a seeder file or provide a SQL sample.

---

## ⚙️ Local Setup Instructions

1. Install [XAMPP](https://www.apachefriends.org/)
2. Copy this project to `htdocs/pharmacy`
3. Start Apache & MySQL in XAMPP
4. Open [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
5. Create `pharmacy_db` and import `pharmacy.sql`
6. Launch app: [http://localhost/pharmacy](http://localhost/pharmacy)
7. Login with default admin:
   - Username: `admin`
   - Password: `1234`

---

## 📡 Remote Update Instructions (Optional)

1. Place update ZIP on your remote server.
2. `update-agent.php` will check version vs online.
3. If a newer version exists, prompt admin for update.
4. Unzip and replace only changed files (using hash).

---

## 📈 Next Steps

- [ ] Build versioned API for syncing
- [ ] Add mobile-first responsive UI
- [ ] Add export to Excel / PDF
- [ ] Add customer prescription module
- [ ] Add SMS/email integration (premium)

---

## 🧾 Contact / Credits

Developed by Clottware
For support, contact: [support@clottware.com] or visit [clottware.com]

---

_Keep this README updated with any architecture, logic, or database changes._
