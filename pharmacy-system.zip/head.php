<!DOCTYPE html>
<html lang="en">

<head>

    <?= getHeadContent(); ?>

    <script>
        // Pass PHP server time to JavaScript
        var serverTime = "<?php echo date('H'); ?>";
    </script>
</head>

<body class="<?= isset($bodyClass) ? $bodyClass : ''; ?>">
    <main class="main-wrapper <?= isset($mainClass) ? $mainClass : ''; ?>">