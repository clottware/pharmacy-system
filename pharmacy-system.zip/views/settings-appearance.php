<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Appearance</h4>
    </div>
    <div class="card-body">
        <form action="appearance.html">
            <div class="appearance-settings">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="setting-info mb-4">
                            <h6 class="mb-1">Select Theme</h6>
                            <p>Choose accent colour of website</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="theme-type d-flex align-items-center mb-4">
                            <select class="select">
                                <option><?= $settings->get('language') ?></option>
                            </select>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="setting-info mb-4">
                            <h6 class="mb-1">Accent Color</h6>
                            <p>Choose accent colour of website</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="theme-colors mb-4">
                            <ul>
                                <li>
                                    <span class="themecolorset defaultcolor active"></span>
                                </li>
                                <li>
                                    <span class="themecolorset theme-violet"></span>
                                </li>
                                <li>
                                    <span class="themecolorset theme-blue"></span>
                                </li>
                                <li>
                                    <span class="themecolorset theme-brown"></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php
function pageModal()
{
    return null;
}
?>