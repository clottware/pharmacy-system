<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4 class="fs-18 fw-bold">Localization</h4>
    </div>
    <div class="card-body">
        <form action="localization-settings.html">
            <div class="border-bottom mb-3">
                <div class="card-title-head">
                    <h6 class="fs-16 fw-bold mb-3">
                        <span class="fs-18 me-2"><i class="ti ti-list"></i></span>
                        Basic Information
                    </h6>
                </div>
                <div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Language</h6>
                                <p>Select Language of the Website</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <select class="select">
                                    <option><?= $settings->get('language') ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Timezone</h6>
                                <p>Select Time zone in website</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <select class="select">
                                    <option><?php echo $settings->get('timezone'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Date Format</h6>
                                <p>Portal full date formate</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <?= date($settings->get('date_format_time')) ?>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Short Date</h6>
                                <p>Portal short date format</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <?= date($settings->get('short_date')) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom mb-3">
                <div class="card-title-head">
                    <h6 class="fs-16 fw-bold mb-3">
                        <span class="fs-18 me-2"><i class="ti ti-credit-card"></i></span>
                        Currency Settings
                    </h6>
                </div>
                <div class="localization-info">
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Currency</h6>
                                <p>Select portal Currency</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <span><?php echo $settings->get('currency'); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Currency Separator</h6>
                                <p>Portal currency separator</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <span><?= $settings->get('currency_sep') ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <h6 class="mb-1 fw-medium">Numbers</h6>
                                <p>Portal number format</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="localization-select ms-sm-auto mb-3">
                                <span><?= $settings->get('numbers_format') ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
function pageModal()
{
    return null;
}
?>