<div class="card flex-fill mb-0">
    <div class="card-header">
        <h4>Payment Gateway</h4>
    </div>
    <div class="card-body pb-0">
        <div class="row">
            <div class="col-xxl-4 col-xl-6 col-lg-12 col-md-6 d-flex">
                <div class="card flex-fill">
                    <div class="w-100 card-body">
                        <div class="d-flex flex-column align-items-start">
                            <div class="d-flex align-items-center justify-content-between w-100 mb-2">
                                <div class="d-flex align-items-center">
                                    <span>
                                        <img src="<?= ASSETS_PATH ?>/images/apps/paystack-logo.png" alt="Payment" height="50" width="50">
                                    </span>
                                </div>
                                <span class="badge border text-dark">Not connected</span>
                            </div>
                            <p class="mb-3">Accept mobile money and credit/debit card payment with PayStack</p>
                        </div>
                        <div class="d-flex align-items-center justify-content-between border-top pt-3">
                            <a href="javascript:void(0);" aria-disabled="true" class="btn btn-sm btn-outline-secondary">
                                <i class="ti ti-lock me-2"></i>Connect
                            </a>
                            <div class="status-toggle modal-status d-flex justify-content-between align-items-center ms-2">
                                <input type="checkbox" disabled id="user2" class="check">
                                <label for="user2" class="checktoggle"> </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
function pageModal()
{
    return null;
}
?>