<?php
$product = null;
if (isset($_GET['id'])) {
    $productModel = new Product();
    $product = $productModel->getProductById($_GET['id']);
}
?>
<!-- Page Header -->
<div class="page-header">
    <div class="add-item d-flex">
        <div class="page-title">
            <h4 class="fw-bold"><?php echo isset($_GET['id']) ? 'Edit Product' : 'Create Product'; ?></h4>
            <h6><?php echo isset($_GET['id']) ? 'Edit product details' : 'Create new product'; ?></h6>
        </div>
    </div>
    <div class="page-btn mt-0">
        <a href="products" class="btn btn-secondary"><i data-feather="arrow-left" class="me-2"></i>Back to Product</a>
    </div>
</div>

<form id="medicineForm" class="add-product-form">
    <div class="add-product">
        <div class="accordions-items-seperate" id="productFormWizard">
            <div class="accordion-item border mb-4">
                <h2 class="accordion-header" id="headingSpacingOne">
                    <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse" data-bs-target="#SpacingOne" aria-expanded="true" aria-controls="SpacingOne">
                        <div class="d-flex align-items-center justify-content-between flex-fill">
                            <h5 class="d-flex align-items-center"><i data-feather="info" class="text-primary me-2"></i><span>Product Information</span></h5>
                        </div>
                    </div>
                </h2>
                <div id="SpacingOne" class="accordion-collapse collapse show" aria-labelledby="headingSpacingOne">
                    <div class="accordion-body border-top">
                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3 position-relative">
                                    <label class="form-label" for="product_name">Product Name<span class="text-danger ms-1">*</span></label>
                                    <input type="text" name="product_name" id="product_name" class="form-control" autocomplete="off" value="<?= $product['name'] ?? '' ?>" required>
                                    <?php if (isset($_GET['id'])): ?>
                                        <input type="hidden" name="product_id" value="<?= htmlspecialchars($_GET['id']) ?>">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="addservice-info">
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <div class="add-newplus">
                                            <label class="form-label">Category<span class="text-danger ms-1">*</span></label>
                                            <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#add-product-category"><i data-feather="plus-circle" class="plus-down-add"></i><span>Add
                                                    New</span></a>
                                        </div>
                                        <select class="select" name="category_id" id="category_id" required>
                                            <option>Select</option>
                                            <?php
                                            // Get categories from the database
                                            $categories = $categoryModel->getCategories(); // $categoryModel is your Category class instance
                                            ?>
                                            <?php foreach ($categories as $category) : ?>
                                                <option value="<?= htmlspecialchars($category['id']) ?>" <?= isset($_GET['id']) && $product['category_id'] == $category['id'] ? 'selected' : '' ?>><?= htmlspecialchars($category['name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <div class="add-newplus">
                                            <label class="form-label">Brands</label>
                                            <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#add-product-brand"><i data-feather="plus-circle" class="plus-down-add"></i><span>Add
                                                    New</span></a>
                                        </div>
                                        <select class="select" name="brand_id" id="brand_id">
                                            <option>Select</option>
                                            <?php
                                            // Get categories from the database
                                            $brands = $brandModel->getBrands(); // $brandModel is your Brand class instance
                                            ?>
                                            <?php foreach ($brands as $brand) : ?>
                                                <option value="<?= htmlspecialchars($brand['id']) ?>" <?= isset($_GET['id']) && $product['brand_id'] == $brand['id'] ? 'selected' : '' ?>><?= htmlspecialchars($brand['name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="add-product-new">
                            <div class="row">
                                <div class="col-sm-6 col-12" id="dosage_form_div" style="display: <?= $product['category_id'] === 5 ? 'block' : 'none' ?>;">
                                    <div class="mb-3">
                                        <div class="add-newplus">
                                            <label class="form-label">Dosage Form<span class="text-danger ms-1">*</span></label>
                                        </div>
                                        <select class="select" name="dosage_form" id="dosage_form">
                                            <option>Select</option>
                                            <?php
                                            // Get dosage forms from the database
                                            $dosageForms = $dosageFormModel->getDosageForm(); // $dosageFormModel is your DosageForm class instance
                                            ?>
                                            <?php foreach ($dosageForms as $dosageForm) : ?>
                                                <option value="<?= htmlspecialchars($dosageForm['id']) ?>" <?= isset($_GET['id']) && $product['dosage_form'] == $dosageForm['id'] ? 'selected' : '' ?>><?= htmlspecialchars($dosageForm['name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12" id="expiry_date_div">
                                    <div class="mb-3">
                                        <label class="form-label">Expiry On<span class="text-danger ms-1" style="display:none">*</span></label>

                                        <div class="input-groupicon calender-input">
                                            <i data-feather="calendar" class="info-img"></i>
                                            <input type="text" class="datetimepicker form-control" id="expiry_date" value="<?= $product['expiry_date'] ?? '' ?>" name="expiry_date" placeholder="dd/mm/yyyy">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- pricing -->
            <div class="accordion-item border mb-4">
                <h2 class="accordion-header" id="headingSpacingTwo">
                    <div class="accordion-button collapsed bg-white" data-bs-toggle="collapse" data-bs-target="#SpacingTwo" aria-expanded="true" aria-controls="SpacingTwo">
                        <div class="d-flex align-items-center justify-content-between flex-fill">
                            <h5 class="d-flex align-items-center"><i data-feather="life-buoy" class="text-primary me-2"></i><span>Pricing & Stocks</span></h5>
                        </div>
                    </div>
                </h2>
                <div id="SpacingTwo" class="accordion-collapse collapse show" aria-labelledby="headingSpacingTwo">
                    <div class="accordion-body border-top">
                        <div class="mb-3s">
                            <div class="single-product">
                                <div class="row">
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Purchase Price<span class="text-danger ms-1">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><?php echo $settings->get('currency_symbol'); ?></span>

                                                <input type="number" name="purchase_price" step="0.01" min="0" class="form-control" value="<?= $product['cost_price'] ?? '' ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Selling Price<span class="text-danger ms-1">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><?php echo $settings->get('currency_symbol'); ?></span>

                                                <input type="number" name="selling_price" step="0.01" min="0" class="form-control" value="<?= $product['price'] ?? '' ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Quantity<span class="text-danger ms-1">*</span></label>
                                            <input class="form-control" type="number" name="quantity" min="0" required value="<?= $product['quantity'] ?? '' ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Quantity Alert<span class="text-danger ms-1">*</span></label>
                                            <input type="number" name="quantity_alert" min="0" class="form-control" value="<?= $product['min_qty'] ?? '' ?>" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="d-flex align-items-center justify-content-end mb-4">
            <button type="button" class="btn btn-secondary me-2" onclick="window.location.href='products.php'">Cancel</button>
            <?php echo renderSubmitButton('Add Product', 'addProduct', ''); ?>
        </div>
    </div>
</form>

<?php
function pageModal()
{
    ob_start();
?>
    <!-- Add Category -->
    <div class="modal fade" id="add-product-category">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="page-title">
                        <h4>Add Category</h4>
                    </div>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <?php include_once 'components/form-add-categories.php'; ?>
            </div>
        </div>
    </div>
    <!-- Add Brand -->
    <div class="modal fade" id="add-product-brand">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="page-title">
                        <h4>Add Brand</h4>
                    </div>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php require 'components/form-add-brands.php'; ?>
            </div>
        </div>
    </div>
<?php
}
?>
<script>
    $(document).ready(function() {

        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            },
        });

        // function to handle toaster
        function toaster(type, message) {
            Toast.fire({
                icon: type,
                title: message,
            });
        }
        // add new category
        $('#add-category-form').on('submit', function(e) {
            e.preventDefault();

            let $form = $(this);
            let $btn = $('#add-category-form button[type="submit"]');
            let $spinner = $('#loader-spinner');
            $('.formResponse').empty();

            $.ajax({
                url: 'controllers/category.php',
                method: 'POST',
                data: $form.serialize(),
                dataType: 'json',
                beforeSend: function() {
                    $btn.prop('disabled', true);
                    $spinner.removeClass('d-none');
                },
                success: function(response) {
                    // Handle success
                    if (response.status) {
                        // Append new category to the category select dropdown
                        let newOption = new Option(response.categories.category, response.categories.category_id, false, false);
                        $('#category_id').append(newOption).trigger('change');

                        // Reset the form
                        $form[0].reset();
                        toaster('success', response.message);

                        // Close the modal after a short delay
                        setTimeout(function() {
                            $('#add-product-category').modal('hide');
                            $('.respond-form').empty();
                        }, 1000);
                    } else {
                        toaster('error', response.message);
                    }
                },
                error: function(error) {
                    // Handle error
                    $('.formResponse').html(
                        '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
                    );
                }
            });
        });

        // add new brand
        $('#add-brand-form').on('submit', function(e) {
            e.preventDefault();

            let $form = $(this);
            let $btn = $('#add-brand-form button[type="submit"]');
            let $spinner = $('#loader-spinner');
            $('.respond-form').empty();

            $.ajax({
                url: 'controllers/brands.php',
                method: 'POST',
                data: $form.serialize(),
                dataType: 'json',
                beforeSend: function() {
                    $btn.prop('disabled', true);
                    $spinner.removeClass('d-none');
                },
                success: function(response) {
                    // Handle success
                    if (response.status) {
                        // Append new brand to the brand select dropdown
                        let newOption = new Option(response.brands.brand, response.brands.brand_id, false, false);
                        $('#brand_id').append(newOption).trigger('change');

                        // Reset the form
                        $form[0].reset();
                        toaster('success', response.message);

                        // Close the modal after a short delay
                        setTimeout(function() {
                            $('#add-product-brand').modal('hide');
                            $('.respond-form').empty();
                        }, 1000);
                    } else {
                        toaster('error', response.message);
                    }
                },
                error: function(error) {
                    // Handle error
                    $('.formResponse').html(
                        '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
                    );
                }
            });
        });
        // if category select is medicine show the dosage form div else hide it
        $('#category_id').on('change', function() {
            //let selectedText = $("#category_id option:selected").text().toLowerCase();
            var selectedValue = $(this).val();
            if (selectedValue === '5') { // Assuming '5' is the ID for 'medicine' category
                $('#dosage_form_div').show();
                $('#dosage_form').prop('required', true);
                $('#expiry_date').prop('required', true);
                $('#expiry_date_div label span').show();
            } else {
                $('#dosage_form_div').hide();
                $('#dosage_form').prop('required', false);
                $('#expiry_date').prop('required', false);
                $('#expiry_date_div label span').hide();
            }
        });

        //submit medicine form
        $('#medicineForm').on('submit', function(e) {
            e.preventDefault();

            let formData = $(this).serialize(); // grabs all inputs

            $.ajax({
                url: 'controllers/products.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    // You can add a loader here if needed
                },
                success: function(response) {
                    // Handle success
                    if (response.status) {
                        // Reset the form
                        $('#medicineForm')[0].reset();
                        toaster('success', response.message);

                        // Optionally, redirect to another page or update the UI
                        setTimeout(function() {
                            window.location.href = 'products.php'; // Redirect to products page
                        }, 1000);
                    } else {
                        toaster('error', response.message);
                    }
                },
                error: function(error) {
                    // Handle error
                    $('.formResponse').html(
                        '<div class="alert alert-danger">Something went wrong. Please try again later.</div>'
                    );
                }
            });
        });
    });
</script>