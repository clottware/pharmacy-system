<?php
$productModel = new Product();
$categoryModel = new Category();
$brandModel = new Brands();
$productId = $_GET['id'] ?? null;
$product = $productModel->getProductById($productId);
$category = $categoryModel->getCategoryById($product['category_id'] ?? null);
$brand = $brandModel->getBrandsById($product['brand_id'] ?? null);
$account = $auth->getUserById($product['user_id'] ?? null);
?>
<div class="page-header">
    <div class="page-title">
        <h4>Product Details</h4>
        <h6>Full details of a product</h6>
    </div>
</div>
<!-- /add -->
<div class="row">
    <div class="col-lg-8 col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="productdetails">
                    <ul class="product-bar">
                        <li>
                            <h4>Product</h4>
                            <h6><?= $product['name'] ?? '' ?></h6>
                        </li>
                        <li>
                            <h4>Category</h4>
                            <h6><?= $category['name'] ?? '' ?></h6>
                        </li>
                        <li>
                            <h4>Brand</h4>
                            <h6><?= $brand['name'] ?? '-' ?></h6>
                        </li>
                        <li>
                            <h4>Minimum Qty</h4>
                            <h6><?= $product['min_qty'] ?? 0 ?></h6>
                        </li>
                        <li>
                            <h4>Quantity</h4>
                            <h6><?= $product['quantity'] ?? 0 ?></h6>
                        </li>
                        <?php if ($product['category_id'] === 5): ?>
                            <li>
                                <h4>Dosage Form</h4>
                                <h6><?= $product['dosage_form'] ?? '' ?></h6>
                            </li>
                        <?php endif; ?>
                        <li>
                            <h4>Cost Price</h4>
                            <h6><?= $product['cost_price'] ?? 0 ?></h6>
                        </li>
                        <li>
                            <h4>Price</h4>
                            <h6><?= $product['price'] ?? 0 ?></h6>
                        </li>
                        <li>
                            <h4>Expiry Date</h4>
                            <h6><?= date($settings->get('date_format'), strtotime($product['expiry_date'])) ?? '' ?></h6>
                        </li>
                        <li>
                            <h4>Status</h4>
                            <h6>Active</h6>
                        </li>
                        <li>
                            <h4>Created By</h4>
                            <h6 class="text-capitalize"><?= $account['username'] ?? '-' ?></h6>
                        </li>
                        <li>
                            <h4>Created At</h4>
                            <h6><?= date($settings->get('date_format'), strtotime($product['created_at'])) ?? '' ?></h6>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="product-actions">
                    <h3 class="mb-4">Actions</h3>
                    <a href="products.php?action=edit&id=<?= $product['id'] ?>" class="btn btn-primary w-100 mb-3">
                        <i data-feather="eye" class="feather-edit me-1"></i>
                        Edit
                    </a>
                    <button class="btn btn-danger w-100 mb-3" data-bs-toggle="modal" data-bs-target="#delete-modal">
                        <i data-feather="trash-2" class="feather-trash-2 me-1"></i>
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /add -->
<?php
function pageModal()
{
    ob_start();
?>
    <!-- delete modal -->
    <?php echo confirmationModal('Delete Product', 'Are you sure you want to delete this product?', 'Yes Delete', 'Cancel'); ?>
    <!-- /delete modal -->
<?php
    return ob_get_clean();
}
?>

<script>
    $(document).ready(function() {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            },
        });

        // function to handle toaster
        function toaster(type, message) {
            Toast.fire({
                icon: type,
                title: message,
            });
        }

        $(document).on('click', '#delete-modal button.btn-primary', function() {
            let productId = $(this).data('id');

            $.ajax({
                url: 'controllers/products', // backend delete handler
                type: 'POST',
                dataType: 'json',
                data: {
                    product_type: 'delete',
                    product_id: productId,
                },
                success: function(response) {
                    if (response.status) {
                        // show success message
                        toaster('success', response.message || 'Product deleted successfully');
                        // redirect to products list after 1.5 seconds
                        setTimeout(() => {
                            window.location.href = 'products';
                        }, 1500);
                    } else {
                        alert(response.message || 'Failed to delete product');
                    }
                },
                error: function() {
                    alert('An error occurred while deleting the product.');
                },
            });
        });
    });
</script>