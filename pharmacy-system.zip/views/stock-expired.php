<?php

/**
 * Product List View
 */

$productModel = new Product();
$categoryModel = new Category();
$brandModel = new Brands();
if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
    $products = $productModel->getProductsByCategory($_GET['category']);
} else {
    $products = $productModel->expiredProducts();
}
?>
<div class="page-header">
    <div class="page-title me-auto">
        <h4 class="fw-bold">Expired Products</h4>
        <h6>Manage your expired products</h6>
    </div>
    <ul class="table-top-head low-stock-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
        </li>
        <li class="d-none">
            <a href="#" class="btn btn-secondary w-auto shadow-none" data-bs-toggle="modal" data-bs-target="#send-email"><i data-feather="mail" class="feather-mail"></i>Send Email</a>
        </li>
    </ul>
</div>
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
        <div class="search-set">
            <div class="search-input">
                <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table datatable">
                <thead class="thead-light">
                    <tr>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Created By</th>
                        <th class="no-sort"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($products):
                        foreach ($products as $product):
                            $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                            $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                    ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:void(0);"><?= htmlspecialchars($product['name']) ?></a>
                                    </div>
                                </td>
                                <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                <td><?= intval($product['quantity']) ?></td>
                                <td><?= date($settings->get('date_format'), strtotime($product['created_at'])) ?></td>
                                <td class="action-table-data">
                                    <div class="edit-delete-action">
                                        <a class="me-2 edit-icon  p-2" href="?action=view&id=<?= $product['id'] ?>">
                                            <i data-feather="eye" class="feather-eye"></i>
                                        </a>
                                        <a class="me-2 p-2" href="?action=edit&id=<?= $product['id'] ?>">
                                            <i data-feather="edit" class="feather-edit"></i>
                                        </a>
                                        <a data-bs-toggle="modal" data-bs-target="#delete-modal" class="p-2" href="javascript:void(0);">
                                            <i data-feather="trash-2" class="feather-trash-2"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
function pageModal()
{
    return null;
}
?>