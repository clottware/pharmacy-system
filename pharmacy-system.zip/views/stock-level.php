<div class="page-header">
    <div class="page-title me-auto">
        <h4 class="fw-bold">Low Stocks</h4>
        <h6>Manage your low stocks</h6>
    </div>
    <ul class="table-top-head low-stock-top-head">
        <li>
            <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i class="ti ti-chevron-up"></i></a>
        </li>
        <li class="d-none">
            <a href="#" class="btn btn-secondary w-auto shadow-none" data-bs-toggle="modal" data-bs-target="#send-email"><i data-feather="mail" class="feather-mail"></i>Send Email</a>
        </li>
    </ul>
</div>

<div class="mb-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
        <ul class="nav nav-pills low-stock-tab d-flex me-2 mb-0" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Low Stocks</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Out of Stocks</button>
            </li>

        </ul>
        <div class="notify d-none bg-white p-1 px-2 border rounded">
            <div class="status-toggle text-secondary d-flex justify-content-between align-items-center">
                <input type="checkbox" id="user2" class="check" checked="">
                <label for="user2" class="checktoggle me-2">checkbox</label>
                Notify
            </div>
        </div>
    </div>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <?php

            /**
             * Product List View
             */

            $productModel = new Product();
            $categoryModel = new Category();
            $brandModel = new Brands();
            if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
                $products = $productModel->productStockLevel($_GET['category']);
            } else {
                $products = $productModel->productStockLevel();
            }
            ?>
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                    <div class="search-set">
                        <div class="search-input">
                            <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
                        </div>
                    </div>

                    <div class="d-flex table-dropdown my-xl-auto right-content align-items-center flex-wrap row-gap-3">
                        <?php if (isset($_GET['action']) && $_GET['action'] === 'filter'): ?>
                            <a href="products.php" class="btn btn-secondary me-2">Clear Filter</a>
                        <?php endif; ?>
                        <div class="dropdown me-2">
                            <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                Category
                            </a>
                            <ul class="dropdown-menu  dropdown-menu-end p-3">
                                <?php
                                $categories = $categoryModel->getCategories();
                                if ($categories):
                                    foreach ($categories as $category):
                                ?>
                                        <li>
                                            <a href="products.php?action=filter&category=<?= htmlspecialchars($category['id']) ?>" class="dropdown-item rounded-1"><?= htmlspecialchars($category['name']) ?></a>
                                        </li>
                                <?php
                                    endforeach;
                                endif;
                                ?>
                        </div>
                        <?php
                        $brands = $brandModel->getBrands();
                        if ($brands):
                        ?>
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                    Brand
                                </a>
                                <ul class="dropdown-menu  dropdown-menu-end p-3">
                                    <?php
                                    foreach ($brands as $brand):
                                    ?>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1"><?= htmlspecialchars($brand['name']) ?></a>
                                        </li>
                                    <?php
                                    endforeach;

                                    ?>
                                </ul>
                            </div>
                        <?php
                        endif;
                        ?>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table datatable">
                            <thead class="thead-light">
                                <tr>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Brand</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Created By</th>
                                    <th class="no-sort"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($products):
                                    foreach ($products as $product):
                                        $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                                        $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                                ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <a href="javascript:void(0);"><?= htmlspecialchars($product['name']) ?></a>
                                                </div>
                                            </td>
                                            <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                            <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                            <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                            <td><?= intval($product['quantity']) ?></td>
                                            <td><?= date($settings->get('date_format'), strtotime($product['created_at'])) ?></td>
                                            <td class="action-table-data">
                                                <div class="edit-delete-action">
                                                    <a class="me-2 edit-icon  p-2" href="?action=view&id=<?= $product['id'] ?>">
                                                        <i data-feather="eye" class="feather-eye"></i>
                                                    </a>
                                                    <a class="me-2 p-2" href="?action=edit&id=<?= $product['id'] ?>">
                                                        <i data-feather="edit" class="feather-edit"></i>
                                                    </a>
                                                    <a data-bs-toggle="modal" data-bs-target="#delete-modal" class="p-2" href="javascript:void(0);">
                                                        <i data-feather="trash-2" class="feather-trash-2"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                <?php
                                    endforeach;
                                endif;
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
            <?php

            /**
             * Product List View
             */

            $productModel = new Product();
            $categoryModel = new Category();
            $brandModel = new Brands();
            if (isset($_GET['action']) && $_GET['action'] === 'filter' && isset($_GET['category'])) {
                $products = $productModel->productStockLevel($_GET['category']);
            } else {
                $products = $productModel->outOfStockProducts();
            }
            ?>
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                    <div class="search-set">
                        <div class="search-input">
                            <span class="btn-searchset"><i class="ti ti-search fs-14 feather-search"></i></span>
                        </div>
                    </div>

                    <div class="d-flex table-dropdown my-xl-auto right-content align-items-center flex-wrap row-gap-3">
                        <?php if (isset($_GET['action']) && $_GET['action'] === 'filter'): ?>
                            <a href="products.php" class="btn btn-secondary me-2">Clear Filter</a>
                        <?php endif; ?>
                        <div class="dropdown me-2">
                            <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                Category
                            </a>
                            <ul class="dropdown-menu  dropdown-menu-end p-3">
                                <?php
                                $categories = $categoryModel->getCategories();
                                if ($categories):
                                    foreach ($categories as $category):
                                ?>
                                        <li>
                                            <a href="products.php?action=filter&category=<?= htmlspecialchars($category['id']) ?>" class="dropdown-item rounded-1"><?= htmlspecialchars($category['name']) ?></a>
                                        </li>
                                <?php
                                    endforeach;
                                endif;
                                ?>
                        </div>
                        <?php
                        $brands = $brandModel->getBrands();
                        if ($brands):
                        ?>
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle btn btn-white btn-md d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                    Brand
                                </a>
                                <ul class="dropdown-menu  dropdown-menu-end p-3">
                                    <?php
                                    foreach ($brands as $brand):
                                    ?>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1"><?= htmlspecialchars($brand['name']) ?></a>
                                        </li>
                                    <?php
                                    endforeach;

                                    ?>
                                </ul>
                            </div>
                        <?php
                        endif;
                        ?>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table datatable">
                            <thead class="thead-light">
                                <tr>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Brand</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Created By</th>
                                    <th class="no-sort"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($products):
                                    foreach ($products as $product):
                                        $category = $product['category_id'] ? $categoryModel->getCategoryById($product['category_id']) : null;
                                        $brand = $product['brand_id'] ? $brandModel->getBrandsById($product['brand_id']) : null;
                                ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <a href="javascript:void(0);"><?= htmlspecialchars($product['name']) ?></a>
                                                </div>
                                            </td>
                                            <td><?= $category != null ? htmlspecialchars($category['name']) : '-' ?></td>
                                            <td><?= $brand != null ? htmlspecialchars($brand['name']) : '-' ?></td>
                                            <td><?= $settings->get('currency_symbol'); ?> <?= number_format($product['price'], 2) ?></td>
                                            <td><?= intval($product['quantity']) ?></td>
                                            <td><?= date($settings->get('date_format'), strtotime($product['created_at'])) ?></td>
                                            <td class="action-table-data">
                                                <div class="edit-delete-action">
                                                    <a class="me-2 edit-icon  p-2" href="?action=view&id=<?= $product['id'] ?>">
                                                        <i data-feather="eye" class="feather-eye"></i>
                                                    </a>
                                                    <a class="me-2 p-2" href="?action=edit&id=<?= $product['id'] ?>">
                                                        <i data-feather="edit" class="feather-edit"></i>
                                                    </a>
                                                    <a data-bs-toggle="modal" data-bs-target="#delete-modal" class="p-2" href="javascript:void(0);">
                                                        <i data-feather="trash-2" class="feather-trash-2"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                <?php
                                    endforeach;
                                endif;
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
function pageModal()
{
    return null;
}
?>