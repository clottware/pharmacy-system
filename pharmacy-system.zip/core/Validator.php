<?php
// core/Validator.php

class Validator
{
    protected $errors = [];
    protected $data = [];

    public function validate(array $data, array $rules)
    {
        $this->errors = [];
        $this->data = $data;

        foreach ($rules as $field => $ruleSet) {
            $value = trim($data[$field] ?? '');

            foreach (explode('|', $ruleSet) as $rule) {
                $ruleName = $rule;
                $param = null;

                if (strpos($rule, ':') !== false) {
                    [$ruleName, $param] = explode(':', $rule);
                }

                $method = 'validate' . ucfirst($ruleName);
                if (method_exists($this, $method)) {
                    $this->$method($field, $value, $param);
                }
            }
        }

        return empty($this->errors);
    }

    public function errors()
    {
        return $this->errors;
    }

    protected function addError($field, $message)
    {
        $this->errors[$field][] = $message;
    }

    // === Rule methods ===

    protected function validateRequired($field, $value)
    {
        if ($value === '') {
            $this->addError($field, "$field is required.");
        }
    }

    protected function validateEmail($field, $value)
    {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, "$field must be a valid email.");
        }
    }

    protected function validateMin($field, $value, $param)
    {
        if (strlen($value) < $param) {
            $this->addError($field, "$field must be at least $param characters.");
        }
    }

    protected function validateMax($field, $value, $param)
    {
        if (strlen($value) > $param) {
            $this->addError($field, "$field must not exceed $param characters.");
        }
    }

    protected function validateMatch($field, $value, $param)
    {
        if (($this->data[$param] ?? '') !== $value) {
            $this->addError($field, "$field must match $param.");
        }
    }

    protected function validateUnique($field, $value, $param)
    {
        // $param = "table.column"
        [$table, $column] = explode('.', $param);
        $sql = "SELECT COUNT(*) FROM `$table` WHERE `$column` = :value";
        // $stmt = $db->prepare("SELECT COUNT(*) FROM `$table` WHERE `$column` = :value");
        // $stmt->execute(['value' => $value]);

        // if ($stmt->fetchColumn() > 0) {
        //     $this->addError($field, "$field already exists.");
        // }
    }
}
