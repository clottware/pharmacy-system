<?php

/**
 * API Class
 * 
 * Lightweight handler for basic REST API operations.
 */

class API
{
    public function __construct()
    {
        header("Content-Type: application/json");
    }

    /**
     * Respond with JSON
     */
    public function respond(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        echo json_encode($data);
        exit;
    }

    /**
     * Read JSON input body
     */
    public function getJsonInput(): array
    {
        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    /**
     * Validate request method
     */
    public function requireMethod(string $method): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
            $this->respond([
                'error' => "Method not allowed. Expected $method."
            ], 405);
        }
    }

    /**
     * Simple endpoint routing
     */
    public function route(): void
    {
        $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

        // Match /api/inventory or /api/inventory/{id}
        if (preg_match('#^api/inventory(?:/(\d+))?$#', $path, $matches)) {
            $id = $matches[1] ?? null;
            $this->handleInventory($id);
        } else {
            $this->respond(['error' => 'Endpoint not found.'], 404);
        }
    }

    /**
     * Example: Handle /api/inventory
     */
    private function handleInventory($id = null): void
    {
        require_once __DIR__ . '/Inventory.php';
        $inventory = new Inventory();

        switch ($_SERVER['REQUEST_METHOD']) {
            case 'GET':
                if ($id) {
                    $item = $inventory->find($id);
                    $this->respond($item ? $item : ['error' => 'Not found'], $item ? 200 : 404);
                } else {
                    $this->respond($inventory->all());
                }
                break;

            case 'POST':
                $data = $this->getJsonInput();
                $created = $inventory->create($data);
                $this->respond($created ? ['message' => 'Item created'] : ['error' => 'Failed'], $created ? 201 : 400);
                break;

            case 'PUT':
                if (!$id) $this->respond(['error' => 'Missing ID'], 400);
                $data = $this->getJsonInput();
                $updated = $inventory->update($id, $data);
                $this->respond($updated ? ['message' => 'Item updated'] : ['error' => 'Update failed'], $updated ? 200 : 400);
                break;

            case 'DELETE':
                if (!$id) $this->respond(['error' => 'Missing ID'], 400);
                $deleted = $inventory->delete($id);
                $this->respond($deleted ? ['message' => 'Item deleted'] : ['error' => 'Delete failed'], $deleted ? 200 : 400);
                break;

            default:
                $this->respond(['error' => 'Method not allowed'], 405);
        }
    }
}
