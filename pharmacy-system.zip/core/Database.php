<?php

/**
 * Database Class (Singleton)
 * 
 * PHP Version: 8.0+
 * Author: Clottware (Improved by GPT-5 😉)
 */

require_once __DIR__ . '/../config/config.php';

class Database
{
    private static ?Database $instance = null;

    private mysqli $conn;
    private ?mysqli_stmt $stmt = null;
    private string $error = '';

    private function __construct()
    {
        $this->connect();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function connect(): void
    {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        if ($this->conn->connect_error) {
            throw new Exception("Database connection failed: " . $this->conn->connect_error);
        }

        $this->conn->set_charset("utf8mb4");
    }

    private function detectParamTypes(array $params): string
    {
        $types = '';
        foreach ($params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_float($param)) {
                $types .= 'd';
            } elseif (is_string($param)) {
                $types .= 's';
            } else {
                $types .= 'b'; // blob or unknown
            }
        }
        return $types;
    }

    public function query(string $sql, array $params = []): bool
    {
        $this->stmt = $this->conn->prepare($sql);

        if (!$this->stmt) {
            throw new Exception("SQL prepare failed: " . $this->conn->error . " | Query: $sql");
        }

        if (!empty($params)) {
            $types = $this->detectParamTypes($params);
            if (!$this->stmt->bind_param($types, ...$params)) {
                throw new Exception("Parameter binding failed: " . $this->stmt->error);
            }
        }

        if (!$this->stmt->execute()) {
            throw new Exception("Query execution failed: " . $this->stmt->error);
        }

        return true;
    }

    public function fetch(string $sql, array $params = []): ?array
    {
        $this->query($sql, $params);
        $result = $this->stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function fetchAll(string $sql, array $params = []): array
    {
        $this->query($sql, $params);
        $result = $this->stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function insertId(): int
    {
        return $this->conn->insert_id;
    }

    public function insert(string $sql, array $params = []): int
    {
        $this->query($sql, $params);
        return $this->insertId();
    }

    public function update(string $sql, array $params = []): bool
    {
        return $this->query($sql, $params);
    }

    public function delete(string $sql, array $params = []): bool
    {
        return $this->query($sql, $params);
    }

    public function getError(): string
    {
        return $this->error;
    }

    public function close(): void
    {
        if ($this->stmt) {
            $this->stmt->close();
        }
        $this->conn->close();
    }
}
