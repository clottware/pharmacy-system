<?php

/**
 * Mailer Class
 * 
 * Simple wrapper for sending system emails.
 * Can be expanded later to use SMTP with PHPMailer.
 */

class Mailer
{
    private string $fromEmail;
    private string $fromName;
    private string $defaultSubjectPrefix;

    public function __construct(string $fromEmail = "no-reply@pharmacy.local", string $fromName = "Pharmacy System", string $subjectPrefix = "[Pharmacy]")
    {
        $this->fromEmail = $fromEmail;
        $this->fromName = $fromName;
        $this->defaultSubjectPrefix = $subjectPrefix;
    }

    /**
     * Send an email
     */
    public function send(string $to, string $subject, string $message, bool $isHtml = true): bool
    {
        $headers = "From: {$this->fromName} <{$this->fromEmail}>\r\n";
        $headers .= "Reply-To: {$this->fromEmail}\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();

        if ($isHtml) {
            $headers .= "\r\nContent-Type: text/html; charset=UTF-8";
        }

        $fullSubject = $this->defaultSubjectPrefix . " " . $subject;
        return mail($to, $fullSubject, $message, $headers);
    }

    /**
     * Format basic HTML message
     */
    public function formatHtml(string $body, string $title = "Notification"): string
    {
        return "
            <html>
            <head><title>{$title}</title></head>
            <body style='font-family:sans-serif;'>
                <div style='padding:20px;border:1px solid #ddd;background:#f9f9f9;'>
                    {$body}
                </div>
            </body>
            </html>
        ";
    }
}
