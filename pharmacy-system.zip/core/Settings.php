<?php

/**
 * Settings Class
 * 
 * Manages global and user-specific settings.
 */

class Settings
{
    private Database $db;
    private string $table = "settings";

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // Get setting by key (global or user-specific)
    public function get(string $key, ?int $user_id = null): ?string
    {
        $sql = "SELECT value FROM {$this->table} WHERE `key_name` = ?" . ($user_id ? " AND user_id = ?" : " AND user_id IS NULL");
        $params = $user_id ? [$key, $user_id] : [$key];
        $result = $this->db->fetch($sql, $params);
        return $result['value'] ?? null;
    }

    // Set or update setting
    public function set(string $key, string $value, ?int $user_id = null): bool
    {
        $exists = $this->get($key, $user_id);
        if ($exists !== null) {
            $sql = "UPDATE {$this->table} SET value = ?, updated_at = NOW() WHERE `key_name` = ?" . ($user_id ? " AND user_id = ?" : " AND user_id IS NULL");
            $params = $user_id ? [$value, $key, $user_id] : [$value, $key];
        } else {
            $sql = "INSERT INTO {$this->table} (`key_name`, `value`, `user_id`, `updated_at`) VALUES (?, ?, ?, NOW())";
            $params = [$key, $value, $user_id];
        }

        return $this->db->query($sql, $params);
    }

    // Delete setting
    public function delete(string $key, ?int $user_id = null): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE `key_name` = ?" . ($user_id ? " AND user_id = ?" : " AND user_id IS NULL");
        $params = $user_id ? [$key, $user_id] : [$key];
        return $this->db->query($sql, $params);
    }
}
