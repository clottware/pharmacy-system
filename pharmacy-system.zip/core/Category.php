<?php

class Category
{
    private $conn;
    private $table = "categories"; // table name in DB

    public function __construct()
    {
        $this->conn = Database::getInstance();
    }

    // Add new category
    public function addCategory(string $category): ?int
    {
        // Check if category already exists
        if ($this->categoryExists($category)) {
            return null; // Category already exists, return null
        }
        $sql = "INSERT INTO {$this->table} (name) VALUES (?)";

        if ($this->conn->insert($sql, [$category])) {
            return $this->conn->insertId(); // Return new category ID
        }

        return null; // Insert failed
    }

    // Update category
    public function updateCategory(int $id, string $category): bool
    {
        // Check if category already exists
        if ($this->categoryExists($category)) {
            return false; // Category already exists, return false
        }
        $sql = "UPDATE {$this->table} SET name = ? WHERE id = ?";
        return $this->conn->update($sql, [$category, $id]);
    }

    public function deleteCategory(int $id): bool
    {
        // Check if category exists
        if (!$this->getCategoryById($id)) {
            return false; // Category does not exist, return false
        }
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->conn->delete($sql, [$id]);
    }

    public function getCategories(): array
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY created_at DESC";
        return $this->conn->fetchAll($sql);
    }

    public function getCategoryById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        return $this->conn->fetch($sql, [$id]);
    }
    public function categoryExists(string $category): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE name = ?";
        $result = $this->conn->fetch($sql, [$category]);
        return $result['count'] > 0;
    }
}
