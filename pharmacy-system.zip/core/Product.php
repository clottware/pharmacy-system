<?php
class Product
{
    private $conn;
    private $table = "products"; // table name in DB

    public function __construct()
    {
        $this->conn = Database::getInstance();
    }

    // Get all products
    function getAllProducts()
    {
        $sql = "SELECT * FROM {$this->table}";
        $stmt = $this->conn->fetchAll($sql);
        return $stmt;
    }

    // get product by ID
    function getProductById($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $stmt = $this->conn->fetch($sql, [$id]);
        return $stmt;
    }


    /**
     * Insert new product
     */
    public function addProduct(array $data = [])
    {
        $sql = "INSERT INTO {$this->table} 
            (name, description, category_id, brand_id, dosage_form, batch_number, expiry_date, quantity, min_qty, cost_price, price,user_id, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $params = [
            $data['product_name'] ?? null,
            $data['description'] ?? null,
            $data['category_id'] ?? null,
            $data['brand_id'] ?? null,
            $data['dosage_form'] ?? null,
            $data['batch_number'] ?? null,
            $data['expiry_date'] ? date('Y-m-d', strtotime($data['expiry_date'])) : null,
            $data['quantity'] ?? 0,
            $data['min_qty'] ?? 0,
            $data['cost_price'] ?? 0.00,
            $data['selling_price'] ?? 0.00,
            $data['user_id'] ?? null,
            date('Y-m-d H:i:s')
        ];

        return $this->conn->insert($sql, $params);
    }

    /**
     * Update existing product
     */
    public function updateProduct(int $id, array $data = [])
    {
        $sql = "UPDATE {$this->table} 
                SET name = ?, 
                    description = ?, 
                    category_id = ?, 
                    brand_id = ?, 
                    dosage_form = ?, 
                    batch_number = ?, 
                    expiry_date = ?, 
                    quantity = ?,
                    min_qty = ?, 
                    cost_price = ?, 
                    price = ?, 
                    updated_at = ? 
                WHERE id = ?";

        $params = [
            $data['product_name'] ?? null,
            $data['description'] ?? null,
            $data['category_id'] ?? null,
            $data['brand_id'] ?? null,
            $data['dosage_form'] ?? null,
            $data['batch_number'] ?? null,
            $data['expiry_date'] ? date('Y-m-d', strtotime($data['expiry_date'])) : null,
            $data['quantity'] ?? 0,
            $data['min_qty'] ?? 0,
            $data['cost_price'] ?? 0.00,
            $data['selling_price'] ?? 0.00,
            date('Y-m-d H:i:s'),
            $id
        ];

        return $this->conn->update($sql, $params);
    }

    /**
     * Delete product by ID
     */
    public function deleteProduct(int $id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        $params = [$id];
        return $this->conn->delete($sql, $params);
    }

    // select all products by category
    public function getProductsByCategory($categoryId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE category_id = ?";
        $stmt = $this->conn->fetchAll($sql, [$categoryId]);
        return $stmt;
    }

    // get product by stock level
    public function productStockLevel($globalMin = null)
    {
        if ($globalMin !== null) {
            // Override all product-level thresholds
            $sql = "SELECT * FROM {$this->table} WHERE quantity <= ?";
            $stmt = $this->conn->fetchAll($sql, [$globalMin]);
        } else {
            // Use product-level alert values
            $sql = "SELECT * FROM {$this->table} WHERE quantity <= min_qty";
            $stmt = $this->conn->fetchAll($sql);
        }

        return $stmt;
    }

    // Out of stock products
    public function outOfStockProducts()
    {
        $sql = "SELECT * FROM {$this->table} WHERE quantity = 0";
        $stmt = $this->conn->fetchAll($sql);
        return $stmt;
    }

    // expired products
    public function expiredProducts()
    {
        $sql = "SELECT * FROM {$this->table} WHERE expiry_date < CURDATE() AND expiry_date IS NOT NULL";
        $stmt = $this->conn->fetchAll($sql);
        return $stmt;
    }
}
