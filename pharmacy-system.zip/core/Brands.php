<?php

class Brands
{
    private $conn;
    private $table = "brands"; // table name in DB

    public function __construct()
    {
        $this->conn = Database::getInstance();
    }

    // Add new brands
    public function addBrands(string $brands): ?int
    {
        // Check if brands already exists
        if ($this->brandsExists($brands)) {
            return null; // Brands already exists, return null
        }
        $sql = "INSERT INTO {$this->table} (name) VALUES (?)";

        if ($this->conn->insert($sql, [$brands])) {
            return $this->conn->insertId(); // Return new brands ID
        }

        return null; // Insert failed
    }

    // Update brands
    public function updateBrands(int $id, string $brands): bool
    {
        // Check if brands already exists
        if ($this->brandsExists($brands)) {
            return false; // Brands already exists, return false
        }
        $sql = "UPDATE {$this->table} SET name = ? WHERE id = ?";
        return $this->conn->update($sql, [$brands, $id]);
    }

    public function deleteBrands(int $id): bool
    {
        // Check if brands exists
        if (!$this->getBrandsById($id)) {
            return false; // Brands does not exist, return false
        }
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->conn->delete($sql, [$id]);
    }

    public function getBrands(): array
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY created_at DESC";
        return $this->conn->fetchAll($sql);
    }

    public function getBrandsById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        return $this->conn->fetch($sql, [$id]);
    }
    public function brandsExists(string $brands): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE name = ?";
        $result = $this->conn->fetch($sql, [$brands]);
        return $result['count'] > 0;
    }
}
