<?php
class Inventory
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function all()
    {
        $sql = "SELECT * FROM inventory";
        $stmt = $this->db->fetchAll($sql);
        return $stmt;
    }

    public function find($id)
    {
        $sql = "SELECT * FROM inventory WHERE id = ?";
        $stmt = $this->db->fetch($sql, [$id]);
        return $stmt;
    }

    public function create($data)
    {
        $sql = "INSERT INTO inventory (name, stock, price) VALUES (?, ?, ?)";
        if (empty($data['name']) || !isset($data['stock']) || !isset($data['price'])) {
            return false; // Validation failed
        }
        $stmt = $this->db->insert($sql, [
            $data['name'] ?? null,
            $data['stock'] ?? 0,
            $data['price'] ?? 0.00,
        ]);
        return $stmt;
    }

    public function update($id, $data)
    {
        $sql = "UPDATE inventory SET name = ?, stock = ?, price = ? WHERE id = ?";
        $stmt = $this->db->update($sql, [
            $data['name'] ?? '',
            $data['stock'] ?? 0,
            $data['price'] ?? 0.00,
            $id
        ]);
        return $stmt;
    }

    public function delete($id)
    {
        $sql = "DELETE FROM inventory WHERE id = ?";
        if (!$id) {
            return false; // Missing ID
        }
        $stmt = $this->db->delete($sql, [$id]);
        return $stmt;
    }
}
