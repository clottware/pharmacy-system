<?php

class Sales
{
    private $conn;
    private $salesTable = "sales";
    private $saleItemsTable = "sale_items";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Create new sale
    public function createSale($staff_id, $payment_method, $items = [])
    {
        try {
            $this->conn->beginTransaction();

            // Calculate total
            $total = 0;
            foreach ($items as $item) {
                $total += $item['quantity'] * $item['price'];
            }

            // Insert into sales table
            $sql = "INSERT INTO {$this->salesTable} (staff_id, payment_method, total_amount, created_at) VALUES (?, ?, ?, NOW())";
            $sale_id = $this->conn->insert($sql, [$staff_id, $payment_method, $total]);

            // Insert into sale_items table
            foreach ($items as $item) {
                $subtotal = $item['quantity'] * $item['price'];
                $sql = "INSERT INTO {$this->saleItemsTable} (sale_id, product_id, quantity, price, subtotal, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
                $this->conn->insert($sql, [
                    $sale_id,
                    $item['product_id'],
                    $item['quantity'],
                    $item['price'],
                    $subtotal
                ]);

                // Reduce stock in products table
                $this->updateProductStock($item['product_id'], $item['quantity']);
            }

            $this->conn->commit();
            return $sale_id;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    // Reduce stock
    private function updateProductStock($product_id, $quantity_sold)
    {
        $sql = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
        $this->conn->update($sql, [$quantity_sold, $product_id]);
    }

    // Get sale by ID
    public function getSale($sale_id)
    {
        $sql = "SELECT * FROM {$this->salesTable} WHERE id = ?";
        $sale = $this->conn->fetch($sql, [$sale_id]);

        if ($sale) {
            $sql = "SELECT * FROM {$this->saleItemsTable} WHERE sale_id = ?";
            $items = $this->conn->fetchAll($sql, [$sale_id]);
            $sale['items'] = $items;
        }
        return $sale;
    }

    // Get sales by date range
    public function getSalesByDateRange($start_date, $end_date)
    {
        $sql = "SELECT * FROM {$this->salesTable} WHERE DATE(created_at) BETWEEN ? AND ?";
        return $this->conn->fetchAll($sql, [$start_date, $end_date]);
    }
}
