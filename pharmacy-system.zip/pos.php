<?php require 'config/session.php'; ?>
<?php
$bodyClass = 'pos-page';
$mainClass = ' pos-three';
?>
<?php
function customPageHeader()
{ ?>
    <link rel='stylesheet' href='assets/plugins/owlcarousel/owl.carousel.min.css'>
    <link rel='stylesheet' href='assets/plugins/owlcarousel/owl.theme.default.min.css'>
<?php }
?>
<?php include 'head.php'; ?>
<?php include 'components/header-pos.php'; ?>

<div class="page-wrapper pos-pg-wrapper ms-0">
    <div class="content pos-design p-0">
        <div class="row align-items-start pos-wrapper">
            <?php include 'components/pos-left.php'; ?>
            <?php include 'components/pos-right.php'; ?>
        </div>
    </div>
</div>



<?php
function pageModal()
{
    ob_start();
    $settings = new Settings();
?>
    <!-- Calculator -->
    <div class="modal fade pos-modal" id="calculator" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="calculator-wrap">
                        <div class="p-3">
                            <div class="d-flex align-items-center">
                                <h3>Calculator</h3>
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div>
                                <input class="input" type="text" placeholder="0" readonly>
                            </div>
                        </div>
                        <div class="calculator-body d-flex justify-content-between">
                            <div class="text-center">
                                <button class="btn btn-clear" onclick="clr()">C</button>
                                <button class="btn btn-number" onclick="dis('7')">7</button>
                                <button class="btn btn-number" onclick="dis('4')">4</button>
                                <button class="btn btn-number" onclick="dis('1')">1</button>
                                <button class="btn btn-number" onclick="dis(',')">,</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-expression" onclick="dis('/')">÷</button>
                                <button class="btn btn-number" onclick="dis('8')">8</button>
                                <button class="btn btn-number" onclick="dis('5')">5</button>
                                <button class="btn btn-number" onclick="dis('2')">2</button>
                                <button class="btn btn-number" onclick="dis('0')">0</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-expression" onclick="dis('%')">%</button>
                                <button class="btn btn-number" onclick="dis('9')">9</button>
                                <button class="btn btn-number" onclick="dis('6')">6</button>
                                <button class="btn btn-number" onclick="dis('3')">3</button>
                                <button class="btn btn-number" onclick="dis('.')">.</button>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-clear" onclick="back()"><i class="ti ti-backspace"></i></button>
                                <button class="btn btn-expression" onclick="dis('*')">x</button>
                                <button class="btn btn-expression" onclick="dis('-')">-</button>
                                <button class="btn btn-expression" onclick="dis('+')">+</button>
                                <button class="btn btn-clear" onclick="solve()">=</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Calculator -->
    <!-- Cash Register Details -->
    <div class="modal fade pos-modal" id="cash-register" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cash Register Details</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped border">
                            <tr>
                                <td>Cash in Hand</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 45689</td>
                            </tr>
                            <tr>
                                <td>Total Sale Amount</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 565597.88</td>
                            </tr>
                            <tr>
                                <td>Total Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 566867.97</td>
                            </tr>
                            <tr>
                                <td>Cash Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 3355.84</td>
                            </tr>
                            <tr>
                                <td>Total Sale Return</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 1959</td>
                            </tr>
                            <tr>
                                <td>Total Expense</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 0</td>
                            </tr>
                            <tr>
                                <td class="text-gray-9 fw-bold bg-secondary-transparent">Total Cash</td>
                                <td class="text-gray-9 fw-bold text-end bg-secondary-transparent"><?= $settings->get('currency_symbol_full'); ?> 587130.97</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-end gap-2 flex-wrap">
                    <button type="button" class="btn btn-md btn-primary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /Cash Register Details -->

    <!-- Today's Sale -->
    <div class="modal fade pos-modal" id="today-sale" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Today's Sale</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped border">
                            <tr>
                                <td>Total Sale Amount</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 0</td>
                            </tr>
                            <tr>
                                <td>Cash Payment</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 0</td>
                            </tr>
                            <tr>
                                <td>Mobile Money</td>
                                <td class="text-gray-9 fw-medium text-end"><?= $settings->get('currency_symbol_full'); ?> 0</td>
                            </tr>
                            <tr>
                                <td class="text-gray-9 fw-bold bg-secondary-transparent">Total Cash</td>
                                <td class="text-gray-9 fw-bold text-end bg-secondary-transparent"><?= $settings->get('currency_symbol_full'); ?> 587130.97</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-end gap-2 flex-wrap">
                    <button type="button" class="btn btn-md btn-primary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /Today's Sale -->


    <script src='assets/js/calculator.js'></script>
    <?php
    function customPageFooter()
    { ?>
        <!-- Sticky-sidebar -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>

    <?php }
    ?>
<?php
}
require 'components/footer-pos.php';
?>

<script>
    $(function() {
        function updateClock() {
            var now = new Date();
            var h = String(now.getHours()).padStart(2, '0');
            var m = String(now.getMinutes()).padStart(2, '0');
            var s = String(now.getSeconds()).padStart(2, '0');
            $('.hour').text(h);
            $('.minute').text(m);
            $('.second').text(s);
        }
        updateClock();
        setInterval(updateClock, 1000);
    });
</script>