<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $company_name = Utils::sanitize($_POST['company_name'] ?? '');
    $company_email = Utils::sanitize($_POST['company_email'] ?? '');
    $company_phone = Utils::sanitize($_POST['company_phone'] ?? '');
    $company_fax = Utils::sanitize($_POST['company_fax'] ?? '');
    $company_website = Utils::sanitize($_POST['company_website'] ?? '');
    $company_address = Utils::sanitize($_POST['company_address'] ?? '');

    // Validate input
    if (empty($company_name)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Company name is required.'], 200);
        exit;
    }

    $settings = new Settings();

    $settings->set('site_name', $company_name);
    $settings->set('site_email', $company_email);
    $settings->set('phone', $company_phone);
    $settings->set('fax', $company_fax);
    $settings->set('website', $company_website);
    $settings->set('address', $company_address);

    echo Utils::jsonResponse([
        'status' => true,
        'message' => 'Company settings updated successfully.'
    ], 200);
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
