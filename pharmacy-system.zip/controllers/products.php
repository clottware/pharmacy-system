<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $productModel = new Product();
    $product_name = Utils::sanitize($_POST['product_name'] ?? '');
    $product_id = Utils::sanitize($_POST['product_id'] ?? '');
    $category_id = Utils::sanitize($_POST['category_id'] ?? '');
    $brand_id = Utils::sanitize($_POST['brand_id'] ?? '');
    $supplier_id = Utils::sanitize($_POST['supplier_id'] ?? '');
    $purchase_price = Utils::sanitize($_POST['purchase_price'] ?? '');
    $selling_price = Utils::sanitize($_POST['selling_price'] ?? '');
    $quantity = Utils::sanitize($_POST['quantity'] ?? '');
    $dosage_form = Utils::sanitize($_POST['dosage_form'] ?? '');
    $quantity_alert = Utils::sanitize($_POST['quantity_alert'] ?? '');
    $expiry_date = Utils::sanitize($_POST['expiry_date'] ?? '');

    // Basic validation
    if (empty($product_name) || empty($category_id)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Please fill in all required fields.'], 400);
        return;
    }
    // If category is Medicine and let say medicine Id is 5 require expiration date
    if ($category_id == 5 && empty($expiry_date)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Please provide an expiry date for medicines.'], 400);
        return;
    }

    // check if user is still logged in
    if (!$auth->isLoggedIn()) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Unauthorized. Please log in again.'], 401);
        return;
    }

    $currentUser = $auth->currentUser();


    if (isset($product_id) && !empty($product_id)) {
        // Handle product update logic here if needed
        $data = [
            'product_name' => $product_name,
            'category_id' => $category_id,
            'brand_id' => $brand_id,
            'supplier_id' => $supplier_id,
            'cost_price' => $purchase_price,
            'selling_price' => $selling_price,
            'quantity' => $quantity,
            'dosage_form' => $dosage_form,
            'min_qty' => $quantity_alert,
            'expiry_date' => $expiry_date,
            'user_id' => $currentUser['id']
        ];

        $updated = $productModel->updateProduct((int)$product_id, $data);
        if ($updated) {
            echo Utils::jsonResponse(['status' => true, 'message' => 'Product updated successfully.'], 200);
        } else {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Failed to update product.'], 500);
        }
    }

    // Handle product creation logic here if needed
    if (!isset($_POST['product_id'])) {
        $data = [
            'product_name' => $product_name,
            'category_id' => $category_id,
            'brand_id' => $brand_id,
            'supplier_id' => $supplier_id,
            'cost_price' => $purchase_price,
            'selling_price' => $selling_price,
            'quantity' => $quantity,
            'dosage_form' => $dosage_form,
            'min_qty' => $quantity_alert,
            'expiry_date' => $expiry_date,
            'user_id' => $currentUser['id']
        ];

        $newProductId = $productModel->addProduct($data);
        if ($newProductId) {
            echo Utils::jsonResponse(['status' => true, 'message' => 'Product added successfully.', 'product_id' => $newProductId], 201);
        } else {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Failed to add product.'], 500);
        }
    }
} elseif (Utils::isGet()) {

    if (isset($_GET['search'])) {
        $search = Utils::slugify($_GET['search'] ?? '');

        $offset = intval($_GET['offset'] ?? 0); // for pagination
        $limit  = 10; // batch size

        // RxNorm API endpoint - pick accurate 10 first.
        $url = "https://rxnav.nlm.nih.gov/REST/drugs.json?name={$search}";

        $response = file_get_contents($url);
        $data = json_decode($response, true);

        $suggestions = [];

        if (isset($data['drugGroup']['conceptGroup'])) {
            $allDrugs = [];

            foreach ($data['drugGroup']['conceptGroup'] as $group) {
                if (isset($group['conceptProperties'])) {
                    foreach ($group['conceptProperties'] as $drug) {
                        $allDrugs[] = $drug;
                    }
                }
            }
            $allowedTtys = ['SCD', 'SBD', 'SCDG', 'SBDG', 'GPCK', 'BPCK'];
            // Slice results for pagination
            $pagedDrugs = array_slice($allDrugs, $offset, $limit);

            foreach ($pagedDrugs as $drug) {
                $rxcui = $drug['rxcui'] ?? '';
                if ($rxcui && in_array($drug['tty'] ?? '', $allowedTtys)) {
                    $getAllRxTermInfo = "https://rxnav.nlm.nih.gov/REST/RxTerms/rxcui/{$rxcui}/allinfo.json";
                    $rxResponse = file_get_contents($getAllRxTermInfo);
                    $rxData = json_decode($rxResponse, true);

                    $suggestions[] = [
                        'rxcui' => $rxcui,
                        'name' => $drug['name'] ?? '',
                        'tty' => $drug['tty'] ?? '',
                        'fullInfo' => $rxData['rxtermsProperties'] ?? null
                    ];
                }
            }

            $hasMore = ($offset + $limit) < count($allDrugs);
        } else {
            $hasMore = false;
        }

        echo Utils::jsonResponse(['status' => true, 'data' => $suggestions, 'hasMore' => $hasMore], 200);
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method. -' . $search], 405);
}
