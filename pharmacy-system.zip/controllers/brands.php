<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $brand = Utils::sanitize($_POST['brand'] ?? '');
    $brand_type = Utils::sanitize($_POST['brand_type'] ?? '');
    $brand_id = isset($_POST['brand_id']) ? (int)$_POST['brand_id'] : null;

    // Validate input
    if (!in_array($brand_type, ['new', 'edit', 'delete'])) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid brand type.'], 400);
        exit;
    }

    $brandModel = new Brands();

    if ($brand_type === 'new') {
        if (empty($brand)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Brands name is required.'], 200);
            exit;
        }
        $result = $brandModel->addBrands($brand);
        $brand_id = $result; // Get the ID of the newly created brand
    }

    if ($brand_type === 'edit') {
        // Ensure brand_id is provided for editing
        if (empty($brand)) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Brands name is required.'], 200);
            exit;
        }
        if (!$brand_id) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Brands ID is required for editing.'], 400);
            exit;
        }
        $result = $brandModel->updateBrands($brand_id, $brand);
    }

    if ($brand_type === 'delete') {
        // Ensure brand_id is provided for deletion
        if (!$brand_id) {
            echo Utils::jsonResponse(['status' => false, 'message' => 'Brands ID is required for deletion.'], 400);
            exit;
        }
        $result = $brandModel->deleteBrands($brand_id);
    }

    if ($result) {
        echo Utils::jsonResponse(['status' => true, 'message' => 'Brands saved successfully.', 'brands' => ['brand_id' => $brand_id, 'brand' => $brand]], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Brands already exists.'], 200);
    }
} elseif (Utils::isGet()) {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $brandModel = new Brands();

    if ($id) {
        $brand = $brandModel->getBrandsById($id);
        echo Utils::jsonResponse(['status' => true, 'data' => $brand], 200);
    } else {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid brand ID.'], 400);
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
