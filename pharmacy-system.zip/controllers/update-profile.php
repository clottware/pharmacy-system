<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check login
if (!$auth->checkRememberedUser()) {
    echo json_encode(['status' => false, 'authentication' => false, 'message' => 'You are not logged in.']);
    exit;
}

if (Utils::isPost()) {
    $first_name = Utils::sanitize($_POST['first_name']) ?? '';
    $last_name = Utils::sanitize($_POST['last_name']) ?? '';
    $username = Utils::sanitize($_POST['username']) ?? '';
    $phone = Utils::sanitize($_POST['phone_number']) ?? '';
    $email = Utils::sanitize($_POST['email']) ?? '';

    // Validate
    if (empty($first_name) || empty($last_name) || empty($username) || empty($email)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'Fill in all required fields.'], 400);
        exit;
    }

    try {
        if ($auth->updateProfile($first_name, $last_name, $username, $phone, $email)) {
            echo Utils::jsonResponse(['status' => true, 'message' => 'Profile updated successfully.']);
        } else {
            echo Utils::jsonResponse(['status' => false, 'message' => 'No changes were made or update failed.'], 400);
        }
    } catch (Throwable $th) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'An error occurred: ' . $th->getMessage()], 500);
    }
}
