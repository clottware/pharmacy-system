<?php
require_once '../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = sanitizeInput($_POST['first_name'] ?? '');
    $lastName = sanitizeInput($_POST['last_name'] ?? '');
    $username = sanitizeInput($_POST['username'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (
        empty($firstName) || empty($lastName) || empty($username) ||
        empty($email) || empty($password) || empty($confirmPassword)
    ) {
        jsonResponse('error', 'All fields are required.');
    }

    if (!validateEmail($email)) {
        jsonResponse('error', 'Invalid email address.');
    }

    if ($password !== $confirmPassword) {
        jsonResponse('error', 'Passwords do not match.');
    }

    $db = new DB();

    // Check if user exists
    $exists = $db->fetch("SELECT id FROM users WHERE username = ? OR email = ?", [$username, $email]);
    if ($exists) {
        jsonResponse('error', 'Username or email already taken.');
    }

    // Insert new user
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $db->query(
        "INSERT INTO users (first_name, last_name, username, email, password) VALUES (?, ?, ?, ?, ?)",
        [$firstName, $lastName, $username, $email, $hashed]
    );

    jsonResponse('success', 'Registration successful. Please log in.');
}
