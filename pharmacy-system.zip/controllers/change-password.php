<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Check if the request is POST
if (Utils::isPost()) {
    $current_password = Utils::sanitize($_POST['current_password'] ?? '');
    $new_password = Utils::sanitize($_POST['new_password'] ?? '');
    $confirm_password = Utils::sanitize($_POST['confirm_password'] ?? '');

    // Validate input
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'All fields are required.'], 400);
        exit;
    }
    if ($new_password !== $confirm_password) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'New password and confirm password do not match.'], 200);
        exit;
    }
    if (strlen($new_password) < 8) {
        echo Utils::jsonResponse(['status' => false, 'message' => 'New password must be at least 8 characters long.'], 200);
        exit;
    }
    // check and change password
    $change_password = ($auth->changePassword($current_password, $new_password));
    if (!$change_password['status']) {
        echo Utils::jsonResponse(['status' => false, 'message' => $change_password['message']], 200);
        exit;
    } else {
        echo Utils::jsonResponse(['status' => true, 'message' => $change_password['message']], 200);
        exit;
    }
} else {
    echo Utils::jsonResponse(['status' => false, 'message' => 'Invalid request method.'], 405);
}
