<?php

/**
 * This file contains functions used across the application.
 * It is included in various pages to provide common functionality.
 */

// Include the configuration file
include_once __DIR__ . '/config/config.php';

// Default page head styles and scripts
function getHeadContent($title = 'Clottware Pharmacy Dashboard')
{
    ob_start();
?>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title) ?></title>
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css">
    <!-- Tabler Icon CSS -->
    <link rel="stylesheet" href="assets/plugins/tabler-icons/tabler-icons.min.css">
    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

    <!-- Daterangepikcer CSS -->
    <link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker.css">
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="assets/css/dataTables.bootstrap5.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
    <!-- animation CSS -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Select2 css -->
    <link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">
    <?php if (function_exists('customPageHeader')) {
        customPageHeader();
    } ?>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css?V=<?= time(); ?>">
    <link href="/assets/css/custom.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js">
    </script>
<?php
    return ob_get_clean();
}

// Default page footer scripts
function getFooterContent()
{
    ob_start();
?>
    <script src="assets/js/bootstrap.bundle.min.js">
    </script>
    <!-- Feather Icon JS -->
    <script src="assets/js/feather.min.js"></script>

    <!-- Select2 JS -->
    <script src="assets/plugins/select2/js/select2.min.js"></script>

    <!-- Slimscroll JS -->
    <script src="assets/js/jquery.slimscroll.min.js"></script>

    <script src="assets/plugins/sweetalert2/sweetalert2.all.min.js"></script>
    <!-- Datatable JS -->
    <script src="assets/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="assets/js/dataTables.bootstrap5.min.js" type="text/javascript"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/plugins/daterangepicker/daterangepicker.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <?php if (function_exists('customPageFooter')) {
        customPageFooter();
    } ?>
    <script src="assets/plugins/avatar/initial.min.js?v=<?= time() ?>"></script>
    <script src="assets/js/theme-colorpicker.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/main.js?v=<?= time(); ?>"></script>
<?php
    return ob_get_clean();
}

// Page specific head styles and scripts
function customHead($content = []): string
{
    // This function can be overridden in specific pages to add custom styles or scripts
    return implode("\n", $content);
}


function customFooter($contents = []): string
{
    // This function can be overridden in specific pages to add custom styles or scripts
    return implode("\n", $contents);
}

include_once __DIR__ . '/components/delete-confirm-modal.php';

// function pageModal()
// {
//     // This function can be overridden in specific pages to add modals
//     return null;
// }