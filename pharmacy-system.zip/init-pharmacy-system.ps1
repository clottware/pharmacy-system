# PowerShell Script: init-pharmacy-system.ps1
# Usage: Open PowerShell, navigate to your project folder, then run: ./init-pharmacy-system.ps1

# Base folders
$folders = @(
    "assets\css",
    "assets\js",
    "assets\images",
    "components",
    "config",
    "controllers",
    "core",
    "docs",
    "models",
    "premium",
    "updates",
    "views"
)

# Base files to create
$files = @(
    "index.php",
    "dashboard.php",
    "config\db.php",
    "docs\README.md",
    "docs\structure.md",
    "docs\database-schema.sql"
)

# Create folders
foreach ($folder in $folders) {
    if (!(Test-Path -Path $folder)) {
        New-Item -ItemType Directory -Path $folder | Out-Null
    }
}

# Create files
foreach ($file in $files) {
    if (!(Test-Path -Path $file)) {
        New-Item -ItemType File -Path $file | Out-Null
    }
}

Write-Host "✅ Pharmacy System folders and files initialized!"
